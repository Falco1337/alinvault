import sys
import os
import shutil
import webbrowser
import subprocess
import re
import json
import asyncio
import threading
import time
import pickle
from urllib.parse import urlparse
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QGridLayout, QHBoxLayout, QPushButton,
    QStackedWidget, QLabel, QFrame, QListWidget,
    QListWidgetItem, QMessageBox, QTextEdit,
    QDialog, QDialogButtonBox, QLineEdit,
    QInputDialog, QProgressBar, QSystemTrayIcon,
    QMenu, QScrollArea, QButtonGroup, QSplitter,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QComboBox, QDateTimeEdit,
    QCheckBox, QStyle
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineSettings, QWebEngineDownloadRequest
from PyQt6.QtCore import QUrl, QTimer, QDateTime, Qt, QPoint, QTimeZone, QSize, pyqtSignal, QThread, QObject
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor, QFont, QLinearGradient, QPen, QMouseEvent, QAction

class ThrottledSearch:
    def __init__(self, callback, delay=300):
        self.callback = callback
        self.delay = delay
        self.timer = QTimer()
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.callback)
        
    def trigger(self):
        self.timer.start(self.delay)

class CommandCache:
    def __init__(self, ttl=5):
        self.cache = {}
        self.ttl = ttl
        
    def get(self, key, func):
        if key in self.cache:
            result, timestamp = self.cache[key]
            if time.time() - timestamp < self.ttl:
                return result
        result = func()
        self.cache[key] = (result, time.time())
        return result

try:
    import win32gui
    import win32process
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False

NOTES_FILE = "alin_notes.dat"

class Note:
    def __init__(self, title="", content="", created=None, modified=None, category="General", is_todo=False):
        self.title = title
        self.content = content
        self.created = created or QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
        self.modified = modified or QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
        self.category = category
        self.is_todo = is_todo
        self.todo_items = []

class NotificationManager(QObject):
    notification_received = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        self.notifications = []
        self.unread_count = 0
        self.auto_allow_domains = [
            "web.whatsapp.com",
            "chat.openai.com",
            "chat.deepseek.com",
            "messages.google.com",
            "telegram.org",
            "discord.com",
            "slack.com",
            "teams.microsoft.com",
            "zoom.us",
            "meet.google.com",
            "facebook.com",
            "x.com",
            "instagram.com"
        ]
    
    def handle_notification(self, notification):
        try:
            title = notification.title()
            message = notification.message()
            
            origin = notification.origin().toString() if notification.origin() else "unknown"
            
            print(f"Handling notification: {title} - {message} from {origin}") 
            
            self.add_notification(title, message, origin)
            
            self.show_system_notification(title, message, origin)
            
        except Exception as e:
            print(f"Error handling notification: {e}")
            import traceback
            traceback.print_exc()
            
    def check_and_allow_notifications(self, url):
        for domain in self.auto_allow_domains:
            if domain in url:
                return True
        return False
    
    def handle_permission_request(self, request):
        try:
            url = request.requestingOrigin().toString()
            
            if request.permissionType() == QWebEnginePage.Feature.Notifications:
                if self.check_and_allow_notifications(url):
                    request.grant()
                    return True
    
            request.deny()
            return False
        except Exception as e:
            print(f"Error handling permission request: {e}")
            try:
                request.deny()
            except:
                pass
            return False
    
    def add_notification(self, title, message, origin):
        try:
            notif_data = {
                'id': len(self.notifications),
                'title': title,
                'message': message,
                'origin': origin,
                'timestamp': QDateTime.currentDateTime(),
                'read': False
            }
            
            self.notifications.insert(0, notif_data)
            self.unread_count += 1
            
            if len(self.notifications) > 100:
                self.notifications = self.notifications[:100]
            
            self.notification_received.emit(notif_data)
            self.show_system_notification(title, message, origin)
            
        except Exception as e:
            print(f"Error adding notification: {e}")
    
    def show_system_notification(self, title, message, origin):
        try:
            app = QApplication.instance()
            for widget in app.topLevelWidgets():
                if hasattr(widget, 'system_tray') and widget.system_tray:
                    domain = origin.replace('https://', '').replace('http://', '').split('/')[0]
                    widget.system_tray.show_notification(
                        f"{domain} - {title}",
                        message,
                        3000
                    )
                break
        except:
            pass
    
    def mark_as_read(self, notification_id):
        for notif in self.notifications:
            if notif.get('id') == notification_id and not notif.get('read'):
                notif['read'] = True
                self.unread_count = max(0, self.unread_count - 1)
                break
    
    def mark_all_as_read(self):
        for notif in self.notifications:
            notif['read'] = True
        self.unread_count = 0
    
    def clear_all(self):
        self.notifications.clear()
        self.unread_count = 0
    
    def get_unread_count(self):
        return self.unread_count
    
class NotificationItemWidget(QWidget):
    def __init__(self, notification_data, dark_mode=False, parent=None):
        super().__init__(parent)
        self.notification_data = notification_data
        self.dark_mode = dark_mode
        self.app_icon_path = None
        
        self.setObjectName("notificationItem")
        self.setFixedHeight(100)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(20, 12, 20, 12)
        layout.setSpacing(15)
        
        # App icon frame
        icon_frame = QFrame()
        icon_frame.setObjectName("notificationIconFrame")
        icon_frame.setFixedSize(48, 48)
        icon_layout = QVBoxLayout()
        icon_layout.setContentsMargins(0, 0, 0, 0)
        
        self.icon_label = QLabel()
        self.icon_label.setObjectName("notificationIcon")
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.set_icon()
        
        # Unread dot
        self.unread_dot = QFrame(self)
        self.unread_dot.setObjectName("unreadDot")
        self.unread_dot.setFixedSize(10, 10)
        self.unread_dot.move(35, 5)
        if notification_data.get('read'):
            self.unread_dot.hide()
        
        icon_layout.addWidget(self.icon_label)
        icon_frame.setLayout(icon_layout)
        layout.addWidget(icon_frame)
        
        # Content
        content_layout = QVBoxLayout()
        content_layout.setSpacing(6)
        
        # Header with origin and time
        header_layout = QHBoxLayout()
        
        origin_text = notification_data['origin'].replace('https://', '').replace('http://', '').split('/')[0]
        
        origin_label = QLabel(origin_text)
        origin_label.setObjectName("notificationOrigin")
        origin_font = QFont("SF Pro Text", 13, QFont.Weight.DemiBold)  # Fixed: Changed Semibold to DemiBold
        origin_label.setFont(origin_font)
        
        time_label = QLabel(notification_data['timestamp'].toString("hh:mm:ss"))
        time_label.setObjectName("notificationTime")
        
        header_layout.addWidget(origin_label)
        header_layout.addStretch()
        header_layout.addWidget(time_label)
        content_layout.addLayout(header_layout)
        
        # Title
        title_label = QLabel(notification_data['title'])
        title_label.setObjectName("notificationTitle")
        title_label.setWordWrap(True)
        title_font = QFont("SF Pro Text", 14, QFont.Weight.Bold)
        title_label.setFont(title_font)
        content_layout.addWidget(title_label)
        
        # Message
        message_label = QLabel(notification_data['message'])
        message_label.setObjectName("notificationMessage")
        message_label.setWordWrap(True)
        message_label.setMaximumHeight(40)
        content_layout.addWidget(message_label)
        
        layout.addLayout(content_layout, 1)
        
        # Actions
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(8)
        
        self.mark_read_btn = QPushButton()
        self.mark_read_btn.setObjectName("actionIconButton")
        self.mark_read_btn.setFixedSize(36, 36)
        self.mark_read_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.mark_read_btn.clicked.connect(self.mark_as_read)
        
        # Checkmark icon
        check_icon_path = os.path.join(os.path.dirname(__file__), "assets", "check.png")
        if os.path.exists(check_icon_path):
            check_icon = QIcon(check_icon_path)
            self.mark_read_btn.setIcon(check_icon)
            self.mark_read_btn.setIconSize(QSize(18, 18))
        else:
            self.mark_read_btn.setText("✓")
        
        if notification_data.get('read'):
            self.mark_read_btn.setVisible(False)
        
        self.delete_btn = QPushButton()
        self.delete_btn.setObjectName("actionIconButton")
        self.delete_btn.setFixedSize(36, 36)
        self.delete_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.delete_btn.clicked.connect(self.delete_notification)
        
        # Delete icon
        delete_icon_path = os.path.join(os.path.dirname(__file__), "assets", "bin.png")
        if os.path.exists(delete_icon_path):
            delete_icon = QIcon(delete_icon_path)
            self.delete_btn.setIcon(delete_icon)
            self.delete_btn.setIconSize(QSize(18, 18))
        else:
            self.delete_btn.setText("🗑️")
        
        actions_layout.addWidget(self.mark_read_btn)
        actions_layout.addWidget(self.delete_btn)
        
        layout.addLayout(actions_layout)
        
        self.setLayout(layout)
        self.update_stylesheet()
    
    def set_icon(self):
        """Set app icon based on origin"""
        if self.app_icon_path and os.path.exists(self.app_icon_path):
            pixmap = QPixmap(self.app_icon_path)
            scaled_pixmap = pixmap.scaled(32, 32, 
                                        Qt.AspectRatioMode.KeepAspectRatio, 
                                        Qt.TransformationMode.SmoothTransformation)
            self.icon_label.setPixmap(scaled_pixmap)
        else:
            # Fallback to emoji
            origin = self.notification_data['origin'].lower()
            if 'whatsapp' in origin:
                self.icon_label.setText("💬")
            elif 'chat.openai' in origin or 'chatgpt' in origin:
                self.icon_label.setText("🤖")
            elif 'deepseek' in origin:
                self.icon_label.setText("🔍")
            elif 'discord' in origin:
                self.icon_label.setText("💭")
            elif 'teams' in origin or 'microsoft' in origin:
                self.icon_label.setText("👥")
            elif 'meet' in origin or 'google' in origin:
                self.icon_label.setText("📹")
            elif 'facebook' in origin:
                self.icon_label.setText("👤")
            elif 'instagram' in origin:
                self.icon_label.setText("📸")
            elif 'telegram' in origin:
                self.icon_label.setText("✈️")
            elif 'slack' in origin:
                self.icon_label.setText("#")
            elif 'zoom' in origin:
                self.icon_label.setText("🎥")
            else:
                self.icon_label.setText("🔔")
    
    def set_app_icon(self, icon_path):
        """Set custom app icon"""
        self.app_icon_path = icon_path
        self.set_icon()
    
    def mark_as_read(self):
        if not self.notification_data.get('read'):
            self.notification_data['read'] = True
            self.mark_read_btn.setVisible(False)
            self.unread_dot.hide()
            self.update_stylesheet()
            
            parent = self.parent()
            while parent and not hasattr(parent, 'notification_marked_read'):
                parent = parent.parent()
            if parent and hasattr(parent, 'notification_marked_read'):
                parent.notification_marked_read(self.notification_data['id'])
    
    def delete_notification(self):
        parent = self.parent()
        while parent and not hasattr(parent, 'notification_deleted'):
            parent = parent.parent()
        if parent and hasattr(parent, 'notification_deleted'):
            parent.notification_deleted(self.notification_data['id'])
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_stylesheet()
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QFrame#notificationItem {
                    background: #2a2a3a;
                    border-radius: 16px;
                    border: 1px solid #3a3a4a;
                }
                QFrame#notificationItem:hover {
                    background: #323242;
                    border-color: #4a4a5a;
                }
                QFrame#notificationIconFrame {
                    background: #3a3a4a;
                    border-radius: 12px;
                }
                QLabel#notificationIcon {
                    color: #0a84ff;
                    font-size: 24px;
                }
                QFrame#unreadDot {
                    background: #0a84ff;
                    border-radius: 5px;
                }
                QLabel#notificationOrigin {
                    color: #ffffff;
                    font-size: 13px;
                    font-weight: 600;
                }
                QLabel#notificationTime {
                    color: #8e8e93;
                    font-size: 12px;
                }
                QLabel#notificationTitle {
                    color: #ffffff;
                    font-size: 14px;
                    font-weight: bold;
                }
                QLabel#notificationMessage {
                    color: #8e8e93;
                    font-size: 13px;
                }
                QPushButton#actionIconButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                }
                QPushButton#actionIconButton:hover {
                    background: #4a4a5a;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame#notificationItem {
                    background: #ffffff;
                    border-radius: 16px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                QFrame#notificationItem:hover {
                    background: #f8f9fa;
                    border-color: rgba(60, 60, 67, 0.2);
                }
                QFrame#notificationIconFrame {
                    background: #f2f2f7;
                    border-radius: 12px;
                }
                QLabel#notificationIcon {
                    color: #007aff;
                    font-size: 24px;
                }
                QFrame#unreadDot {
                    background: #007aff;
                    border-radius: 5px;
                }
                QLabel#notificationOrigin {
                    color: #000000;
                    font-size: 13px;
                    font-weight: 600;
                }
                QLabel#notificationTime {
                    color: #8e8e93;
                    font-size: 12px;
                }
                QLabel#notificationTitle {
                    color: #000000;
                    font-size: 14px;
                    font-weight: bold;
                }
                QLabel#notificationMessage {
                    color: #8e8e93;
                    font-size: 13px;
                }
                QPushButton#actionIconButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                }
                QPushButton#actionIconButton:hover {
                    background: #e5e5ea;
                }
            """)

class NotificationsWidget(QWidget):
    def __init__(self, notification_manager, parent=None):
        super().__init__(parent)
        self.notification_manager = notification_manager
        self.dark_mode = False
        self.current_filter = "All"
        
        self.notification_manager.notification_received.connect(self.add_notification)
        
        # Main layout
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Header with gradient
        header = QFrame()
        header.setObjectName("notificationsHeader")
        header.setFixedHeight(120)
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 0, 30, 0)
        
        # Left side with icon and title
        title_container = QWidget()
        title_layout = QHBoxLayout()
        title_layout.setSpacing(15)
        
        # Notification icon with badge
        icon_frame = QFrame()
        icon_frame.setObjectName("headerIconFrame")
        icon_frame.setFixedSize(50, 50)
        icon_layout = QVBoxLayout()
        icon_layout.setContentsMargins(0, 0, 0, 0)
        
        icon_label = QLabel("🔔")
        icon_label.setObjectName("headerIcon")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_font = QFont("SF Pro Display", 28)
        icon_label.setFont(icon_font)
        icon_layout.addWidget(icon_label)
        icon_frame.setLayout(icon_layout)
        
        title_container_layout = QVBoxLayout()
        title_container_layout.setSpacing(4)
        
        self.title_label = QLabel("Notifications")
        self.title_label.setObjectName("mainTitle")
        title_font = QFont("SF Pro Display", 32, QFont.Weight.Bold)
        self.title_label.setFont(title_font)
        
        self.subtitle_label = QLabel("Stay updated with your latest alerts")
        self.subtitle_label.setObjectName("subtitleLabel")
        subtitle_font = QFont("SF Pro Text", 14)
        self.subtitle_label.setFont(subtitle_font)
        
        title_container_layout.addWidget(self.title_label)
        title_container_layout.addWidget(self.subtitle_label)
        
        title_layout.addWidget(icon_frame)
        title_layout.addLayout(title_container_layout)
        title_container.setLayout(title_layout)
        header_layout.addWidget(title_container)
        
        header_layout.addStretch()
        
        # Stats cards
        stats_container = QWidget()
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(15)
        
        # Unread card
        self.unread_card = self.create_stat_card("🔔", "Unread", "0")
        # Total card
        self.total_card = self.create_stat_card("📋", "Total", "0")
        # Today card
        self.today_card = self.create_stat_card("📅", "Today", "0")
        
        stats_layout.addWidget(self.unread_card)
        stats_layout.addWidget(self.total_card)
        stats_layout.addWidget(self.today_card)
        stats_container.setLayout(stats_layout)
        header_layout.addWidget(stats_container)
        
        header.setLayout(header_layout)
        layout.addWidget(header)
        
        # Filter toolbar
        toolbar = QFrame()
        toolbar.setObjectName("notificationsToolbar")
        toolbar.setFixedHeight(70)
        toolbar_layout = QHBoxLayout()
        toolbar_layout.setContentsMargins(30, 0, 30, 0)
        toolbar_layout.setSpacing(20)
        
        # Filter chips
        filter_chips_container = QFrame()
        filter_chips_container.setObjectName("filterChipsContainer")
        filter_chips_layout = QHBoxLayout()
        filter_chips_layout.setContentsMargins(0, 0, 0, 0)
        filter_chips_layout.setSpacing(8)
        
        # Filter chips
        self.filter_all_btn = self.create_filter_chip("All", True)
        self.filter_all_btn.clicked.connect(lambda: self.set_filter("All"))
        
        self.filter_unread_btn = self.create_filter_chip("Unread", False)
        self.filter_unread_btn.clicked.connect(lambda: self.set_filter("Unread"))
        
        self.filter_today_btn = self.create_filter_chip("Today", False)
        self.filter_today_btn.clicked.connect(lambda: self.set_filter("Today"))
        
        filter_chips_layout.addWidget(self.filter_all_btn)
        filter_chips_layout.addWidget(self.filter_unread_btn)
        filter_chips_layout.addWidget(self.filter_today_btn)
        filter_chips_layout.addStretch()
        filter_chips_container.setLayout(filter_chips_layout)
        
        toolbar_layout.addWidget(filter_chips_container)
        
        toolbar_layout.addStretch()
        
        # Action buttons
        actions_container = QFrame()
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(10)
        
        self.btn_mark_all_read = QPushButton("Mark All as Read")
        self.btn_mark_all_read.setObjectName("actionButton")
        self.btn_mark_all_read.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_mark_all_read.clicked.connect(self.mark_all_read)
        
        self.btn_clear_all = QPushButton("Clear All")
        self.btn_clear_all.setObjectName("actionButton")
        self.btn_clear_all.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_clear_all.clicked.connect(self.clear_all)
        
        self.btn_settings = QPushButton()
        self.btn_settings.setObjectName("iconButton")
        self.btn_settings.setFixedSize(40, 40)
        self.btn_settings.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_settings.clicked.connect(self.show_settings)
        
        # Settings icon
        settings_icon_path = os.path.join(os.path.dirname(__file__), "assets", "settings.png")
        if os.path.exists(settings_icon_path):
            settings_icon = QIcon(settings_icon_path)
            self.btn_settings.setIcon(settings_icon)
            self.btn_settings.setIconSize(QSize(20, 20))
        else:
            self.btn_settings.setText("⚙️")
        
        actions_layout.addWidget(self.btn_mark_all_read)
        actions_layout.addWidget(self.btn_clear_all)
        actions_layout.addWidget(self.btn_settings)
        actions_container.setLayout(actions_layout)
        
        toolbar_layout.addWidget(actions_container)
        
        toolbar.setLayout(toolbar_layout)
        layout.addWidget(toolbar)
        
        # Search bar
        search_container = QFrame()
        search_container.setObjectName("searchContainer")
        search_container.setFixedHeight(60)
        search_container_layout = QHBoxLayout()
        search_container_layout.setContentsMargins(30, 0, 30, 0)
        
        search_icon = QLabel("🔍")
        search_icon.setObjectName("searchIcon")
        
        self.search_input = QLineEdit()
        self.search_input.setObjectName("searchInput")
        self.search_input.setPlaceholderText("Search notifications...")
        self.search_input.textChanged.connect(self.filter_notifications)
        
        search_container_layout.addWidget(search_icon)
        search_container_layout.addWidget(self.search_input)
        search_container.setLayout(search_container_layout)
        layout.addWidget(search_container)
        
        # Notifications list
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameStyle(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        self.scroll_content = QWidget()
        self.scroll_content.setObjectName("scrollContent")
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.scroll_layout.setSpacing(10)
        self.scroll_layout.setContentsMargins(30, 20, 30, 20)
        
        self.scroll_area.setWidget(self.scroll_content)
        layout.addWidget(self.scroll_area)
        
        # Empty state
        self.empty_state = self.create_empty_state()
        self.scroll_layout.addWidget(self.empty_state)
        
        self.setLayout(layout)
        self.update_stylesheet()
        self.refresh_notifications()
    
    def create_stat_card(self, icon, label, value):
        card = QFrame()
        card.setObjectName("statCard")
        card.setFixedSize(110, 80)
        
        layout = QVBoxLayout()
        layout.setSpacing(5)
        layout.setContentsMargins(10, 12, 10, 12)
        
        icon_label = QLabel(icon)
        icon_label.setObjectName("statIcon")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        value_label = QLabel(value)
        value_label.setObjectName("statValue")
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        value_font = QFont("SF Pro Display", 20, QFont.Weight.Bold)
        value_label.setFont(value_font)
        
        label_label = QLabel(label)
        label_label.setObjectName("statLabel")
        label_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label_font = QFont("SF Pro Text", 12)
        label_label.setFont(label_font)
        
        layout.addWidget(icon_label)
        layout.addWidget(value_label)
        layout.addWidget(label_label)
        
        card.setLayout(layout)
        card.value_label = value_label
        return card
    
    def create_filter_chip(self, text, checked=False):
        chip = QPushButton(text)
        chip.setObjectName("filterChip")
        chip.setCheckable(True)
        chip.setChecked(checked)
        chip.setCursor(Qt.CursorShape.PointingHandCursor)
        chip.setFixedHeight(36)
        return chip
    
    def create_empty_state(self):
        empty = QFrame()
        empty.setObjectName("emptyState")
        empty.setFixedHeight(300)
        
        layout = QVBoxLayout()
        layout.setSpacing(20)
        
        icon_label = QLabel("🔔")
        icon_label.setObjectName("emptyIcon")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_font = QFont("SF Pro Display", 64)
        icon_label.setFont(icon_font)
        
        title_label = QLabel("No notifications")
        title_label.setObjectName("emptyTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = QFont("SF Pro Display", 20, QFont.Weight.Medium)
        title_label.setFont(title_font)
        
        desc_label = QLabel("You're all caught up! New notifications will appear here")
        desc_label.setObjectName("emptyDesc")
        desc_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_font = QFont("SF Pro Text", 14)
        desc_label.setFont(desc_font)
        desc_label.setWordWrap(True)
        
        layout.addStretch()
        layout.addWidget(icon_label)
        layout.addWidget(title_label)
        layout.addWidget(desc_label)
        layout.addStretch()
        
        empty.setLayout(layout)
        return empty
    
    def set_filter(self, filter_type):
        self.current_filter = filter_type
        
        # Update chip states
        self.filter_all_btn.setChecked(filter_type == "All")
        self.filter_unread_btn.setChecked(filter_type == "Unread")
        self.filter_today_btn.setChecked(filter_type == "Today")
        
        self.filter_notifications()
    
    def filter_notifications(self):
        search_text = self.search_input.text().lower()
        today = QDateTime.currentDateTime().date()
        
        # Hide all items first
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), NotificationItemWidget):
                item.widget().hide()
        
        # Show matching items
        visible_count = 0
        today_count = 0
        
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), NotificationItemWidget):
                widget = item.widget()
                notif = widget.notification_data
                
                # Check filter
                matches_filter = True
                if self.current_filter == "Unread":
                    matches_filter = not notif.get('read')
                elif self.current_filter == "Today":
                    notif_date = notif['timestamp'].date()
                    matches_filter = notif_date == today
                
                # Check search
                matches_search = True
                if search_text:
                    matches_search = (search_text in notif['title'].lower() or 
                                    search_text in notif['message'].lower() or
                                    search_text in notif['origin'].lower())
                
                if matches_filter and matches_search:
                    widget.show()
                    visible_count += 1
                    if notif['timestamp'].date() == today:
                        today_count += 1
        
        # Update stats
        self.unread_card.value_label.setText(str(self.notification_manager.unread_count))
        self.total_card.value_label.setText(str(len(self.notification_manager.notifications)))
        self.today_card.value_label.setText(str(today_count))
        
        # Update subtitle
        if visible_count == 0:
            self.subtitle_label.setText("No notifications found")
        else:
            self.subtitle_label.setText(f"Showing {visible_count} notification{'s' if visible_count != 1 else ''}")
    
    def add_notification(self, notification_data):
        # Check if empty_state exists and remove it
        empty_state_index = -1
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if widget == self.empty_state:
                empty_state_index = i
                break
        
        if empty_state_index >= 0:
            item = self.scroll_layout.takeAt(empty_state_index)
            if item and item.widget():
                item.widget().hide()
        
        # Create notification widget
        notif_widget = NotificationItemWidget(notification_data, self.dark_mode)
        
        # Get app icon for the notification
        app_icon = self.get_app_icon(notification_data['origin'])
        if app_icon:
            notif_widget.set_app_icon(app_icon)
        
        # Insert at top
        self.scroll_layout.insertWidget(0, notif_widget)
        
        # Update stats
        self.filter_notifications()
    
    def get_app_icon(self, origin):
        """Get app icon based on domain"""
        domain = origin.replace('https://', '').replace('http://', '').split('/')[0]
        
        icon_map = {
            'web.whatsapp.com': 'assets/whatsapp.png',
            'chat.openai.com': 'assets/chatgpt.png',
            'chat.deepseek.com': 'assets/deepseek.png',
            'messages.google.com': 'assets/messages.png',
            'telegram.org': 'assets/telegram.png',
            'discord.com': 'assets/discord.png',
            'slack.com': 'assets/slack.png',
            'teams.microsoft.com': 'assets/teams.png',
            'zoom.us': 'assets/zoom.png',
            'meet.google.com': 'assets/meet.png',
            'facebook.com': 'assets/facebook.png',
            'instagram.com': 'assets/instagram.png',
            'x.com': 'assets/x.png',
            'twitter.com': 'assets/x.png'
        }
        
        for key, icon_path in icon_map.items():
            if key in domain:
                full_path = os.path.join(os.path.dirname(__file__), icon_path)
                if os.path.exists(full_path):
                    return full_path
        return None
    
    def notification_marked_read(self, notif_id):
        self.notification_manager.mark_as_read(notif_id)
        self.filter_notifications()
    
    def notification_deleted(self, notif_id):
        # Find and remove widget
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if isinstance(widget, NotificationItemWidget) and widget.notification_data.get('id') == notif_id:
                widget.deleteLater()
                self.scroll_layout.removeWidget(widget)
                break
        
        # Remove from manager
        self.notification_manager.notifications = [
            n for n in self.notification_manager.notifications 
            if n.get('id') != notif_id
        ]
        
        # Check if we need to show empty state
        has_notifications = False
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if isinstance(widget, NotificationItemWidget):
                has_notifications = True
                break
        
        # Show empty state if no notifications
        if not has_notifications:
            # Check if empty_state is already in layout
            empty_state_exists = False
            for i in range(self.scroll_layout.count()):
                widget = self.scroll_layout.itemAt(i).widget()
                if widget == self.empty_state:
                    empty_state_exists = True
                    break
            
            if not empty_state_exists and self.empty_state:
                self.scroll_layout.addWidget(self.empty_state)
                self.empty_state.show()
        
        self.filter_notifications()
    
    def mark_all_read(self):
        self.notification_manager.mark_all_as_read()
        
        # Update all widgets
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if isinstance(widget, NotificationItemWidget):
                widget.notification_data['read'] = True
                widget.mark_read_btn.setVisible(False)
                widget.unread_dot.hide()
                widget.update_stylesheet()
        
        self.filter_notifications()
    
    def clear_all(self):
        widgets_to_remove = []
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if widget and widget != self.empty_state:
                widgets_to_remove.append(widget)
        
        for widget in widgets_to_remove:
            widget.deleteLater()
            self.scroll_layout.removeWidget(widget)
        
        # Clear manager
        self.notification_manager.clear_all()
        
        # Show empty state
        empty_state_exists = False
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if widget == self.empty_state:
                empty_state_exists = True
                break
        
        if not empty_state_exists and self.empty_state:
            self.scroll_layout.addWidget(self.empty_state)
        
        self.empty_state.show()
        self.filter_notifications()
    
    def show_settings(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Notification Settings")
        dialog.setMinimumWidth(450)
        dialog.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Popup)
        dialog.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Main frame
        main_frame = QFrame()
        main_frame.setObjectName("settingsDialog")
        
        layout = QVBoxLayout(main_frame)
        layout.setSpacing(20)
        layout.setContentsMargins(25, 25, 25, 25)
        
        # Header
        header_layout = QHBoxLayout()
        header_label = QLabel("Notification Settings")
        header_label.setObjectName("settingsHeader")
        header_label_font = QFont("SF Pro Display", 18, QFont.Weight.Bold)
        header_label.setFont(header_label_font)
        
        close_btn = QPushButton("✕")
        close_btn.setObjectName("closeButton")
        close_btn.setFixedSize(32, 32)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(dialog.accept)
        
        header_layout.addWidget(header_label)
        header_layout.addStretch()
        header_layout.addWidget(close_btn)
        layout.addLayout(header_layout)
        
        # Auto-allow domains section
        section_title = QLabel("Auto-Allow Domains")
        section_title.setObjectName("sectionTitle")
        section_title_font = QFont("SF Pro Text", 14, QFont.Weight.DemiBold)  
        section_title.setFont(section_title_font)
        layout.addWidget(section_title)
        
        section_desc = QLabel("Domains that will automatically get notification permission:")
        section_desc.setObjectName("sectionDesc")
        section_desc.setWordWrap(True)
        layout.addWidget(section_desc)
        
        # Domain list
        self.domains_list = QListWidget()
        self.domains_list.setObjectName("domainsList")
        self.domains_list.setMinimumHeight(150)
        self.refresh_domains_list()
        layout.addWidget(self.domains_list)
        
        # Add domain
        add_layout = QHBoxLayout()
        self.domain_input = QLineEdit()
        self.domain_input.setObjectName("domainInput")
        self.domain_input.setPlaceholderText("example.com")
        
        btn_add = QPushButton("Add")
        btn_add.setObjectName("primaryButton")
        btn_add.setFixedHeight(40)
        btn_add.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_add.clicked.connect(self.add_domain)
        
        add_layout.addWidget(self.domain_input)
        add_layout.addWidget(btn_add)
        layout.addLayout(add_layout)
        
        # Remove button
        btn_remove = QPushButton("Remove Selected")
        btn_remove.setObjectName("secondaryButton")
        btn_remove.setFixedHeight(40)
        btn_remove.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_remove.clicked.connect(self.remove_domain)
        layout.addWidget(btn_remove)
        
        # Done button
        btn_done = QPushButton("Done")
        btn_done.setObjectName("primaryButton")
        btn_done.setFixedHeight(44)
        btn_done.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_done.clicked.connect(dialog.accept)
        layout.addWidget(btn_done)
        
        # Main container
        container_layout = QVBoxLayout(dialog)
        container_layout.setContentsMargins(10, 10, 10, 10)
        container_layout.addWidget(main_frame)
        
        # Apply theme
        if self.dark_mode:
            dialog.setStyleSheet("""
                QFrame#settingsDialog {
                    background: #1e1e2e;
                    border-radius: 20px;
                    border: 1px solid #3a3a4a;
                }
                QLabel#settingsHeader {
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                }
                QLabel#sectionTitle {
                    color: white;
                    font-size: 14px;
                    font-weight: 600;
                }
                QLabel#sectionDesc {
                    color: #8e8e93;
                    font-size: 13px;
                }
                QListWidget#domainsList {
                    background: #2a2a3a;
                    color: white;
                    border: 1px solid #3a3a4a;
                    border-radius: 12px;
                    padding: 8px;
                    outline: none;
                }
                QListWidget::item {
                    padding: 10px;
                    border-radius: 8px;
                }
                QListWidget::item:hover {
                    background: #3a3a4a;
                }
                QListWidget::item:selected {
                    background: #0a84ff;
                }
                QLineEdit#domainInput {
                    background: #2a2a3a;
                    color: white;
                    border: 1px solid #3a3a4a;
                    border-radius: 10px;
                    padding: 10px;
                    font-size: 14px;
                }
                QLineEdit#domainInput:focus {
                    border: 2px solid #0a84ff;
                }
                QPushButton#closeButton {
                    background: #2a2a3a;
                    border: none;
                    border-radius: 16px;
                    color: white;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton#closeButton:hover {
                    background: #3a3a4a;
                }
                QPushButton#primaryButton {
                    background: #0a84ff;
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-weight: 600;
                    font-size: 14px;
                    padding: 0 20px;
                }
                QPushButton#primaryButton:hover {
                    background: #409cff;
                }
                QPushButton#primaryButton:pressed {
                    background: #0063ce;
                }
                QPushButton#secondaryButton {
                    background: #2a2a3a;
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-size: 14px;
                    padding: 0 20px;
                }
                QPushButton#secondaryButton:hover {
                    background: #3a3a4a;
                }
            """)
        else:
            dialog.setStyleSheet("""
                QFrame#settingsDialog {
                    background: white;
                    border-radius: 20px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                QLabel#settingsHeader {
                    color: black;
                    font-size: 18px;
                    font-weight: bold;
                }
                QLabel#sectionTitle {
                    color: black;
                    font-size: 14px;
                    font-weight: 600;
                }
                QLabel#sectionDesc {
                    color: #8e8e93;
                    font-size: 13px;
                }
                QListWidget#domainsList {
                    background: #f8f9fa;
                    color: black;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 12px;
                    padding: 8px;
                    outline: none;
                }
                QListWidget::item {
                    padding: 10px;
                    border-radius: 8px;
                }
                QListWidget::item:hover {
                    background: #e5e5ea;
                }
                QListWidget::item:selected {
                    background: #007aff;
                    color: white;
                }
                QLineEdit#domainInput {
                    background: #f8f9fa;
                    color: black;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 10px;
                    padding: 10px;
                    font-size: 14px;
                }
                QLineEdit#domainInput:focus {
                    border: 2px solid #007aff;
                }
                QPushButton#closeButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 16px;
                    color: #007aff;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton#closeButton:hover {
                    background: #e5e5ea;
                }
                QPushButton#primaryButton {
                    background: #007aff;
                    border: none;
                    border-radius: 10px;
                    color: white;
                    font-weight: 600;
                    font-size: 14px;
                    padding: 0 20px;
                }
                QPushButton#primaryButton:hover {
                    background: #005fc7;
                }
                QPushButton#primaryButton:pressed {
                    background: #004299;
                }
                QPushButton#secondaryButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 10px;
                    color: #007aff;
                    font-size: 14px;
                    padding: 0 20px;
                }
                QPushButton#secondaryButton:hover {
                    background: #e5e5ea;
                }
            """)
        
        dialog.exec()
    
    def refresh_domains_list(self):
        self.domains_list.clear()
        for domain in self.notification_manager.auto_allow_domains:
            self.domains_list.addItem(domain)
    
    def add_domain(self):
        domain = self.domain_input.text().strip()
        if domain and domain not in self.notification_manager.auto_allow_domains:
            self.notification_manager.auto_allow_domains.append(domain)
            self.domains_list.addItem(domain)
            self.domain_input.clear()
    
    def remove_domain(self):
        current = self.domains_list.currentItem()
        if current:
            domain = current.text()
            self.notification_manager.auto_allow_domains.remove(domain)
            self.domains_list.takeItem(self.domains_list.row(current))
    
    def refresh_notifications(self):
        widgets_to_remove = []
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if widget and widget != self.empty_state:
                widgets_to_remove.append(widget)
        
        for widget in widgets_to_remove:
            widget.deleteLater()
            self.scroll_layout.removeWidget(widget)
        
        # Add notifications
        if self.notification_manager.notifications:
            # Hide empty state if it exists
            if self.empty_state in [self.scroll_layout.itemAt(i).widget() for i in range(self.scroll_layout.count())]:
                self.empty_state.hide()
            
            # Add all notifications
            for notif in self.notification_manager.notifications:
                widget = NotificationItemWidget(notif, self.dark_mode)
                
                # Set app icon
                app_icon = self.get_app_icon(notif['origin'])
                if app_icon:
                    widget.set_app_icon(app_icon)
                
                self.scroll_layout.addWidget(widget)
        else:
            empty_state_exists = False
            for i in range(self.scroll_layout.count()):
                widget = self.scroll_layout.itemAt(i).widget()
                if widget == self.empty_state:
                    empty_state_exists = True
                    break
            
            if not empty_state_exists and self.empty_state:
                self.scroll_layout.addWidget(self.empty_state)
            
            self.empty_state.show()
        
        self.filter_notifications()
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_stylesheet()
        
        # Update all notification widgets
        for i in range(self.scroll_layout.count()):
            widget = self.scroll_layout.itemAt(i).widget()
            if isinstance(widget, NotificationItemWidget):
                widget.set_dark_mode(dark)
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QFrame#notificationsHeader {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 #1e1e2e, stop:1 #2a2a3a);
                    border-bottom: 1px solid #3a3a4a;
                }
                
                QFrame#notificationsToolbar {
                    background: #1e1e2e;
                    border-bottom: 1px solid #2a2a3a;
                }
                
                QFrame#searchContainer {
                    background: #1e1e2e;
                    border-bottom: 1px solid #2a2a3a;
                }
                
                QFrame#filterChipsContainer {
                    background: transparent;
                }
                
                QPushButton#filterChip {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 18px;
                    color: #8e8e93;
                    padding: 0 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                
                QPushButton#filterChip:hover {
                    background: #3a3a4a;
                }
                
                QPushButton#filterChip:checked {
                    background: #0a84ff;
                    border-color: #0a84ff;
                    color: white;
                }
                
                QPushButton#actionButton {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 10px;
                    color: white;
                    padding: 8px 16px;
                    font-size: 13px;
                    font-weight: 500;
                }
                
                QPushButton#actionButton:hover {
                    background: #3a3a4a;
                }
                
                QPushButton#iconButton {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 10px;
                    color: white;
                }
                
                QPushButton#iconButton:hover {
                    background: #3a3a4a;
                }
                
                QFrame#searchContainer {
                    background: #1e1e2e;
                    border-bottom: 1px solid #2a2a3a;
                }
                
                QLabel#searchIcon {
                    color: #8e8e93;
                    font-size: 16px;
                }
                
                QLineEdit#searchInput {
                    background: transparent;
                    border: none;
                    color: white;
                    font-size: 14px;
                }
                
                QLineEdit#searchInput::placeholder {
                    color: #8e8e93;
                }
                
                QLabel#mainTitle {
                    color: white;
                    font-size: 32px;
                    font-weight: bold;
                }
                
                QLabel#subtitleLabel {
                    color: #8e8e93;
                    font-size: 14px;
                }
                
                QFrame#headerIconFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #0a84ff, stop:1 #5856d6);
                    border-radius: 15px;
                }
                
                QLabel#headerIcon {
                    color: white;
                }
                
                QFrame#statCard {
                    background: #2a2a3a;
                    border-radius: 16px;
                    border: 1px solid #3a3a4a;
                }
                
                QLabel#statIcon {
                    font-size: 20px;
                    color: #0a84ff;
                }
                
                QLabel#statValue {
                    color: white;
                    font-size: 20px;
                    font-weight: bold;
                }
                
                QLabel#statLabel {
                    color: #8e8e93;
                    font-size: 12px;
                }
                
                QScrollArea {
                    background: #1a1a2e;
                    border: none;
                }
                
                QWidget#scrollContent {
                    background: #1a1a2e;
                }
                
                QFrame#emptyState {
                    background: transparent;
                }
                
                QLabel#emptyIcon {
                    color: #3a3a4a;
                    font-size: 64px;
                }
                
                QLabel#emptyTitle {
                    color: #8e8e93;
                    font-size: 20px;
                    font-weight: 500;
                }
                
                QLabel#emptyDesc {
                    color: #6a6a7a;
                    font-size: 14px;
                }
                
                QScrollBar:vertical {
                    background: #2a2a3a;
                    width: 8px;
                    border-radius: 4px;
                }
                
                QScrollBar::handle:vertical {
                    background: #4a4a5a;
                    border-radius: 4px;
                    min-height: 20px;
                }
                
                QScrollBar::handle:vertical:hover {
                    background: #5a5a6a;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame#notificationsHeader {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 #f8f9fa, stop:1 #ffffff);
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#notificationsToolbar {
                    background: #ffffff;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#searchContainer {
                    background: #ffffff;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#filterChipsContainer {
                    background: transparent;
                }
                
                QPushButton#filterChip {
                    background: #f2f2f7;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 18px;
                    color: #8e8e93;
                    padding: 0 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                
                QPushButton#filterChip:hover {
                    background: #e5e5ea;
                }
                
                QPushButton#filterChip:checked {
                    background: #007aff;
                    border-color: #007aff;
                    color: white;
                }
                
                QPushButton#actionButton {
                    background: #f2f2f7;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 10px;
                    color: #007aff;
                    padding: 8px 16px;
                    font-size: 13px;
                    font-weight: 500;
                }
                
                QPushButton#actionButton:hover {
                    background: #e5e5ea;
                }
                
                QPushButton#iconButton {
                    background: #f2f2f7;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 10px;
                    color: #007aff;
                }
                
                QPushButton#iconButton:hover {
                    background: #e5e5ea;
                }
                
                QFrame#searchContainer {
                    background: #ffffff;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QLabel#searchIcon {
                    color: #8e8e93;
                    font-size: 16px;
                }
                
                QLineEdit#searchInput {
                    background: transparent;
                    border: none;
                    color: black;
                    font-size: 14px;
                }
                
                QLineEdit#searchInput::placeholder {
                    color: #8e8e93;
                }
                
                QLabel#mainTitle {
                    color: black;
                    font-size: 32px;
                    font-weight: bold;
                }
                
                QLabel#subtitleLabel {
                    color: #8e8e93;
                    font-size: 14px;
                }
                
                QFrame#headerIconFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #007aff, stop:1 #5856d6);
                    border-radius: 15px;
                }
                
                QLabel#headerIcon {
                    color: white;
                }
                
                QFrame#statCard {
                    background: #ffffff;
                    border-radius: 16px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QLabel#statIcon {
                    font-size: 20px;
                    color: #007aff;
                }
                
                QLabel#statValue {
                    color: black;
                    font-size: 20px;
                    font-weight: bold;
                }
                
                QLabel#statLabel {
                    color: #8e8e93;
                    font-size: 12px;
                }
                
                QScrollArea {
                    background: #f8f9fa;
                    border: none;
                }
                
                QWidget#scrollContent {
                    background: #f8f9fa;
                }
                
                QFrame#emptyState {
                    background: transparent;
                }
                
                QLabel#emptyIcon {
                    color: #e5e5ea;
                    font-size: 64px;
                }
                
                QLabel#emptyTitle {
                    color: #8e8e93;
                    font-size: 20px;
                    font-weight: 500;
                }
                
                QLabel#emptyDesc {
                    color: #aeaeb2;
                    font-size: 14px;
                }
                
                QScrollBar:vertical {
                    background: transparent;
                    width: 8px;
                    border-radius: 4px;
                }
                
                QScrollBar::handle:vertical {
                    background: #c1c1c1;
                    border-radius: 4px;
                    min-height: 20px;
                }
                
                QScrollBar::handle:vertical:hover {
                    background: #a8a8a8;
                }
            """)

class TodoItem:
    def __init__(self, text, completed=False):
        self.text = text
        self.completed = completed
        self.created = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")

class NotesWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.notes = []
        self.current_note_index = -1
        self.dark_mode = False
        self.load_notes()
        if len(self.notes) == 0:
            self.create_default_note()
        
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        toolbar = QFrame()
        toolbar.setObjectName("notesToolbar")
        toolbar.setFixedHeight(64)
        toolbar_layout = QHBoxLayout()
        toolbar_layout.setContentsMargins(20, 0, 20, 0)
        toolbar_layout.setSpacing(12)
            
        self.btn_new_note = QPushButton("➕ New Note")
        self.btn_new_note.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_new_note.clicked.connect(self.new_note)
        
        self.btn_new_todo = QPushButton("✅ New Todo")
        self.btn_new_todo.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_new_todo.clicked.connect(self.new_todo)
        
        self.btn_delete = QPushButton("🗑️ Delete")
        self.btn_delete.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_delete.clicked.connect(self.delete_note)
        
        self.category_combo = QComboBox()
        self.category_combo.addItems(["All Notes", "General", "Work", "Personal", "Ideas", "Todo"])
        self.category_combo.setMinimumWidth(130)
        self.category_combo.currentTextChanged.connect(self.filter_notes)
        
        self.btn_save = QPushButton("💾 Save")
        self.btn_save.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_save.clicked.connect(self.save_current_note)
        self.btn_save.setFixedWidth(90)
        
        toolbar_layout.addWidget(self.btn_new_note)
        toolbar_layout.addWidget(self.btn_new_todo)
        toolbar_layout.addWidget(self.btn_delete)
        toolbar_layout.addStretch()
        toolbar_layout.addWidget(QLabel("Filter:"))
        toolbar_layout.addWidget(self.category_combo)
        toolbar_layout.addWidget(self.btn_save)
        toolbar.setLayout(toolbar_layout)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(1)
        
        list_panel = QWidget()
        list_layout = QVBoxLayout()
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.setSpacing(0)
        
        search_container = QFrame()
        search_container.setObjectName("searchContainer")
        search_container.setFixedHeight(50)
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(15, 0, 15, 0)
        
        self.search_icon = QLabel("🔍")
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search notes...")
        self.search_input.textChanged.connect(self.filter_notes)
        
        search_layout.addWidget(self.search_icon)
        search_layout.addWidget(self.search_input)
        search_container.setLayout(search_layout)
        list_layout.addWidget(search_container)
        
        self.notes_list = QListWidget()
        self.notes_list.setMinimumWidth(280)
        self.notes_list.setMaximumWidth(350)
        self.notes_list.setSpacing(2)
        self.notes_list.itemClicked.connect(self.note_selected)
        list_layout.addWidget(self.notes_list)
        
        list_panel.setLayout(list_layout)
        
        self.editor_widget = QWidget()
        editor_layout = QVBoxLayout()
        editor_layout.setContentsMargins(25, 25, 25, 25)
        editor_layout.setSpacing(20)
        
        title_container = QFrame()
        title_container.setObjectName("titleContainer")
        title_layout = QVBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(8)
        
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Note Title")
        self.title_edit.setFixedHeight(50)
        
        meta_layout = QHBoxLayout()
        meta_layout.setSpacing(15)
        self.created_label = QLabel("Created: -")
        self.created_label.setObjectName("metaLabel")
        self.modified_label = QLabel("Modified: -")
        self.modified_label.setObjectName("metaLabel")
        meta_layout.addWidget(self.created_label)
        meta_layout.addWidget(self.modified_label)
        meta_layout.addStretch()
        
        title_layout.addWidget(self.title_edit)
        title_layout.addLayout(meta_layout)
        title_container.setLayout(title_layout)
        
        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("Write your note here...")
        self.content_edit.textChanged.connect(self.on_content_changed)
        self.title_edit.textChanged.connect(self.on_title_changed)
        
        self.todo_widget = QWidget()
        todo_layout = QVBoxLayout()
        todo_layout.setContentsMargins(0, 0, 0, 0)
        todo_layout.setSpacing(15)
        
        todo_header = QLabel("Todo List")
        todo_header.setObjectName("todoHeader")
        
        self.todo_input = QLineEdit()
        self.todo_input.setPlaceholderText("Add new todo item and press Enter...")
        self.todo_input.setFixedHeight(45)
        self.todo_input.returnPressed.connect(self.add_todo_item)
        
        todo_stats = QHBoxLayout()
        self.todo_stats_label = QLabel("0 items")
        self.todo_stats_label.setObjectName("todoStats")
        self.clear_completed_btn = QPushButton("Clear Completed")
        self.clear_completed_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.clear_completed_btn.clicked.connect(self.clear_completed_todos)
        self.clear_completed_btn.setVisible(False)
        todo_stats.addWidget(self.todo_stats_label)
        todo_stats.addStretch()
        todo_stats.addWidget(self.clear_completed_btn)
        
        self.todo_list = QListWidget()
        self.todo_list.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        self.todo_list.setSpacing(5)
        
        todo_layout.addWidget(todo_header)
        todo_layout.addWidget(self.todo_input)
        todo_layout.addLayout(todo_stats)
        todo_layout.addWidget(self.todo_list)
        self.todo_widget.setLayout(todo_layout)
        self.todo_widget.hide()
        
        editor_layout.addWidget(title_container)
        editor_layout.addWidget(self.content_edit)
        editor_layout.addWidget(self.todo_widget)
        self.editor_widget.setLayout(editor_layout)
        
        splitter.addWidget(list_panel)
        splitter.addWidget(self.editor_widget)
        splitter.setSizes([300, 700])
        
        main_layout.addWidget(toolbar)
        main_layout.addWidget(splitter)
        
        self.setLayout(main_layout)
        self.auto_save_timer = QTimer()
        self.auto_save_timer.setSingleShot(True)
        self.auto_save_timer.timeout.connect(self.save_current_note)
        self.auto_save_delay = 1000
        if self.notes:
            self.current_note_index = 0
            self.display_note(self.notes[0])
        
        self.refresh_notes_list()
        self.update_stylesheet()
        self.installEventFilter(self)
    
    def eventFilter(self, obj, event):
        if event.type() == event.Type.KeyPress:
            if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
                if event.key() == Qt.Key.Key_N:
                    self.new_note()
                    return True
                elif event.key() == Qt.Key.Key_S:
                    self.save_current_note()
                    return True
        return super().eventFilter(obj, event)
    
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            if event.key() == Qt.Key.Key_N:
                self.new_note()
                event.accept()
                return
            elif event.key() == Qt.Key.Key_S:
                self.save_current_note()
                event.accept()
                return
        super().keyPressEvent(event)
    
    def create_default_note(self):
        default_note = Note(
            title="Welcome to Alin Vault Notes",
            content="Welcome to your notes section!\n\n"
                   "Features:\n"
                   "• Auto-save - Your notes are saved automatically\n"
                   "• Keyboard shortcuts: Ctrl+N (new note), Ctrl+S (save)\n"
                   "• Multiple categories\n"
                   "• Search functionality\n"
                   "• Dark/Light theme support\n\n"
                   "Start writing your first note!",
            category="General"
        )
        self.notes.append(default_note)
        self.save_notes()
    
    def on_content_changed(self):
        if self.current_note_index >= 0:
            self.auto_save_timer.start(self.auto_save_delay)
    
    def on_title_changed(self):
        if self.current_note_index >= 0:
            self.auto_save_timer.start(self.auto_save_delay)
    
    def load_notes(self):
        try:
            if os.path.exists(NOTES_FILE):
                with open(NOTES_FILE, 'rb') as f:
                    self.notes = pickle.load(f)
        except Exception:
            self.notes = []
    
    def save_notes(self):
        try:
            with open(NOTES_FILE, 'wb') as f:
                pickle.dump(self.notes, f)
        except Exception:
            pass
    
    def new_note(self):
        note = Note(title="Untitled Note", content="", category="General")
        self.notes.append(note)
        self.current_note_index = len(self.notes) - 1
        self.refresh_notes_list()
        self.display_note(note)
        self.save_notes()
        self.title_edit.setFocus()
        self.title_edit.selectAll()
    
    def new_todo(self):
        note = Note(title="Todo List", content="", category="Todo", is_todo=True)
        self.notes.append(note)
        self.current_note_index = len(self.notes) - 1
        self.refresh_notes_list()
        self.display_note(note)
        self.save_notes()
        self.todo_input.setFocus()
    
    def delete_note(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            reply = QMessageBox.question(
                self, "Delete Note",
                "Are you sure you want to delete this note?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.notes.pop(self.current_note_index)
                self.current_note_index = -1
                self.refresh_notes_list()
                self.title_edit.clear()
                self.content_edit.clear()
                self.todo_list.clear()
                self.todo_widget.hide()
                self.content_edit.show()
                self.created_label.setText("Created: -")
                self.modified_label.setText("Modified: -")
                self.save_notes()
    
    def save_current_note(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            note.title = self.title_edit.text() or "Untitled Note"
            if note.is_todo:
                note.content = json.dumps([{"text": item.text, "completed": item.completed} 
                                         for item in note.todo_items])
            else:
                note.content = self.content_edit.toPlainText()
            note.modified = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
            self.modified_label.setText(f"Modified: {note.modified}")
            self.save_notes()
            self.refresh_notes_list()
            original_text = self.btn_save.text()
            self.btn_save.setText("✓ Saved!")
            QTimer.singleShot(1000, lambda: self.btn_save.setText(original_text))
    
    def note_selected(self, item):
        row = self.notes_list.row(item)
        if row < len(self.notes):
            self.current_note_index = row
            self.display_note(self.notes[row])
    
    def display_note(self, note):
        self.title_edit.setText(note.title)
        self.created_label.setText(f"Created: {note.created}")
        self.modified_label.setText(f"Modified: {note.modified}")
        
        if note.is_todo:
            self.content_edit.hide()
            self.todo_widget.show()
            self.todo_list.clear()
            
            if note.content:
                try:
                    items = json.loads(note.content)
                    note.todo_items = []
                    for item in items:
                        todo_item = TodoItem(item["text"], item["completed"])
                        note.todo_items.append(todo_item)
                        self.add_todo_item_to_list(todo_item)
                except:
                    note.todo_items = []
            self.update_todo_stats()
        else:
            self.todo_widget.hide()
            self.content_edit.show()
            self.content_edit.setText(note.content)
    
    def add_todo_item(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            if note.is_todo:
                text = self.todo_input.text().strip()
                if text:
                    item = TodoItem(text)
                    note.todo_items.append(item)
                    self.add_todo_item_to_list(item)
                    self.todo_input.clear()
                    self.update_todo_stats()
                    self.save_notes()
    
    def add_todo_item_to_list(self, todo_item):
        item_widget = QWidget()
        item_widget.setObjectName("todoItem")
        layout = QHBoxLayout()
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(12)
        
        checkbox = QCheckBox()
        checkbox.setChecked(todo_item.completed)
        checkbox.stateChanged.connect(lambda state, t=todo_item: self.toggle_todo(t, state))
        
        text_label = QLabel(todo_item.text)
        text_label.setWordWrap(True)
        if todo_item.completed:
            text_label.setStyleSheet("text-decoration: line-through; color: #8e8e93;")
        
        delete_btn = QPushButton("✕")
        delete_btn.setFixedSize(28, 28)
        delete_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        delete_btn.clicked.connect(lambda: self.delete_todo_item(todo_item))
        delete_btn.setObjectName("todoDeleteBtn")
        
        layout.addWidget(checkbox)
        layout.addWidget(text_label, 1)
        layout.addWidget(delete_btn)
        
        item_widget.setLayout(layout)
        
        list_item = QListWidgetItem(self.todo_list)
        list_item.setSizeHint(item_widget.sizeHint())
        self.todo_list.addItem(list_item)
        self.todo_list.setItemWidget(list_item, item_widget)
    
    def toggle_todo(self, todo_item, state):
        todo_item.completed = (state == Qt.CheckState.Checked.value)
        self.save_notes()
        self.refresh_todo_display()
        self.update_todo_stats()
    
    def delete_todo_item(self, todo_item):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            if todo_item in note.todo_items:
                note.todo_items.remove(todo_item)
                self.refresh_todo_display()
                self.update_todo_stats()
                self.save_notes()
    
    def clear_completed_todos(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            note.todo_items = [item for item in note.todo_items if not item.completed]
            self.refresh_todo_display()
            self.update_todo_stats()
            self.save_notes()
    
    def update_todo_stats(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            if note.is_todo:
                total = len(note.todo_items)
                completed = sum(1 for item in note.todo_items if item.completed)
                self.todo_stats_label.setText(f"{completed}/{total} completed")
                self.clear_completed_btn.setVisible(completed > 0)
    
    def refresh_todo_display(self):
        if self.current_note_index >= 0 and self.current_note_index < len(self.notes):
            note = self.notes[self.current_note_index]
            if note.is_todo:
                self.todo_list.clear()
                for item in note.todo_items:
                    self.add_todo_item_to_list(item)
    
    def filter_notes(self):
        filter_text = self.search_input.text().lower() if hasattr(self, 'search_input') else ""
        category = self.category_combo.currentText()
        self.refresh_notes_list(category, filter_text)
    
    def refresh_notes_list(self, category="All Notes", search_text=""):
        self.notes_list.clear()
        
        filter_category = category if category != "All Notes" else "All"
        
        for i, note in enumerate(self.notes):
            if filter_category != "All" and filter_category != note.category:
                continue
            
            if search_text:
                if search_text not in note.title.lower() and search_text not in note.content.lower():
                    continue
            
            item_text = f"{note.title}"
            
            if note.category != "General":
                item_text += f"  •  {note.category}"
            
            item_text += f"\n{note.modified}"
            
            item = QListWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole, i)
            
            if note.is_todo:
                item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogApplyButton))
            else:
                item.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
            
            self.notes_list.addItem(item)
            self.notes_list.item(i).setText(item_text)
        if self.current_note_index >= 0 and self.current_note_index < self.notes_list.count():
            self.notes_list.setCurrentRow(self.current_note_index)
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_stylesheet()
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QFrame#notesToolbar {
                    background: rgba(30, 30, 46, 0.98);
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                QFrame#searchContainer {
                    background: #2a2a3a;
                    border-bottom: 1px solid #3a3a4a;
                }
                
                QFrame#titleContainer {
                    background: transparent;
                }
                
                QListWidget {
                    background: #1e1e2e;
                    border: none;
                    color: #ffffff;
                    outline: none;
                    font-size: 14px;
                }
                
                QListWidget::item {
                    padding: 15px;
                    border-bottom: 1px solid #2a2a3a;
                }
                
                QListWidget::item:selected {
                    background: #0f3460;
                }
                
                QListWidget::item:hover {
                    background: #2a2a3a;
                }
                
                QLineEdit, QTextEdit {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 12px;
                    color: #ffffff;
                    padding: 12px 15px;
                    font-size: 15px;
                }
                
                QLineEdit:focus, QTextEdit:focus {
                    border: 1px solid #0a84ff;
                }
                
                QComboBox {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 10px;
                    color: #ffffff;
                    padding: 8px 15px;
                    min-width: 130px;
                }
                
                QComboBox::drop-down {
                    border: none;
                    width: 30px;
                }
                
                QComboBox::down-arrow {
                    image: none;
                    border-left: 5px solid transparent;
                    border-right: 5px solid transparent;
                    border-top: 5px solid #ffffff;
                }
                
                QComboBox QAbstractItemView {
                    background: #2a2a3a;
                    color: #ffffff;
                    selection-background-color: #0f3460;
                }
                
                QCheckBox {
                    color: #ffffff;
                    spacing: 8px;
                }
                
                QCheckBox::indicator {
                    width: 22px;
                    height: 22px;
                    border-radius: 6px;
                }
                
                QCheckBox::indicator:unchecked {
                    border: 2px solid #3a3a4a;
                    background: #2a2a3a;
                }
                
                QCheckBox::indicator:checked {
                    border: 2px solid #0a84ff;
                    background: #0a84ff;
                }
                
                QSplitter::handle {
                    background: #2a2a3a;
                }
                
                QLabel#metaLabel {
                    color: #8e8e93;
                    font-size: 12px;
                }
                
                QLabel#todoHeader {
                    color: #ffffff;
                    font-size: 20px;
                    font-weight: 600;
                    padding: 10px 0;
                }
                
                QLabel#todoStats {
                    color: #8e8e93;
                    font-size: 13px;
                }
                
                QFrame#todoItem {
                    background: #2a2a3a;
                    border-radius: 10px;
                }
                
                QPushButton#todoDeleteBtn {
                    background: transparent;
                    border: none;
                    color: #ff453a;
                    font-size: 16px;
                    font-weight: bold;
                }
                
                QPushButton#todoDeleteBtn:hover {
                    background: rgba(255, 69, 58, 0.2);
                    border-radius: 14px;
                }
            """)
            
            button_style = """
                QPushButton {
                    background: #2a2a3a;
                    border: none;
                    border-radius: 10px;
                    color: #ffffff;
                    padding: 8px 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #3a3a4a;
                }
                QPushButton:pressed {
                    background: #1a1a2a;
                }
            """
            
            delete_button_style = """
                QPushButton {
                    background: rgba(255, 69, 58, 0.2);
                    border: none;
                    border-radius: 10px;
                    color: #ff453a;
                    padding: 8px 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: rgba(255, 69, 58, 0.3);
                }
                QPushButton:pressed {
                    background: rgba(255, 69, 58, 0.4);
                }
            """
            
            save_button_style = """
                QPushButton {
                    background: #0a84ff;
                    border: none;
                    border-radius: 10px;
                    color: #ffffff;
                    padding: 8px 20px;
                    font-size: 14px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: #409cff;
                }
                QPushButton:pressed {
                    background: #0063ce;
                }
            """
            
        else:
            self.setStyleSheet("""
                QFrame#notesToolbar {
                    background: rgba(255, 255, 255, 0.98);
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#searchContainer {
                    background: #f8f9fa;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#titleContainer {
                    background: transparent;
                }
                
                QListWidget {
                    background: #ffffff;
                    border: none;
                    color: #000000;
                    outline: none;
                    font-size: 14px;
                }
                
                QListWidget::item {
                    padding: 15px;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QListWidget::item:selected {
                    background: #e5e5ea;
                }
                
                QListWidget::item:hover {
                    background: #f2f2f7;
                }
                
                QLineEdit, QTextEdit {
                    background: #f8f9fa;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 12px;
                    color: #000000;
                    padding: 12px 15px;
                    font-size: 15px;
                }
                
                QLineEdit:focus, QTextEdit:focus {
                    border: 1px solid #007aff;
                }
                
                QComboBox {
                    background: #f8f9fa;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 10px;
                    color: #000000;
                    padding: 8px 15px;
                    min-width: 130px;
                }
                
                QComboBox::drop-down {
                    border: none;
                    width: 30px;
                }
                
                QComboBox::down-arrow {
                    image: none;
                    border-left: 5px solid transparent;
                    border-right: 5px solid transparent;
                    border-top: 5px solid #8e8e93;
                }
                
                QComboBox QAbstractItemView {
                    background: #ffffff;
                    color: #000000;
                    selection-background-color: #e5e5ea;
                }
                
                QCheckBox {
                    color: #000000;
                    spacing: 8px;
                }
                
                QCheckBox::indicator {
                    width: 22px;
                    height: 22px;
                    border-radius: 6px;
                }
                
                QCheckBox::indicator:unchecked {
                    border: 2px solid rgba(60, 60, 67, 0.2);
                    background: #ffffff;
                }
                
                QCheckBox::indicator:checked {
                    border: 2px solid #007aff;
                    background: #007aff;
                }
                
                QSplitter::handle {
                    background: rgba(60, 60, 67, 0.1);
                }
                
                QLabel#metaLabel {
                    color: #8e8e93;
                    font-size: 12px;
                }
                
                QLabel#todoHeader {
                    color: #000000;
                    font-size: 20px;
                    font-weight: 600;
                    padding: 10px 0;
                }
                
                QLabel#todoStats {
                    color: #8e8e93;
                    font-size: 13px;
                }
                
                QFrame#todoItem {
                    background: #f8f9fa;
                    border-radius: 10px;
                }
                
                QPushButton#todoDeleteBtn {
                    background: transparent;
                    border: none;
                    color: #ff3b30;
                    font-size: 16px;
                    font-weight: bold;
                }
                
                QPushButton#todoDeleteBtn:hover {
                    background: rgba(255, 59, 48, 0.1);
                    border-radius: 14px;
                }
            """)
            
            button_style = """
                QPushButton {
                    background: #f8f9fa;
                    border: none;
                    border-radius: 10px;
                    color: #007aff;
                    padding: 8px 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:pressed {
                    background: #d1d1d6;
                }
            """
            
            delete_button_style = """
                QPushButton {
                    background: #f8f9fa;
                    border: none;
                    border-radius: 10px;
                    color: #ff3b30;
                    padding: 8px 16px;
                    font-size: 14px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #ffe5e5;
                }
                QPushButton:pressed {
                    background: #ffcccc;
                }
            """
            
            save_button_style = """
                QPushButton {
                    background: #007aff;
                    border: none;
                    border-radius: 10px;
                    color: #ffffff;
                    padding: 8px 20px;
                    font-size: 14px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: #005fc7;
                }
                QPushButton:pressed {
                    background: #004299;
                }
            """
        
        for btn in [self.btn_new_note, self.btn_new_todo, self.btn_delete, self.btn_save]:
            if btn == self.btn_delete:
                btn.setStyleSheet(delete_button_style)
            elif btn == self.btn_save:
                btn.setStyleSheet(save_button_style)
            else:
                btn.setStyleSheet(button_style)
        
        if hasattr(self, 'clear_completed_btn'):
            self.clear_completed_btn.setStyleSheet(button_style)

def check_dependencies():
    missing = []
    if sys.platform == "win32":
        if not WIN32_AVAILABLE:
            missing.append("pywin32")
    
    if missing:
        print("\n" + "="*50)
        print("WARNING: Missing dependencies!")
        print("Please install the following packages:")
        for pkg in missing:
            print(f"  - {pkg}")
        print("\nRun: pip install " + " ".join(missing))
        print("="*50 + "\n")
        return False
    return True

class DownloadManager:
    def __init__(self):
        self.download_path = self.get_download_path()
        self.ensure_download_folder()
        self.downloads = {}
        self.progress_bars = {}
        
    def get_download_path(self):
        home = os.path.expanduser("~")
        if sys.platform == "win32":
            import ctypes.wintypes
            try:
                CSIDL_PROFILE = 40
                SHGFP_TYPE_CURRENT = 0
                buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
                ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PROFILE, None, SHGFP_TYPE_CURRENT, buf)
                profile_path = buf.value
                downloads_path = os.path.join(profile_path, "Downloads")
                if os.path.exists(downloads_path):
                    return os.path.join(downloads_path, "Alin Vault")
            except:
                pass
            return os.path.join(home, "Downloads", "Alin Vault")
        elif sys.platform == "darwin":
            return os.path.join(home, "Downloads", "Alin Vault")
        else:
            return os.path.join(home, "Downloads", "Alin Vault")
    
    def ensure_download_folder(self):
        if not os.path.exists(self.download_path):
            os.makedirs(self.download_path)
            
    def handle_download(self, download):
        suggested_filename = download.suggestedFileName()
        if not suggested_filename:
            suggested_filename = f"download_{QDateTime.currentDateTime().toString('yyyyMMdd_hhmmss')}"
            
        file_path = os.path.join(self.download_path, suggested_filename)
        
        counter = 1
        base_path = file_path
        while os.path.exists(file_path):
            name, ext = os.path.splitext(base_path)
            file_path = f"{name}_{counter}{ext}"
            counter += 1
            
        download.setDownloadDirectory(self.download_path)
        download.setDownloadFileName(os.path.basename(file_path))
        
        download_id = id(download)
        self.downloads[download_id] = download
        self.progress_bars[download_id] = None
        
        download.receivedBytesChanged.connect(lambda: self.update_progress(download))
        download.receivedBytesChanged.connect(lambda: self.on_progress(download_id, download.receivedBytes(), download.totalBytes()))
        download.accept()
        
        download.stateChanged.connect(lambda state: self.on_download_state_changed(state, download))
        
    def update_progress(self, download):
        try:
            download_id = id(download)
            received = download.receivedBytes()
            total = download.totalBytes()
            if total > 0:
                progress = (received / total) * 100
        except Exception:
            pass
    
    def on_progress(self, download_id, received, total):
        if total > 0:
            progress = (received / total) * 100
        
    def on_download_state_changed(self, state, download):
        try:
            download_id = id(download)
            if state == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                if download_id in self.downloads:
                    del self.downloads[download_id]
                if download_id in self.progress_bars:
                    del self.progress_bars[download_id]
            elif state == QWebEngineDownloadRequest.DownloadState.DownloadInterrupted:
                if download_id in self.downloads:
                    del self.downloads[download_id]
                if download_id in self.progress_bars:
                    del self.progress_bars[download_id]
        except Exception:
            pass

class DownloadProgressDialog(QDialog):
    def __init__(self, filename, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Downloading...")
        self.setFixedSize(420, 180)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Popup)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        main_frame = QFrame()
        main_frame.setObjectName("downloadDialog")
        main_frame.setStyleSheet("""
            QFrame#downloadDialog {
                background: rgba(255, 255, 255, 0.98);
                border-radius: 20px;
                border: 1px solid rgba(0, 0, 0, 0.1);
            }
            QLabel {
                color: #1c1c1e;
                font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', sans-serif;
            }
            QLabel#titleLabel {
                font-size: 16px;
                color: #000000;
            }
            QLabel#filenameLabel {
                font-size: 13px;
                color: #8e8e93;
            }
            QProgressBar {
                border: none;
                background: #e9e9ed;
                border-radius: 6px;
                height: 12px;
            }
            QProgressBar::chunk {
                background: #007aff;
                border-radius: 6px;
            }
            QPushButton {
                background: #f2f2f7;
                border: none;
                border-radius: 10px;
                padding: 8px 16px;
                font-size: 14px;
                color: #007aff;
            }
            QPushButton:hover {
                background: #e5e5ea;
            }
            QPushButton:pressed {
                background: #d1d1d6;
            }
        """)
        
        layout = QVBoxLayout(main_frame)
        layout.setContentsMargins(25, 20, 25, 20)
        layout.setSpacing(12)
        
        title_label = QLabel("Downloading to Alin Vault")
        title_label.setObjectName("titleLabel")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)
        
        self.filename_label = QLabel(os.path.basename(filename))
        self.filename_label.setObjectName("filenameLabel")
        self.filename_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.filename_label.setWordWrap(True)
        layout.addWidget(self.filename_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)
        
        info_layout = QHBoxLayout()
        self.speed_label = QLabel("Starting...")
        self.speed_label.setStyleSheet("color: #8e8e93; font-size: 12px;")
        self.percent_label = QLabel("0%")
        self.percent_label.setStyleSheet("color: #007aff; font-size: 12px;")
        info_layout.addWidget(self.speed_label)
        info_layout.addStretch()
        info_layout.addWidget(self.percent_label)
        layout.addLayout(info_layout)
        
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)
        layout.addLayout(button_layout)
        
        container_layout = QVBoxLayout(self)
        container_layout.setContentsMargins(10, 10, 10, 10)
        container_layout.addWidget(main_frame)
        
        self.start_time = time.time()
        self.last_received = 0
        
    def update_progress(self, received, total):
        percent = (received / total) * 100
        self.progress_bar.setValue(int(percent))
        self.percent_label.setText(f"{int(percent)}%")
        
        elapsed = time.time() - self.start_time
        if elapsed > 0:
            speed = received / elapsed / 1024
            if speed > 1024:
                speed_text = f"{speed/1024:.1f} MB/s"
            else:
                speed_text = f"{speed:.1f} KB/s"
            self.speed_label.setText(speed_text)
        
        if received >= total:
            self.speed_label.setText("Complete!")
            QTimer.singleShot(1500, self.accept)

class EnhancedDownloadManager(DownloadManager):
    def __init__(self):
        super().__init__()
        self.active_dialogs = {}
        self.completed_downloads = []
        self.system_tray = None
        
    def set_system_tray(self, tray):
        self.system_tray = tray
        
    def handle_download(self, download):
        suggested_filename = download.suggestedFileName()
        if not suggested_filename:
            suggested_filename = f"download_{QDateTime.currentDateTime().toString('yyyyMMdd_hhmmss')}"
            
        file_path = os.path.join(self.download_path, suggested_filename)
        
        counter = 1
        base_path = file_path
        while os.path.exists(file_path):
            name, ext = os.path.splitext(base_path)
            file_path = f"{name}_{counter}{ext}"
            counter += 1
            
        download.setDownloadDirectory(self.download_path)
        download.setDownloadFileName(os.path.basename(file_path))
        
        download_id = id(download)
        self.downloads[download_id] = download
        self.progress_bars[download_id] = None
        
        dialog = DownloadProgressDialog(file_path)
        dialog.show()
        
        self.active_dialogs[download_id] = {
            'dialog': dialog,
            'filename': os.path.basename(file_path),
            'download': download
        }
        
        download.receivedBytesChanged.connect(lambda: self.update_progress(download))
        download.receivedBytesChanged.connect(
            lambda: self.update_progress_dialog(download_id, download.receivedBytes(), download.totalBytes())
        )
        download.accept()
        
        download.stateChanged.connect(
            lambda state: self.on_download_state_changed_enhanced(state, download, download_id)
        )
        
    def update_progress(self, download):
        try:
            download_id = id(download)
            received = download.receivedBytes()
            total = download.totalBytes()
            if total > 0:
                progress = (received / total) * 100
        except Exception:
            pass
    
    def on_progress(self, download_id, received, total):
        if total > 0:
            progress = (received / total) * 100
        
    def update_progress_dialog(self, download_id, received, total):
        if download_id in self.active_dialogs:
            dialog = self.active_dialogs[download_id]['dialog']
            dialog.update_progress(received, total)
    
    def on_download_state_changed(self, state, download):
        try:
            download_id = id(download)
            if state == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                if download_id in self.downloads:
                    del self.downloads[download_id]
                if download_id in self.progress_bars:
                    del self.progress_bars[download_id]
            elif state == QWebEngineDownloadRequest.DownloadState.DownloadInterrupted:
                if download_id in self.downloads:
                    del self.downloads[download_id]
                if download_id in self.progress_bars:
                    del self.progress_bars[download_id]
        except Exception:
            pass
    
    def on_download_state_changed_enhanced(self, state, download, download_id):
        try:
            if state == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                filename = download.downloadFileName()
                filepath = os.path.join(self.download_path, filename)
                
                self.completed_downloads.append({
                    'filename': filename,
                    'filepath': filepath,
                    'time': QDateTime.currentDateTime().toString('yyyy-MM-dd hh:mm:ss')
                })
                
                if download_id in self.active_dialogs:
                    dialog = self.active_dialogs[download_id]['dialog']
                    if dialog.isVisible():
                        dialog.accept()
                    del self.active_dialogs[download_id]
                
                if self.system_tray:
                    self.system_tray.show_notification(
                        "Download Complete",
                        f"{filename} has been downloaded to Alin Vault"
                    )
                
                main_window = self.find_main_window()
                if main_window and hasattr(main_window, 'download_manager_widget'):
                    main_window.download_manager_widget.refresh_downloads()
            elif state == QWebEngineDownloadRequest.DownloadState.DownloadInterrupted:
                if download_id in self.active_dialogs:
                    dialog = self.active_dialogs[download_id]['dialog']
                    if dialog.isVisible():
                        dialog.reject()
                    del self.active_dialogs[download_id]
                    
                if self.system_tray:
                    self.system_tray.show_notification(
                        "Download Failed",
                        f"{download.downloadFileName()}: {download.interruptReasonString()}"
                    )
        except Exception:
            pass
    
    def find_main_window(self):
        app = QApplication.instance()
        for widget in app.topLevelWidgets():
            if isinstance(widget, ALINDashboard):
                return widget
        return None

class SystemTrayManager(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tray_icon = None
        self.setup_tray()
        
    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon()
        self.tray_icon.setToolTip("Alin Vault")
        
        icon_path = os.path.join(os.path.dirname(__file__), "assets", "vault.png")
        if os.path.exists(icon_path):
            self.tray_icon.setIcon(QIcon(icon_path))
        else:
            icon = QPixmap(48, 48)
            icon.fill(Qt.GlobalColor.transparent)
            painter = QPainter(icon)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setBrush(QColor(0, 122, 255))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(4, 4, 40, 40)
            painter.setPen(QColor(255, 255, 255))
            font = QFont("Arial", 20)
            painter.setFont(font)
            painter.drawText(icon.rect().adjusted(0, -2, 0, 0), Qt.AlignmentFlag.AlignCenter, "AL")
            painter.end()
            self.tray_icon.setIcon(QIcon(icon))
        
        tray_menu = QMenu()
        show_action = QAction("Show Alin Vault", None)
        show_action.triggered.connect(self.show_window)
        tray_menu.addAction(show_action)
        
        tray_menu.addSeparator()
        
        quit_action = QAction("Quit", None)
        quit_action.triggered.connect(self.quit_app)
        tray_menu.addAction(quit_action)
        
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()
        
    def show_window(self):
        main_window = self.parent()
        if main_window:
            main_window.showNormal()
            main_window.activateWindow()
            main_window.raise_()
    
    def quit_app(self):
        QApplication.quit()
    
    def show_notification(self, title, message, duration=3000):
        if self.tray_icon and self.tray_icon.supportsMessages():
            self.tray_icon.showMessage(
                title,
                message,
                QSystemTrayIcon.MessageIcon.Information,
                duration
            )

class DownloadItemWidget(QWidget):
    def __init__(self, filename, filepath, size, source="", dark_mode=False, parent=None):
        super().__init__(parent)
        self.filepath = filepath
        self.filename = filename
        self.source = source
        self.dark_mode = dark_mode
        self.is_selected = False
        
        self.setObjectName("downloadItem")
        self.setFixedHeight(80)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(20, 12, 20, 12)
        layout.setSpacing(15)
        
        ext = os.path.splitext(filename)[1].lower()
        icon_map = {
            '.pdf': '📕', '.doc': '📘', '.docx': '📘',
            '.xls': '📗', '.xlsx': '📗',
            '.jpg': '🖼️', '.jpeg': '🖼️', '.png': '🖼️', '.gif': '🖼️',
            '.mp3': '🎵', '.wav': '🎵',
            '.mp4': '🎬', '.avi': '🎬', '.mkv': '🎬',
            '.zip': '📦', '.rar': '📦', '.7z': '📦',
            '.txt': '📄', '.py': '🐍', '.js': '📜', '.html': '🌐',
            '.exe': '⚙️', '.msi': '⚙️',
            '.pptx': '📊', '.ppt': '📊'
        }
        icon = icon_map.get(ext, '📄')
        
        icon_label = QLabel(icon)
        icon_label.setObjectName("fileIcon")
        icon_font = QFont("SF Pro Display", 32)
        icon_label.setFont(icon_font)
        layout.addWidget(icon_label)
        
        info_layout = QVBoxLayout()
        info_layout.setSpacing(4)
        
        name_layout = QHBoxLayout()
        name_layout.setSpacing(8)
        
        name_label = QLabel(filename)
        name_label.setObjectName("fileName")
        name_font = QFont("SF Pro Text", 14, QFont.Weight.Medium)
        name_label.setFont(name_font)
        name_layout.addWidget(name_label)
        
        source_badge = QFrame()
        source_badge.setObjectName("sourceBadge")
        source_badge.setFixedSize(8, 8)
        source_badge.setStyleSheet(f"""
            QFrame#sourceBadge {{
                background: {"#0a84ff" if source == "Downloads" else "#00bcd4"};
                border-radius: 4px;
            }}
        """)
        name_layout.addWidget(source_badge)
        
        source_label = QLabel(source)
        source_label.setObjectName("sourceLabel")
        source_label.setStyleSheet("font-size: 11px; color: #8e8e93;")
        name_layout.addWidget(source_label)
        
        name_layout.addStretch()
        info_layout.addLayout(name_layout)
        
        meta_layout = QHBoxLayout()
        meta_layout.setSpacing(15)
        
        size_label = QLabel(self.format_size(size))
        size_label.setObjectName("metaText")
        
        modified = QDateTime.fromSecsSinceEpoch(int(os.path.getmtime(filepath)))
        date_label = QLabel(modified.toString("MMM d, yyyy • hh:mm"))
        date_label.setObjectName("metaText")
        
        meta_layout.addWidget(size_label)
        meta_layout.addWidget(date_label)
        meta_layout.addStretch()
        info_layout.addLayout(meta_layout)
        
        layout.addLayout(info_layout, 1)
        
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(8)
        
        self.open_btn = QPushButton("Open")
        self.open_btn.setFixedSize(70, 36)
        self.open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.open_btn.clicked.connect(self.open_file)
        actions_layout.addWidget(self.open_btn)
        
        self.folder_btn = QPushButton()
        self.folder_btn.setFixedSize(40, 36)
        self.folder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.folder_btn.clicked.connect(self.open_folder)
        
        folder_icon_path = os.path.join(os.path.dirname(__file__), "assets", "folder.png")
        if os.path.exists(folder_icon_path):
            folder_icon = QIcon(folder_icon_path)
            self.folder_btn.setIcon(folder_icon)
            self.folder_btn.setIconSize(QSize(20, 20))
        else:
            self.folder_btn.setText("📂")
        
        actions_layout.addWidget(self.folder_btn)
        
        self.delete_btn = QPushButton()
        self.delete_btn.setFixedSize(40, 36)
        self.delete_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.delete_btn.clicked.connect(self.delete_file)
        
        bin_icon_path = os.path.join(os.path.dirname(__file__), "assets", "bin.png")
        if os.path.exists(bin_icon_path):
            bin_icon = QIcon(bin_icon_path)
            self.delete_btn.setIcon(bin_icon)
            self.delete_btn.setIconSize(QSize(20, 20))
        else:
            self.delete_btn.setText("🗑️")
        
        actions_layout.addWidget(self.delete_btn)
        
        layout.addLayout(actions_layout)
        
        self.setLayout(layout)
        self.update_stylesheet()
    
    def set_size_for_mode(self, mode):
        if mode == "grid":
            self.setFixedSize(300, 120)
            self.delete_btn.hide()
            self.folder_btn.hide()
        else:
            self.setFixedHeight(80)
            self.delete_btn.show()
            self.folder_btn.show()
    
    def format_size(self, bytes):
        try:
            bytes = float(bytes)
            if bytes < 0:
                return "0 B"
            
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if bytes < 1024.0:
                    return f"{bytes:.1f} {unit}"
                bytes /= 1024.0
            return f"{bytes:.1f} PB"
        except:
            return "0 B"
    
    def open_file(self):
        try:
            if sys.platform == 'win32':
                os.startfile(self.filepath)
            elif sys.platform == 'darwin':
                subprocess.run(['open', self.filepath])
            else:
                subprocess.run(['xdg-open', self.filepath])
        except Exception as e:
            error_box = QMessageBox(self)
            error_box.setWindowTitle("Error")
            error_box.setText(f"Cannot open file: {str(e)}")
            error_box.setIcon(QMessageBox.Icon.Critical)
            error_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            
            if not self.dark_mode:
                error_box.setStyleSheet("""
                    QMessageBox { background-color: white; color: black; }
                    QMessageBox QLabel { color: black; }
                    QPushButton { background-color: #f2f2f7; color: #007aff; border: none; border-radius: 6px; padding: 8px 16px; }
                """)
            else:
                error_box.setStyleSheet("""
                    QMessageBox { background-color: #2a2a3a; color: white; }
                    QMessageBox QLabel { color: white; }
                    QPushButton { background-color: #3a3a4a; color: white; border: none; border-radius: 6px; padding: 8px 16px; }
                """)
            
            error_box.exec()
    
    def open_folder(self):
        folder = os.path.dirname(self.filepath)
        try:
            if sys.platform == 'win32':
                os.startfile(folder)
            elif sys.platform == 'darwin':
                subprocess.run(['open', folder])
            else:
                subprocess.run(['xdg-open', folder])
        except Exception as e:
            error_box = QMessageBox(self)
            error_box.setWindowTitle("Error")
            error_box.setText(f"Cannot open folder: {str(e)}")
            error_box.setIcon(QMessageBox.Icon.Critical)
            error_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            
            if not self.dark_mode:
                error_box.setStyleSheet("""
                    QMessageBox { background-color: white; color: black; }
                    QMessageBox QLabel { color: black; }
                    QPushButton { background-color: #f2f2f7; color: #007aff; border: none; border-radius: 6px; padding: 8px 16px; }
                """)
            else:
                error_box.setStyleSheet("""
                    QMessageBox { background-color: #2a2a3a; color: white; }
                    QMessageBox QLabel { color: white; }
                    QPushButton { background-color: #3a3a4a; color: white; border: none; border-radius: 6px; padding: 8px 16px; }
                """)
            
            error_box.exec()
    
    def delete_file(self):
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Delete File")
        msg_box.setText(f"Are you sure you want to delete '{self.filename}'?")
        msg_box.setIcon(QMessageBox.Icon.Question)
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.setDefaultButton(QMessageBox.StandardButton.No)
        
        if not self.dark_mode:
            msg_box.setStyleSheet("""
                QMessageBox { 
                    background-color: white; 
                    color: black; 
                }
                QMessageBox QLabel { 
                    color: black; 
                    font-size: 13px; 
                }
                QPushButton { 
                    background-color: #f2f2f7; 
                    color: #007aff; 
                    border: none; 
                    border-radius: 6px; 
                    padding: 8px 16px; 
                    font-size: 13px; 
                    min-width: 80px; 
                }
                QPushButton:hover { 
                    background-color: #e5e5ea; 
                }
            """)
        else:
            msg_box.setStyleSheet("""
                QMessageBox { 
                    background-color: #2a2a3a; 
                    color: white; 
                }
                QMessageBox QLabel { 
                    color: white; 
                    font-size: 13px; 
                }
                QPushButton { 
                    background-color: #3a3a4a; 
                    color: white; 
                    border: none; 
                    border-radius: 6px; 
                    padding: 8px 16px; 
                    font-size: 13px; 
                    min-width: 80px; 
                }
                QPushButton:hover { 
                    background-color: #4a4a5a; 
                }
            """)
        
        reply = msg_box.exec()
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                os.remove(self.filepath)
                self.setParent(None)
                self.deleteLater()
                
                main_window = self.find_main_window()
                if main_window and hasattr(main_window, 'download_manager_widget'):
                    main_window.download_manager_widget.refresh_downloads()
            except Exception as e:
                error_box = QMessageBox(self)
                error_box.setWindowTitle("Error")
                error_box.setText(f"Cannot delete file: {str(e)}")
                error_box.setIcon(QMessageBox.Icon.Critical)
                error_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                
                if not self.dark_mode:
                    error_box.setStyleSheet("""
                        QMessageBox { background-color: white; color: black; }
                        QMessageBox QLabel { color: black; }
                        QPushButton { background-color: #f2f2f7; color: #007aff; border: none; border-radius: 6px; padding: 8px 16px; }
                    """)
                else:
                    error_box.setStyleSheet("""
                        QMessageBox { background-color: #2a2a3a; color: white; }
                        QMessageBox QLabel { color: white; }
                        QPushButton { background-color: #3a3a4a; color: white; border: none; border-radius: 6px; padding: 8px 16px; }
                    """)
                
                error_box.exec()
    
    def find_main_window(self):
        app = QApplication.instance()
        for widget in app.topLevelWidgets():
            if isinstance(widget, ALINDashboard):
                return widget
        return None
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_stylesheet()
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QFrame#downloadItem {
                    background: #2a2a3a;
                    border-radius: 16px;
                    border: 1px solid #3a3a4a;
                }
                QFrame#downloadItem:hover {
                    background: #323242;
                    border: 1px solid #4a4a5a;
                }
                QLabel#fileName {
                    color: #ffffff;
                }
                QLabel#metaText {
                    color: #8e8e93;
                    font-size: 11px;
                }
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                    font-size: 13px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
                QPushButton:pressed {
                    background: #2a2a3a;
                }
            """)
            
            self.folder_btn.setStyleSheet("""
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
            """)
            
            self.delete_btn.setStyleSheet("""
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ff453a;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: rgba(255, 69, 58, 0.3);
                }
            """)
            
        else:
            self.setStyleSheet("""
                QFrame#downloadItem {
                    background: #ffffff;
                    border-radius: 16px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                QFrame#downloadItem:hover {
                    background: #f8f9fa;
                    border: 1px solid rgba(60, 60, 67, 0.2);
                }
                QLabel#fileName {
                    color: #000000;
                }
                QLabel#metaText {
                    color: #8e8e93;
                    font-size: 11px;
                }
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 13px;
                    font-weight: 500;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:pressed {
                    background: #d1d1d6;
                }
            """)
            
            self.folder_btn.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
            """)
            
            self.delete_btn.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #ff3b30;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #ffe5e5;
                }
            """)
            
            for btn in self.findChildren(QPushButton):
                if btn.text() == "📁":
                    btn.setStyleSheet("""
                        QPushButton {
                            background: #f2f2f7;
                            border: none;
                            border-radius: 8px;
                            font-size: 16px;
                            color: #007aff;
                            padding: 6px;
                        }
                        QPushButton:hover {
                            background: #e5e5ea;
                        }
                    """)

class DownloadManagerWidget(QWidget):
    def __init__(self, download_manager, parent=None):
        super().__init__(parent)
        self.download_manager = download_manager
        self.download_items = []
        self.dark_mode = False
        self.current_filter = "All"
        self.selected_items = []
        self.view_mode = "grid"
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        header = QFrame()
        header.setObjectName("downloadsHeader")
        header.setFixedHeight(100)
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(30, 0, 30, 0)
        
        title_container = QWidget()
        title_layout = QHBoxLayout()
        title_layout.setSpacing(12)
        
        icon_label = QLabel("⬇️")
        icon_label.setObjectName("headerIcon")
        icon_font = QFont("SF Pro Display", 32)
        icon_label.setFont(icon_font)
        
        self.title_label = QLabel("Downloads")
        self.title_label.setObjectName("mainTitle")
        title_font = QFont("SF Pro Display", 28, QFont.Weight.Bold)
        self.title_label.setFont(title_font)
        
        title_layout.addWidget(icon_label)
        title_layout.addWidget(self.title_label)
        title_container.setLayout(title_layout)
        header_layout.addWidget(title_container)
        
        header_layout.addStretch()
        
        stats_container = QWidget()
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(15)
        
        self.total_stats = self.create_stat_card("📊", "Total", "0")
        self.downloads_stats = self.create_stat_card("⬇️", "Downloads", "0")
        self.documents_stats = self.create_stat_card("📄", "Documents", "0")
        
        stats_layout.addWidget(self.total_stats)
        stats_layout.addWidget(self.downloads_stats)
        stats_layout.addWidget(self.documents_stats)
        stats_container.setLayout(stats_layout)
        header_layout.addWidget(stats_container)
        
        header.setLayout(header_layout)
        layout.addWidget(header)
        
        toolbar = QFrame()
        toolbar.setObjectName("downloadsToolbar")
        toolbar.setFixedHeight(60)
        toolbar_layout = QHBoxLayout()
        toolbar_layout.setContentsMargins(30, 0, 30, 0)
        toolbar_layout.setSpacing(15)
        
        filter_group = QFrame()
        filter_group.setObjectName("filterGroup")
        filter_layout = QHBoxLayout()
        filter_layout.setContentsMargins(4, 4, 4, 4)
        filter_layout.setSpacing(4)
        
        self.filter_all_btn = QPushButton("All Files")
        self.filter_all_btn.setCheckable(True)
        self.filter_all_btn.setChecked(True)
        self.filter_all_btn.clicked.connect(lambda: self.set_filter("All"))
        
        self.filter_downloads_btn = QPushButton("Downloads")
        self.filter_downloads_btn.setCheckable(True)
        self.filter_downloads_btn.clicked.connect(lambda: self.set_filter("Downloads"))
        
        self.filter_documents_btn = QPushButton("Documents")
        self.filter_documents_btn.setCheckable(True)
        self.filter_documents_btn.clicked.connect(lambda: self.set_filter("Documents"))
        
        filter_layout.addWidget(self.filter_all_btn)
        filter_layout.addWidget(self.filter_downloads_btn)
        filter_layout.addWidget(self.filter_documents_btn)
        filter_group.setLayout(filter_layout)
        
        toolbar_layout.addWidget(filter_group)
        
        self.filter_group = QButtonGroup(self)
        self.filter_group.addButton(self.filter_all_btn)
        self.filter_group.addButton(self.filter_downloads_btn)
        self.filter_group.addButton(self.filter_documents_btn)
        
        toolbar_layout.addStretch()
        
        search_container = QFrame()
        search_container.setObjectName("searchContainer")
        search_container.setFixedWidth(250)
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(12, 0, 12, 0)
        search_layout.setSpacing(8)
        
        search_icon = QLabel("🔍")
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search files...")
        self.search_input.setFixedHeight(36)
        self.search_input.textChanged.connect(self.filter_files)
        
        search_layout.addWidget(search_icon)
        search_layout.addWidget(self.search_input)
        search_container.setLayout(search_layout)
        toolbar_layout.addWidget(search_container)
        
        self.view_toggle_btn = QPushButton("☰")
        self.view_toggle_btn.setFixedSize(40, 36)
        self.view_toggle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.view_toggle_btn.clicked.connect(self.toggle_view_mode)
        toolbar_layout.addWidget(self.view_toggle_btn)
        
        self.refresh_btn = QPushButton("↻")
        self.refresh_btn.setFixedSize(40, 36)
        self.refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.refresh_downloads)
        toolbar_layout.addWidget(self.refresh_btn)
        
        self.open_folder_btn = QPushButton("📂 Open Folder")
        self.open_folder_btn.setFixedHeight(36)
        self.open_folder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.open_folder_btn.clicked.connect(self.open_download_folder)
        toolbar_layout.addWidget(self.open_folder_btn)
        
        toolbar.setLayout(toolbar_layout)
        layout.addWidget(toolbar)
        
        content_area = QFrame()
        content_area.setObjectName("contentArea")
        content_layout = QVBoxLayout()
        content_layout.setContentsMargins(30, 20, 30, 20)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameStyle(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        self.scroll_content = QWidget()
        self.scroll_content.setObjectName("scrollContent")
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.scroll_layout.setSpacing(8)
        self.scroll_layout.setContentsMargins(0, 0, 0, 0)
        
        self.scroll_area.setWidget(self.scroll_content)
        content_layout.addWidget(self.scroll_area)
        
        content_area.setLayout(content_layout)
        layout.addWidget(content_area)
        
        self.setLayout(layout)
        
        self.update_stylesheet()
        self.refresh_downloads()

    def lighten_color(self, hex_color, percent):
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        r = min(255, int(r + (255 - r) * percent / 100))
        g = min(255, int(g + (255 - g) * percent / 100))
        b = min(255, int(b + (255 - b) * percent / 100))
        return f"#{r:02x}{g:02x}{b:02x}"

    def darken_color(self, hex_color, percent):
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        r = max(0, int(r * (100 - percent) / 100))
        g = max(0, int(g * (100 - percent) / 100))
        b = max(0, int(b * (100 - percent) / 100))
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def format_size(self, bytes):
        try:
            bytes = float(bytes)
            if bytes < 0:
                return "0 B"
            
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if bytes < 1024.0:
                    return f"{bytes:.1f} {unit}"
                bytes /= 1024.0
            return f"{bytes:.1f} PB"
        except:
            return "0 B"
    
    
    def create_stat_card(self, icon, label, value):
        card = QFrame()
        card.setObjectName("statCard")
        card.setFixedSize(100, 70)
        layout = QVBoxLayout()
        layout.setSpacing(4)
        
        icon_label = QLabel(icon)
        icon_label.setObjectName("statIcon")
        
        value_label = QLabel(value)
        value_label.setObjectName("statValue")
        
        label_label = QLabel(label)
        label_label.setObjectName("statLabel")
        
        layout.addWidget(icon_label, 0, Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(value_label, 0, Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(label_label, 0, Qt.AlignmentFlag.AlignCenter)
        card.setLayout(layout)
        
        card.value_label = value_label
        return card
    
    def set_filter(self, filter_type):
        self.current_filter = filter_type
        self.filter_files()
    
    def toggle_view_mode(self):
        if self.view_mode == "grid":
            self.view_mode = "list"
            self.view_toggle_btn.setText("☰")  
        else:
            self.view_mode = "grid"
            self.view_toggle_btn.setText("⊞")  
        
        self.refresh_downloads()
    
    def filter_files(self):
        search_text = self.search_input.text().lower()
        
        for i in reversed(range(self.scroll_layout.count())):
            item = self.scroll_layout.itemAt(i)
            if item and item.spacerItem():
                self.scroll_layout.removeItem(item)
        
        visible_count = 0
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, DownloadItemWidget):
                    matches_filter = (self.current_filter == "All" or 
                                    widget.source == self.current_filter)
                    matches_search = (not search_text or 
                                    search_text in widget.filename.lower())
                    should_show = matches_filter and matches_search
                    widget.setVisible(should_show)
                    if should_show:
                        visible_count += 1
        
        self.title_label.setText(f"Downloads  •  {visible_count} items")
        
        self.update_stats()
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_stylesheet()
        
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if hasattr(widget, 'set_dark_mode'):
                    widget.set_dark_mode(dark)
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QFrame#downloadsHeader {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 #1e1e2e, stop:1 #2a2a3a);
                    border-bottom: 1px solid #3a3a4a;
                }
                
                QFrame#downloadsToolbar {
                    background: #1e1e2e;
                    border-bottom: 1px solid #2a2a3a;
                }
                
                QFrame#contentArea {
                    background: #1a1a2e;
                }
                
                QLabel#mainTitle {
                    color: #ffffff;
                    font-size: 28px;
                    font-weight: bold;
                }
                
                QLabel#headerIcon {
                    color: #0a84ff;
                }
                
                QFrame#statCard {
                    background: #2a2a3a;
                    border-radius: 12px;
                    border: 1px solid #3a3a4a;
                }
                
                QLabel#statIcon {
                    font-size: 20px;
                    color: #0a84ff;
                }
                
                QLabel#statValue {
                    color: #ffffff;
                    font-size: 18px;
                    font-weight: bold;
                }
                
                QLabel#statLabel {
                    color: #8e8e93;
                    font-size: 11px;
                }
                
                QFrame#filterGroup {
                    background: #2a2a3a;
                    border-radius: 10px;
                }
                
                QPushButton {
                    background: transparent;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                    padding: 8px 16px;
                    font-size: 13px;
                }
                
                QPushButton:hover {
                    background: #3a3a4a;
                }
                
                QPushButton:checked {
                    background: #0a84ff;
                    color: white;
                }
                
                QFrame#searchContainer {
                    background: #2a2a3a;
                    border-radius: 10px;
                }
                
                QLineEdit {
                    background: transparent;
                    border: none;
                    color: #ffffff;
                    font-size: 13px;
                }
                
                QLineEdit::placeholder {
                    color: #8e8e93;
                }
                
                QScrollArea {
                    background: transparent;
                    border: none;
                }
                
                QScrollArea > QWidget > QWidget {
                    background: transparent;
                }
                
                QScrollBar:vertical {
                    background: #2a2a3a;
                    width: 8px;
                    border-radius: 4px;
                }
                
                QScrollBar::handle:vertical {
                    background: #4a4a5a;
                    border-radius: 4px;
                    min-height: 20px;
                }
                
                QScrollBar::handle:vertical:hover {
                    background: #5a5a6a;
                }
                
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    border: none;
                    background: none;
                }
                
                QWidget#scrollContent {
                    background: transparent;
                }
            """)
            
            self.refresh_btn.setStyleSheet("""
                QPushButton {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 8px;
                    color: #ffffff;
                    font-size: 16px;
                    padding: 0px;
                }
                QPushButton:hover {
                    background: #3a3a4a;
                }
            """)
            
            self.view_toggle_btn.setStyleSheet("""
                QPushButton {
                    background: #2a2a3a;
                    border: 1px solid #3a3a4a;
                    border-radius: 8px;
                    color: #ffffff;
                    font-size: 16px;
                    padding: 0px;
                }
                QPushButton:hover {
                    background: #3a3a4a;
                }
            """)
            
            self.open_folder_btn.setStyleSheet("""
                QPushButton {
                    background: #0a84ff;
                    border: none;
                    border-radius: 8px;
                    color: white;
                    font-size: 13px;
                    font-weight: 500;
                    padding: 0 16px;
                }
                QPushButton:hover {
                    background: #409cff;
                }
                QPushButton:pressed {
                    background: #0063ce;
                }
            """)
            
        else:
            self.setStyleSheet("""
                QFrame#downloadsHeader {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 #f8f9fa, stop:1 #ffffff);
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#downloadsToolbar {
                    background: #ffffff;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QFrame#contentArea {
                    background: #f8f9fa;
                }
                
                QLabel#mainTitle {
                    color: #000000;
                    font-size: 28px;
                    font-weight: bold;
                }
                
                QLabel#headerIcon {
                    color: #007aff;
                }
                
                QFrame#statCard {
                    background: #ffffff;
                    border-radius: 12px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QLabel#statIcon {
                    font-size: 20px;
                    color: #007aff;
                }
                
                QLabel#statValue {
                    color: #000000;
                    font-size: 18px;
                    font-weight: bold;
                }
                
                QLabel#statLabel {
                    color: #8e8e93;
                    font-size: 11px;
                }
                
                QFrame#filterGroup {
                    background: #f2f2f7;
                    border-radius: 10px;
                }
                
                QPushButton {
                    background: transparent;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                    padding: 8px 16px;
                    font-size: 13px;
                }
                
                QPushButton:hover {
                    background: #e5e5ea;
                }
                
                QPushButton:checked {
                    background: #007aff;
                    color: white;
                }
                
                QFrame#searchContainer {
                    background: #f2f2f7;
                    border-radius: 10px;
                }
                
                QLineEdit {
                    background: transparent;
                    border: none;
                    color: #000000;
                    font-size: 13px;
                }
                
                QLineEdit::placeholder {
                    color: #8e8e93;
                }
                
                QScrollArea {
                    background: transparent;
                    border: none;
                }
                
                QScrollArea > QWidget > QWidget {
                    background: transparent;
                }
                
                QScrollBar:vertical {
                    background: transparent;
                    width: 8px;
                    border-radius: 4px;
                }
                
                QScrollBar::handle:vertical {
                    background: #c1c1c1;
                    border-radius: 4px;
                    min-height: 20px;
                }
                
                QScrollBar::handle:vertical:hover {
                    background: #a8a8a8;
                }
                
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    border: none;
                    background: none;
                }
                
                QWidget#scrollContent {
                    background: transparent;
                }
            """)
            
            self.refresh_btn.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 16px;
                    padding: 0px;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
            """)
            
            self.view_toggle_btn.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 16px;
                    padding: 0px;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
            """)
            
            self.open_folder_btn.setStyleSheet("""
                QPushButton {
                    background: #007aff;
                    border: none;
                    border-radius: 8px;
                    color: white;
                    font-size: 13px;
                    font-weight: 500;
                    padding: 0 16px;
                }
                QPushButton:hover {
                    background: #005fc7;
                }
                QPushButton:pressed {
                    background: #004299;
                }
            """)
    
    def refresh_downloads(self):
        for i in reversed(range(self.scroll_layout.count())):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                widget.setParent(None)
                widget.deleteLater()
            elif item and item.spacerItem():
                self.scroll_layout.removeItem(item)
        
        all_files = []
        home = os.path.expanduser("~")
        
        downloads_path = os.path.join(home, "Downloads", "Alin Vault")
        if os.path.exists(downloads_path):
            for f in os.listdir(downloads_path):
                filepath = os.path.join(downloads_path, f)
                if os.path.isfile(filepath):
                    modified = os.path.getmtime(filepath)
                    all_files.append((modified, f, filepath, "Downloads"))
        
        documents_path = os.path.join(home, "Documents", "Alin Vault")
        if os.path.exists(documents_path):
            for f in os.listdir(documents_path):
                filepath = os.path.join(documents_path, f)
                if os.path.isfile(filepath):
                    modified = os.path.getmtime(filepath)
                    all_files.append((modified, f, filepath, "Documents"))
        
        all_files.sort(reverse=True)
        
        downloads_count = 0
        documents_count = 0

        if self.view_mode == "grid":
            grid_widget = QWidget()
            grid_widget.setObjectName("gridContainer")
            
            grid_layout = QGridLayout()
            grid_layout.setSpacing(20)
            grid_layout.setContentsMargins(20, 20, 20, 20)
            grid_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
            
            row = 0
            col = 0
            max_cols = 4
            
            if hasattr(self, 'parent') and self.parent():
                parent_width = self.parent().width()
                if parent_width > 1400:
                    max_cols = 8
                elif parent_width > 1100:
                    max_cols = 6
                elif parent_width > 800:
                    max_cols = 4
                else:
                    max_cols = 2
            
            ios_colors = {
                'blue': '#007AFF',
                'green': '#34C759',
                'indigo': '#5856D6',
                'orange': '#FF9500',
                'pink': '#FF2D55',
                'purple': '#AF52DE',
                'red': '#FF3B30',
                'teal': '#5AC8FA',
                'yellow': '#FFCC00',
                'gray': '#8E8E93',
                'gray2': '#AEAEB2',
                'gray3': '#C7C7CC',
                'gray4': '#D1D1D6',
                'gray5': '#E5E5EA',
                'gray6': '#F2F2F7'
            }
            
            for modified, filename, filepath, source in all_files:
                size = os.path.getsize(filepath)
                
                if source == "Downloads":
                    downloads_count += 1
                else:
                    documents_count += 1
                
                ext = os.path.splitext(filename)[1].lower()
                
                ext_color_map = {
                    '.pdf': ios_colors['red'],
                    '.doc': ios_colors['blue'], '.docx': ios_colors['blue'],
                    '.xls': ios_colors['green'], '.xlsx': ios_colors['green'],
                    '.ppt': ios_colors['orange'], '.pptx': ios_colors['orange'],
                    '.jpg': ios_colors['pink'], '.jpeg': ios_colors['pink'],
                    '.png': ios_colors['pink'], '.gif': ios_colors['pink'],
                    '.mp3': ios_colors['purple'], '.wav': ios_colors['purple'],
                    '.flac': ios_colors['purple'],
                    '.mp4': ios_colors['indigo'], '.avi': ios_colors['indigo'],
                    '.mkv': ios_colors['indigo'], '.mov': ios_colors['indigo'],
                    '.zip': ios_colors['teal'], '.rar': ios_colors['teal'],
                    '.7z': ios_colors['teal'], '.tar': ios_colors['teal'],
                    '.txt': ios_colors['gray'], '.md': ios_colors['gray'],
                    '.py': ios_colors['blue'], '.js': ios_colors['yellow'],
                    '.html': ios_colors['orange'], '.css': ios_colors['purple'],
                }
                
                accent_color = ext_color_map.get(ext, ios_colors['blue'])
                
                item_container = QFrame()
                item_container.setObjectName("gridItem")
                item_container.setFixedSize(260, 300)
                item_container.setCursor(Qt.CursorShape.PointingHandCursor)
                
                item_layout = QVBoxLayout()
                item_layout.setContentsMargins(16, 20, 16, 16)
                item_layout.setSpacing(12)
                
                top_layout = QHBoxLayout()
                top_layout.setContentsMargins(0, 0, 0, 0)
                
                icon_container = QFrame()
                icon_container.setObjectName("iconContainer")
                icon_container.setFixedSize(64, 64)
                icon_container.setStyleSheet(f"""
                    QFrame#iconContainer {{
                        background: {ios_colors['gray6']};
                        border-radius: 20px;
                        border: none;
                    }}
                """)
                
                icon_layout = QVBoxLayout(icon_container)
                icon_layout.setContentsMargins(0, 0, 0, 0)
                
                icon_label = QLabel()
                icon_label.setObjectName("gridIcon")
                icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                
                icon_map = {
                    '.pdf': '📕', '.doc': '📘', '.docx': '📘',
                    '.xls': '📗', '.xlsx': '📗', '.ppt': '📊', '.pptx': '📊',
                    '.jpg': '🖼️', '.jpeg': '🖼️', '.png': '🖼️', '.gif': '🖼️', '.svg': '🎨',
                    '.mp3': '🎵', '.wav': '🎵', '.flac': '🎵',
                    '.mp4': '🎬', '.avi': '🎬', '.mkv': '🎬', '.mov': '🎬',
                    '.zip': '📦', '.rar': '📦', '.7z': '📦', '.tar': '📦',
                    '.txt': '📄', '.md': '📝',
                    '.py': '🐍', '.js': '⚡', '.html': '🌐', '.css': '🎨', '.json': '📋',
                    '.exe': '⚙️', '.msi': '📦', '.dmg': '💿',
                    '.psd': '🎨', '.ai': '✒️', '.xd': '🖌️',
                    '.db': '🗄️', '.sql': '📊', '.csv': '📊',
                }
                icon = icon_map.get(ext, '📄')
                
                icon_font = QFont("SF Pro Display", 32)
                icon_label.setFont(icon_font)
                icon_label.setText(icon)
                icon_label.setStyleSheet(f"color: {accent_color};")
                
                icon_layout.addWidget(icon_label)
                
                source_badge = QFrame()
                source_badge.setObjectName("sourceBadge")
                source_badge.setFixedSize(8, 8)
                
                badge_color = ios_colors['blue'] if source == "Downloads" else ios_colors['green']
                source_badge.setStyleSheet(f"""
                    QFrame#sourceBadge {{
                        background: {badge_color};
                        border-radius: 4px;
                        border: none;
                    }}
                """)
                
                source_container = QWidget()
                source_container_layout = QHBoxLayout()
                source_container_layout.setContentsMargins(0, 0, 0, 0)
                source_container_layout.setSpacing(6)
                source_container_layout.addWidget(source_badge)
                
                source_text = QLabel(source)
                source_text.setObjectName("gridSource")
                source_text_font = QFont("SF Pro Text", 11, QFont.Weight.Medium)
                source_text.setFont(source_text_font)
                source_text.setStyleSheet(f"color: {ios_colors['gray']};")
                source_container_layout.addWidget(source_text)
                source_container_layout.addStretch()
                source_container.setLayout(source_container_layout)
                
                top_layout.addWidget(icon_container)
                top_layout.addStretch()
                top_layout.addWidget(source_container)
                
                item_layout.addLayout(top_layout)
                
                name_label = QLabel(filename)
                name_label.setObjectName("gridFileName")
                name_label.setWordWrap(True)
                name_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
                
                name_font = QFont("SF Pro Text", 14, QFont.Weight.DemiBold)
                name_label.setFont(name_font)
                name_label.setFixedHeight(48)
                name_label.setWordWrap(False)
                
                metrics = name_label.fontMetrics()
                elided_text = metrics.elidedText(filename, Qt.TextElideMode.ElideMiddle, 180)
                name_label.setText(elided_text)
                name_label.setStyleSheet(f"color: {ios_colors['gray']};")
                
                item_layout.addWidget(name_label)
                
                separator = QFrame()
                separator.setObjectName("separator")
                separator.setFrameShape(QFrame.Shape.HLine)
                separator.setFixedHeight(1)
                separator.setStyleSheet(f"""
                    QFrame#separator {{
                        background: {ios_colors['gray5']};
                        max-height: 1px;
                        border: none;
                    }}
                """)
                item_layout.addWidget(separator)
                
                meta_layout = QVBoxLayout()
                meta_layout.setSpacing(8)
                
                size_container = QWidget()
                size_layout = QHBoxLayout()
                size_layout.setContentsMargins(0, 0, 0, 0)
                size_layout.setSpacing(8)
                
                size_icon = QLabel("📦")
                size_icon_font = QFont("SF Pro Text", 12, QFont.Weight.Normal)
                size_icon.setFont(size_icon_font)
                size_icon.setObjectName("metaIcon")
                size_icon.setStyleSheet(f"color: {ios_colors['gray2']};")
                
                size_value = QLabel(self.format_size(size))
                size_value.setObjectName("gridSize")
                size_value_font = QFont("SF Pro Text", 12, QFont.Weight.Normal)
                size_value.setFont(size_value_font)
                size_value.setStyleSheet(f"color: {ios_colors['gray']};")
                
                size_layout.addWidget(size_icon)
                size_layout.addWidget(size_value)
                size_layout.addStretch()
                size_container.setLayout(size_layout)
                meta_layout.addWidget(size_container)
                
                date_container = QWidget()
                date_layout = QHBoxLayout()
                date_layout.setContentsMargins(0, 0, 0, 0)
                date_layout.setSpacing(8)
                
                date_icon = QLabel("📅")
                date_icon_font = QFont("SF Pro Text", 12, QFont.Weight.Normal)
                date_icon.setFont(date_icon_font)
                date_icon.setObjectName("metaIcon")
                date_icon.setStyleSheet(f"color: {ios_colors['gray2']};")
                
                modified_date = QDateTime.fromSecsSinceEpoch(int(modified))
                date_value = QLabel(modified_date.toString("MMM d, yyyy"))
                date_value.setObjectName("gridDate")
                date_value_font = QFont("SF Pro Text", 12, QFont.Weight.Normal)
                date_value.setFont(date_value_font)
                date_value.setStyleSheet(f"color: {ios_colors['gray']};")
                
                date_layout.addWidget(date_icon)
                date_layout.addWidget(date_value)
                date_layout.addStretch()
                date_container.setLayout(date_layout)
                meta_layout.addWidget(date_container)
                
                item_layout.addLayout(meta_layout)
                
                item_layout.addStretch()
                
                open_btn = QPushButton("Open File")
                open_btn.setObjectName("gridOpenBtn")
                open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                open_btn.setFixedHeight(44)
                open_btn.clicked.connect(lambda checked, fp=filepath: self.open_file(fp))
                
                open_btn.setStyleSheet(f"""
                    QPushButton#gridOpenBtn {{
                        background: {ios_colors['blue']};
                        border: none;
                        border-radius: 12px;
                        color: white;
                        font-weight: 600;
                        font-size: 14px;
                        font-family: "SF Pro Text";
                    }}
                    QPushButton#gridOpenBtn:hover {{
                        background: {ios_colors['blue']}dd;
                    }}
                    QPushButton#gridOpenBtn:pressed {{
                        background: {ios_colors['blue']}aa;
                    }}
                """)
                
                item_layout.addWidget(open_btn)
                
                item_container.setLayout(item_layout)
                
                item_container.setStyleSheet(f"""
                    QFrame#gridItem {{
                        background: white;
                        border-radius: 20px;
                        border: none;
                    }}
                    QFrame#gridItem:hover {{
                        background: {ios_colors['gray6']};
                    }}
                    QLabel#gridFileName {{
                        color: {ios_colors['gray']};
                        font-weight: 600;
                    }}
                """)
                
                grid_layout.addWidget(item_container, row, col)
                
                col += 1
                if col >= max_cols:
                    col = 0
                    row += 1
            
            grid_widget.setLayout(grid_layout)
            
            scroll_area = QScrollArea()
            scroll_area.setWidgetResizable(True)
            scroll_area.setFrameStyle(QFrame.Shape.NoFrame)
            scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            scroll_area.setWidget(grid_widget)
            scroll_area.setStyleSheet("""
                QScrollArea {
                    background: transparent;
                    border: none;
                }
                QScrollArea > QWidget > QWidget {
                    background: transparent;
                }
                QScrollBar:vertical {
                    background: #F2F2F7;
                    width: 6px;
                    border-radius: 3px;
                }
                QScrollBar::handle:vertical {
                    background: #C7C7CC;
                    border-radius: 3px;
                    min-height: 20px;
                }
                QScrollBar::handle:vertical:hover {
                    background: #AEAEB2;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    border: none;
                    background: none;
                }
            """)
            
            self.scroll_layout.addWidget(scroll_area)
            
        else:
            for modified, filename, filepath, source in all_files:
                size = os.path.getsize(filepath)
                
                if source == "Downloads":
                    downloads_count += 1
                else:
                    documents_count += 1
                
                item = DownloadItemWidget(filename, filepath, size, source, self.dark_mode)
                self.scroll_layout.addWidget(item)
        self.total_stats.value_label.setText(str(len(all_files)))
        self.downloads_stats.value_label.setText(str(downloads_count))
        self.documents_stats.value_label.setText(str(documents_count))
        
        self.title_label.setText(f"Downloads  •  {len(all_files)} items")
        
        self.filter_files()
    
    def open_file(self, filepath):
        try:
            if sys.platform == 'win32':
                os.startfile(filepath)
            elif sys.platform == 'darwin':
                subprocess.run(['open', filepath])
            else:
                subprocess.run(['xdg-open', filepath])
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Cannot open file: {str(e)}")
            
    def open_download_folder(self):
        path = self.download_manager.download_path
        if sys.platform == 'win32':
            os.startfile(path)
        elif sys.platform == 'darwin':
            subprocess.run(['open', path])
        else:
            subprocess.run(['xdg-open', path])
    
    def update_stats(self):
        visible_count = 0
        downloads_visible = 0
        documents_visible = 0
        
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i)
            if item and item.widget() and item.widget().isVisible():
                widget = item.widget()
                if isinstance(widget, DownloadItemWidget):
                    visible_count += 1
                    if widget.source == "Downloads":
                        downloads_visible += 1
                    else:
                        documents_visible += 1

class TabInfo:
    def __init__(self, name, url, webview, button):
        self.name = name
        self.url = url
        self.webview = webview
        self.button = button
        self.profile_name = None

class AddTabDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add New Tab")
        self.setMinimumSize(400, 200)
        
        layout = QVBoxLayout()
        
        layout.addWidget(QLabel("Enter URL:"))
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("https://example.com")
        layout.addWidget(self.url_input)
        
        layout.addWidget(QLabel("Enter Short Name:"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("My Website")
        layout.addWidget(self.name_input)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.setLayout(layout)
        
    def get_values(self):
        return self.url_input.text(), self.name_input.text()

class LoginHelperDialog(QDialog):
    def __init__(self, service_name, login_url, parent=None):
        super().__init__(parent)
        self.service_name = service_name
        self.login_url = login_url
        
        self.setWindowTitle(f"Login to {service_name}")
        self.setMinimumSize(600, 400)
        
        layout = QVBoxLayout()
        
        info_label = QLabel(
            f"<h3>Login to {service_name}</h3>"
            "<p>Due to Google's security restrictions, you need to login using your default browser.</p>"
            "<p>Click the button below to open the login page in your browser.</p>"
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        self.btn_open_browser = QPushButton(f"Open {service_name} Login in Browser")
        self.btn_open_browser.clicked.connect(self.open_browser)
        self.btn_open_browser.setMinimumHeight(50)
        layout.addWidget(self.btn_open_browser)
        
        instructions = QLabel(
            "<b>Instructions:</b><br>"
            "1. Click the button above to open login page<br>"
            "2. Login to your account in the browser<br>"
            "3. After successful login, return to this application<br>"
            "4. Click 'Continue' to reload the page"
        )
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        
        button_box.button(QDialogButtonBox.StandardButton.Ok).setText("Continue")
        
        layout.addWidget(button_box)
        
        self.setLayout(layout)
        
    def open_browser(self):
        webbrowser.open(self.login_url)
        QMessageBox.information(
            self, 
            "Browser Opened", 
            f"Please login to {service_name} in your browser.\n\n"
            "After successful login, return to this application and click 'Continue'."
        )

class CustomTabButton(QPushButton):
    closed = pyqtSignal(object)
    
    def __init__(self, text, tab_id, parent=None):
        super().__init__(text, parent)
        self.tab_id = tab_id
        self.original_text = text  # Store original text for fallback
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumWidth(100)
        self.setMaximumWidth(180)  # Increased to accommodate longer titles
        self.setFixedHeight(36)
        
        # Enable tooltip for full title on hover
        self.setToolTip(text)
    
    def update_title(self, title):
        """Update button text with website title"""
        if title and title.strip():
            # Limit title length for display
            display_title = title.strip()
            if len(display_title) > 20:
                display_title = display_title[:18] + "..."
            
            # Set button text with icon
            icon = self.get_icon_for_title(title)
            self.setText(f"{icon} {display_title}")
            self.setToolTip(title)  # Full title on hover
        else:
            # Fallback to original text
            self.setText(self.original_text)
    
    def get_icon_for_title(self, title):
        """Get appropriate icon based on website title"""
        title_lower = title.lower()
        
        # Common website icons
        if 'whatsapp' in title_lower:
            return "💬"
        elif 'youtube' in title_lower:
            return "▶️"
        elif 'chatgpt' in title_lower or 'openai' in title_lower:
            return "🤖"
        elif 'deepseek' in title_lower:
            return "🔍"
        elif 'google' in title_lower:
            return "🔎"
        elif 'github' in title_lower:
            return "🐙"
        elif 'facebook' in title_lower:
            return "👤"
        elif 'instagram' in title_lower:
            return "📸"
        elif 'twitter' in title_lower or 'x.com' in title_lower:
            return "🐦"
        elif 'discord' in title_lower:
            return "💬"
        elif 'slack' in title_lower:
            return "#"
        elif 'telegram' in title_lower:
            return "✈️"
        elif 'spotify' in title_lower:
            return "🎵"
        elif 'netflix' in title_lower:
            return "🎬"
        elif 'amazon' in title_lower:
            return "📦"
        else:
            return "🌐"
    
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.closed.emit(self)
        else:
            super().mousePressEvent(event)

class ClipboardItemWidget(QWidget):
    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.text = text
        self.is_dark_mode = False
        self.is_selected = False
        self.parent_clipboard = parent
        self.item = None
        
        self.setObjectName("clipboardItem")
        self.setFixedHeight(80)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(20, 12, 20, 12)
        layout.setSpacing(15)
        
        self.selection_frame = QFrame()
        self.selection_frame.setObjectName("selectionFrame")
        self.selection_frame.setFixedSize(24, 24)
        selection_layout = QHBoxLayout()
        selection_layout.setContentsMargins(0, 0, 0, 0)
        
        self.checkbox = QCheckBox()
        self.checkbox.setVisible(False)
        self.checkbox.stateChanged.connect(self.on_checkbox_changed)
        selection_layout.addWidget(self.checkbox, 0, Qt.AlignmentFlag.AlignCenter)
        self.selection_frame.setLayout(selection_layout)
        layout.addWidget(self.selection_frame)
        
        content_layout = QVBoxLayout()
        content_layout.setSpacing(6)
        
        self.preview_label = QLabel()
        self.preview_label.setObjectName("previewLabel")
        self.preview_label.setWordWrap(True)
        self.preview_label.setMaximumHeight(40)
        self.update_preview_text()
        content_layout.addWidget(self.preview_label)
        
        meta_layout = QHBoxLayout()
        meta_layout.setSpacing(10)
        
        self.char_count = QLabel(f"{len(text)} characters")
        self.char_count.setObjectName("metaText")
        meta_layout.addWidget(self.char_count)
        
        words = len(text.split())
        self.word_count = QLabel(f"{words} words")
        self.word_count.setObjectName("metaText")
        meta_layout.addWidget(self.word_count)
        
        self.time_label = QLabel(QDateTime.currentDateTime().toString("hh:mm:ss"))
        self.time_label.setObjectName("metaText")
        meta_layout.addWidget(self.time_label)
        
        meta_layout.addStretch()
        content_layout.addLayout(meta_layout)
        
        layout.addLayout(content_layout, 1)
        
        actions_layout = QHBoxLayout()
        actions_layout.setSpacing(8)
        
        self.copy_button = QPushButton()
        self.copy_button.setFixedSize(40, 36)
        self.copy_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.copy_button.clicked.connect(self.copy_to_clipboard)
        
        copy_icon_path = os.path.join(os.path.dirname(__file__), "assets", "copy.png")
        if os.path.exists(copy_icon_path):
            copy_icon = QIcon(copy_icon_path)
            self.copy_button.setIcon(copy_icon)
            self.copy_button.setIconSize(QSize(20, 20))
        else:
            self.copy_button.setText("📋")
        
        actions_layout.addWidget(self.copy_button)
        
        self.view_button = QPushButton()
        self.view_button.setFixedSize(40, 36)
        self.view_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.view_button.clicked.connect(self.show_full_text)
        
        view_icon_path = os.path.join(os.path.dirname(__file__), "assets", "visual.png")
        if os.path.exists(view_icon_path):
            view_icon = QIcon(view_icon_path)
            self.view_button.setIcon(view_icon)
            self.view_button.setIconSize(QSize(20, 20))
        else:
            self.view_button.setText("👁️")
        
        actions_layout.addWidget(self.view_button)
        
        layout.addLayout(actions_layout)
        
        self.setLayout(layout)
        self.update_stylesheet()
    
    def update_preview_text(self):
        if len(self.text) > 100:
            preview = self.text[:97] + "..."
        else:
            preview = self.text
        self.preview_label.setText(preview.replace('\n', ' '))
    
    def copy_to_clipboard(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.text)
        
        self.copy_button.setStyleSheet("""
            QPushButton {
                background: #34c759;
                border: none;
                border-radius: 8px;
            }
        """)
        
        if not os.path.exists(os.path.join(os.path.dirname(__file__), "assets", "copy.png")):
            self.copy_button.setText("✓")
        
        QTimer.singleShot(1000, self.reset_copy_button)
    
    def reset_copy_button(self):
        self.update_stylesheet()
        if not os.path.exists(os.path.join(os.path.dirname(__file__), "assets", "copy.png")):
            self.copy_button.setText("📋")
    
    def show_full_text(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Clipboard Item")
        dialog.setMinimumSize(600, 400)
        
        if self.is_dark_mode:
            dialog.setStyleSheet("""
                QDialog { 
                    background-color: #1a1a2e; 
                }
                QLabel { 
                    color: white; 
                }
                QTextEdit { 
                    background-color: #2a2a3a; 
                    color: white; 
                    border: 1px solid #3a3a4a; 
                    border-radius: 10px; 
                    padding: 15px; 
                    font-size: 14px; 
                }
                QPushButton { 
                    background-color: #2a2a3a; 
                    color: white; 
                    border: none; 
                    border-radius: 8px; 
                    padding: 8px 16px; 
                    font-size: 13px; 
                    font-weight: 500; 
                }
                QPushButton:hover { 
                    background-color: #3a3a4a; 
                }
            """)
        else:
            dialog.setStyleSheet("""
                QDialog { 
                    background-color: white; 
                }
                QLabel { 
                    color: black; 
                }
                QTextEdit { 
                    background-color: #f8f9fa; 
                    color: black; 
                    border: 1px solid rgba(60, 60, 67, 0.1); 
                    border-radius: 10px; 
                    padding: 15px; 
                    font-size: 14px; 
                }
                QPushButton { 
                    background-color: #f2f2f7; 
                    color: #007aff; 
                    border: none; 
                    border-radius: 8px; 
                    padding: 8px 16px; 
                    font-size: 13px; 
                    font-weight: 500; 
                }
                QPushButton:hover { 
                    background-color: #e5e5ea; 
                }
            """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        header_label = QLabel("Full Content")
        header_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(header_label)
        
        text_edit = QTextEdit()
        text_edit.setPlainText(self.text)
        text_edit.setReadOnly(True)
        text_edit.setMinimumHeight(250)
        layout.addWidget(text_edit)
        
        button_layout = QHBoxLayout()
        
        copy_btn = QPushButton()
        
        copy_icon_path = os.path.join(os.path.dirname(__file__), "assets", "copy.png")
        if os.path.exists(copy_icon_path):
            copy_icon = QIcon(copy_icon_path)
            copy_btn.setIcon(copy_icon)
            copy_btn.setIconSize(QSize(20, 20))
            copy_btn.setText(" Copy to Clipboard")
        else:
            copy_btn.setText("📋 Copy to Clipboard")
        
        copy_btn.clicked.connect(lambda: self.copy_to_clipboard())
        button_layout.addWidget(copy_btn)
        
        button_layout.addStretch()
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        button_layout.addWidget(close_btn)
        
        layout.addLayout(button_layout)
        
        dialog.setLayout(layout)
        dialog.exec()
    
    def on_checkbox_changed(self, state):
        self.is_selected = state == Qt.CheckState.Checked.value
        if self.item:
            self.item.setSelected(self.is_selected)
        self.update_stylesheet()
    
    def set_selected(self, selected):
        self.is_selected = selected
        self.checkbox.setChecked(selected)
        self.update_stylesheet()
    
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
                self.checkbox.setChecked(not self.checkbox.isChecked())
            else:
                if self.parent_clipboard and self.parent_clipboard.list_widget:
                    self.parent_clipboard.list_widget.clearSelection()
                    if self.item:
                        self.item.setSelected(True)
                        self.checkbox.setChecked(True)
        
        super().mousePressEvent(event)
    
    def set_dark_mode(self, dark):
        self.is_dark_mode = dark
        self.update_stylesheet()
    
    def update_stylesheet(self):
        if self.is_dark_mode:
            base_style = """
                QFrame#clipboardItem {
                    background: #2a2a3a;
                    border-radius: 12px;
                    border: 1px solid #3a3a4a;
                }
                QFrame#clipboardItem:hover {
                    background: #323242;
                    border: 1px solid #4a4a5a;
                }
                QLabel#previewLabel {
                    color: #ffffff;
                    font-size: 14px;
                }
                QLabel#metaText {
                    color: #8e8e93;
                    font-size: 11px;
                }
            """
            
            if self.is_selected:
                base_style += """
                    QFrame#clipboardItem {
                        border: 2px solid #0a84ff;
                        background: #1e3a5f;
                    }
                """
            
            self.setStyleSheet(base_style)
            
            self.selection_frame.setStyleSheet("""
                QFrame#selectionFrame {
                    background: transparent;
                }
                QCheckBox::indicator {
                    width: 20px;
                    height: 20px;
                }
                QCheckBox::indicator:unchecked {
                    border: 2px solid #4a4a5a;
                    background: #2a2a3a;
                    border-radius: 4px;
                }
                QCheckBox::indicator:checked {
                    border: 2px solid #0a84ff;
                    background: #0a84ff;
                    border-radius: 4px;
                }
            """)
            
            self.copy_button.setStyleSheet("""
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
                QPushButton:pressed {
                    background: #2a2a3a;
                }
            """)
            
            self.view_button.setStyleSheet("""
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: #ffffff;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
                QPushButton:pressed {
                    background: #2a2a3a;
                }
            """)
            
        else:
            base_style = """
                QFrame#clipboardItem {
                    background: #ffffff;
                    border-radius: 12px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                QFrame#clipboardItem:hover {
                    background: #f8f9fa;
                    border: 1px solid rgba(60, 60, 67, 0.2);
                }
                QLabel#previewLabel {
                    color: #000000;
                    font-size: 14px;
                }
                QLabel#metaText {
                    color: #8e8e93;
                    font-size: 11px;
                }
            """
            
            if self.is_selected:
                base_style += """
                    QFrame#clipboardItem {
                        border: 2px solid #007aff;
                        background: #f0f7ff;
                    }
                """
            
            self.setStyleSheet(base_style)
            
            self.selection_frame.setStyleSheet("""
                QFrame#selectionFrame {
                    background: transparent;
                }
                QCheckBox::indicator {
                    width: 20px;
                    height: 20px;
                }
                QCheckBox::indicator:unchecked {
                    border: 2px solid rgba(60, 60, 67, 0.2);
                    background: white;
                    border-radius: 4px;
                }
                QCheckBox::indicator:checked {
                    border: 2px solid #007aff;
                    background: #007aff;
                    border-radius: 4px;
                }
            """)
            
            self.copy_button.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:pressed {
                    background: #d1d1d6;
                }
            """)
            
            self.view_button.setStyleSheet("""
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:pressed {
                    background: #d1d1d6;
                }
            """)
        
        if self.is_dark_mode:
            self.copy_button.setStyleSheet(self.copy_button.styleSheet() + "color: #0a84ff;")
            self.view_button.setStyleSheet(self.view_button.styleSheet() + "color: #0a84ff;")
        else:
            self.copy_button.setStyleSheet(self.copy_button.styleSheet() + "color: #007aff;")
            self.view_button.setStyleSheet(self.view_button.styleSheet() + "color: #007aff;")

class ClipboardWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.clipboard = QApplication.clipboard()
        self.clipboard.dataChanged.connect(self.add_clipboard_item)
        self.max_items = 50
        self.last_text = ""
        self.dark_mode = False
        
        layout = QVBoxLayout()
        
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        self.list_widget.setSpacing(5)
        
        info_layout = QHBoxLayout()
        self.info_label = QLabel(f"0 / {self.max_items} items")
        info_layout.addWidget(self.info_label)
        info_layout.addStretch()
        
        btn_layout = QHBoxLayout()
        self.btn_delete = QPushButton("Delete Selected")
        self.btn_delete.clicked.connect(self.delete_selected)
        self.btn_clear = QPushButton("Clear All")
        self.btn_clear.clicked.connect(self.clear_all)
        
        btn_layout.addWidget(self.btn_delete)
        btn_layout.addWidget(self.btn_clear)
        btn_layout.addStretch()
        
        layout.addWidget(self.list_widget)
        layout.addLayout(info_layout)
        layout.addLayout(btn_layout)
        
        self.setLayout(layout)
        
    def add_clipboard_item(self):
        try:
            text = self.clipboard.text()
            if text and text.strip() and text != self.last_text:
                self.last_text = text
                
                while self.list_widget.count() >= self.max_items:
                    item = self.list_widget.takeItem(self.list_widget.count() - 1)
                    widget = self.list_widget.itemWidget(item)
                    if widget:
                        widget.setParent(None)
                        widget.deleteLater()
                
                item = QListWidgetItem(self.list_widget)
                item.setSizeHint(QSize(0, 60))
                
                custom_widget = ClipboardItemWidget(text)
                custom_widget.set_dark_mode(self.dark_mode)
                
                self.list_widget.insertItem(0, item)
                self.list_widget.setItemWidget(item, custom_widget)
                self.update_info_label()
        except Exception:
            pass
            
    def delete_selected(self):
        try:
            current_row = self.list_widget.currentRow()
            if current_row >= 0:
                item = self.list_widget.takeItem(current_row)
                widget = self.list_widget.itemWidget(item)
                if widget:
                    widget.setParent(None)
                    widget.deleteLater()
                self.update_info_label()
                if self.list_widget.count() == 0:
                    self.last_text = ""
        except Exception:
            pass
            
    def clear_all(self):
        try:
            while self.list_widget.count() > 0:
                item = self.list_widget.takeItem(0)
                widget = self.list_widget.itemWidget(item)
                if widget:
                    widget.setParent(None)
                    widget.deleteLater()
            self.list_widget.clear()
            self.last_text = ""
            self.update_info_label()
        except Exception:
            pass
        
    def update_info_label(self):
        self.info_label.setText(f"{self.list_widget.count()} / {self.max_items} items")
        
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            widget = self.list_widget.itemWidget(item)
            if widget and hasattr(widget, 'set_dark_mode'):
                widget.set_dark_mode(dark)
        self.update_stylesheet()
        
    def update_stylesheet(self):
        if self.dark_mode:
            self.list_widget.setStyleSheet("""
                QListWidget { background: #1a1a2e; border: 1px solid #333; border-radius: 5px; outline: none; }
                QListWidget::item { background: transparent; }
            """)
            self.info_label.setStyleSheet("color: #aaa; font-size: 11px; padding: 5px;")
        else:
            self.list_widget.setStyleSheet("""
                QListWidget { background: #f8f9fa; border: 1px solid #ddd; border-radius: 5px; outline: none; }
                QListWidget::item { background: transparent; }
            """)
            self.info_label.setStyleSheet("color: #666; font-size: 11px; padding: 5px;")

class CustomWebEnginePage(QWebEnginePage):
    def __init__(self, profile, download_manager, notification_manager, parent=None):
        super().__init__(profile, parent)
        self.download_manager = download_manager
        self.notification_manager = notification_manager
        self.profile = profile
        self.profile.downloadRequested.connect(self.handle_download)
        self.featurePermissionRequested.connect(self.handle_permission_request)
        self.profile.setNotificationPresenter(self.present_notification)
        
        # Enable clipboard access
        settings = self.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanPaste, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
        
        self.featurePermissionRequested.connect(self.on_feature_permission_requested)
        self.titleChanged.connect(self.on_title_changed)
    
    def createWindow(self, window_type):
        if window_type == QWebEnginePage.WebWindowType.WebBrowserTab:
            # Buka dalam tab baru
            main_window = self.get_main_window()
            if main_window:
                # Return page baru yang akan di-populate dengan URL nanti
                new_page = CustomWebEnginePage(self.profile, self.download_manager, 
                                            self.notification_manager, None)
                new_page.urlChanged.connect(lambda url: self.handle_new_window_url(url, main_window))
                return new_page
        return super().createWindow(window_type)

    def handle_new_window_url(self, url, main_window):
        """Handle URL dari window baru yang di-create"""
        if url and url.isValid():
            main_window.open_url_in_new_tab(url.toString())

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        modifiers = QApplication.keyboardModifiers()
        
        if (navigation_type == QWebEnginePage.NavigationType.NavigationTypeLinkClicked and
            (modifiers & Qt.KeyboardModifier.ControlModifier or
            QApplication.mouseButtons() & Qt.MouseButton.MiddleButton)):
            
            
            main_window = self.get_main_window()
            if main_window and hasattr(main_window, 'open_url_in_new_tab'):
                main_window.open_url_in_new_tab(url.toString())
                return False  
        return super().acceptNavigationRequest(url, navigation_type, is_main_frame)

    def get_main_window(self):
        app = QApplication.instance()
        for widget in app.topLevelWidgets():
            if isinstance(widget, ALINDashboard):
                return widget
        return None
    
    def on_title_changed(self, title):
        """Handle page title change"""
        if self.parent():
            # Find parent webview
            webview = self.parent()
            while webview and not hasattr(webview, 'update_tab_title'):
                webview = webview.parent()
            
            if webview and hasattr(webview, 'update_tab_title'):
                webview.update_tab_title(title)
    
    def on_feature_permission_requested(self, url, feature):
        """Grant clipboard permissions automatically"""
        if feature == QWebEnginePage.Feature.ClipboardReadWrite:
            print(f"Granting clipboard permission for {url.toString()}")
            self.setFeaturePermission(
                url, 
                feature, 
                QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
            )
            return True
        return False
    
    def present_notification(self, notification):
        """Handle received notification - method ini akan dipanggil otomatis"""
        if self.notification_manager:
            self.notification_manager.handle_notification(notification)
            
            print(f"Notification received: {notification.title()} - {notification.message()}")
    
    def on_notification_received(self, notification):
        """Handle received notification"""
        if self.notification_manager:
            self.notification_manager.handle_notification(notification)
            
    def handle_download(self, download):
        self.download_manager.handle_download(download)
    
    def handle_permission_request(self, url, feature):
        if self.notification_manager:
            class SimplePermissionRequest:
                def __init__(self, url, feature, page):
                    self._url = url
                    self._feature = feature
                    self._page = page
                    self._granted = False
                
                def requestingOrigin(self):
                    return QUrl(self._url)
                
                def permissionType(self):
                    return self._feature
                
                def grant(self):
                    self._granted = True
                    self._page.setFeaturePermission(
                        QUrl(self._url),
                        self._feature,
                        QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
                    )
                
                def deny(self):
                    self._page.setFeaturePermission(
                        QUrl(self._url),
                        self._feature,
                        QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
                    )
            
            request = SimplePermissionRequest(url.toString(), feature, self)
            
            if feature == QWebEnginePage.Feature.Notifications:
                url_str = url.toString()
                if self.notification_manager and self.notification_manager.check_and_allow_notifications(url_str):
                    self.setFeaturePermission(
                        url, 
                        feature, 
                        QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
                    )
                    return True
                else:
                    self.setFeaturePermission(
                        url, 
                        feature, 
                        QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
                    )
                    return True
        
        return False
        
    def present_notification(self, notification):
        if self.notification_manager:
            self.notification_manager.handle_notification(notification)
    
    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        return True

class MusicPlayerWidget(QWidget):
    shown = pyqtSignal()
    hidden = pyqtSignal()
    def __init__(self):
        super().__init__()
        self.dark_mode = False
        self.current_player = None
        self.playing = False
        self.title = ""
        self.artist = ""
        self.album = ""
        self.position = 0
        self.length = 0
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_player_info)
        self.timer.start(1000)
        
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(25)
        
        header_container = QWidget()
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        header = QLabel("Now Playing")
        header.setObjectName("musicHeader")
        header_font = QFont("SF Pro Display", 28, QFont.Weight.DemiBold)
        header.setFont(header_font)
        
        self.player_status = QLabel("● Live")
        self.player_status.setObjectName("playerStatus")
        status_font = QFont("SF Pro Text", 12)
        self.player_status.setFont(status_font)
        self.player_status.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        
        header_layout.addWidget(header)
        header_layout.addStretch()
        header_layout.addWidget(self.player_status)
        header_container.setLayout(header_layout)
        main_layout.addWidget(header_container)
        
        artwork_container = QFrame()
        artwork_container.setObjectName("artworkContainer")
        artwork_container.setFixedSize(320, 320)
        artwork_container.setContentsMargins(20, 20, 20, 20)
        
        artwork_layout = QVBoxLayout()
        artwork_layout.setContentsMargins(0, 0, 0, 0)
        
        self.artwork_label = QLabel()
        self.artwork_label.setObjectName("artworkLabel")
        self.artwork_label.setFixedSize(280, 280)
        self.artwork_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.update_artwork()
        
        artwork_layout.addWidget(self.artwork_label, 0, Qt.AlignmentFlag.AlignCenter)
        artwork_container.setLayout(artwork_layout)
        
        artwork_wrapper = QWidget()
        artwork_wrapper_layout = QHBoxLayout()
        artwork_wrapper_layout.setContentsMargins(0, 10, 0, 20)
        artwork_wrapper_layout.addStretch()
        artwork_wrapper_layout.addWidget(artwork_container)
        artwork_wrapper_layout.addStretch()
        artwork_wrapper.setLayout(artwork_wrapper_layout)
        main_layout.addWidget(artwork_wrapper)
        
        track_info_container = QWidget()
        track_info_layout = QVBoxLayout()
        track_info_layout.setSpacing(8)
        track_info_layout.setContentsMargins(10, 0, 10, 0)
        
        self.now_playing_label = QLabel("Nothing Playing")
        self.now_playing_label.setObjectName("nowPlaying")
        now_playing_font = QFont("SF Pro Display", 24, QFont.Weight.Medium)
        self.now_playing_label.setFont(now_playing_font)
        self.now_playing_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.now_playing_label.setWordWrap(True)
        track_info_layout.addWidget(self.now_playing_label)
        
        self.artist_label = QLabel("")
        self.artist_label.setObjectName("artistLabel")
        artist_font = QFont("SF Pro Text", 16)
        self.artist_label.setFont(artist_font)
        self.artist_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.artist_label.setWordWrap(True)
        track_info_layout.addWidget(self.artist_label)
        
        track_info_container.setLayout(track_info_layout)
        main_layout.addWidget(track_info_container)
        
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_layout = QVBoxLayout()
        progress_layout.setSpacing(8)
        progress_layout.setContentsMargins(10, 10, 10, 10)
        
        time_layout = QHBoxLayout()
        time_layout.setContentsMargins(0, 0, 0, 0)
        
        self.current_time = QLabel("0:00")
        self.current_time.setObjectName("timeLabel")
        current_time_font = QFont("SF Pro Text", 13, QFont.Weight.Medium)
        self.current_time.setFont(current_time_font)
        
        self.total_time = QLabel("0:00")
        self.total_time.setObjectName("timeLabel")
        self.total_time.setFont(current_time_font)
        
        time_layout.addWidget(self.current_time)
        time_layout.addStretch()
        time_layout.addWidget(self.total_time)
        progress_layout.addLayout(time_layout)
        
        progress_bar_container = QFrame()
        progress_bar_container.setObjectName("progressBarContainer")
        progress_bar_container.setFixedHeight(32)
        
        progress_bar_layout = QHBoxLayout()
        progress_bar_layout.setContentsMargins(0, 0, 0, 0)
        
        self.progress_bar = QFrame()
        self.progress_bar.setObjectName("progressBar")
        self.progress_bar.setFixedHeight(5)
        
        self.progress_fill = QFrame(self.progress_bar)
        self.progress_fill.setObjectName("progressFill")
        self.progress_fill.setFixedHeight(5)
        self.progress_fill.setFixedWidth(0)
        
        self.progress_knob = QFrame(self.progress_bar)
        self.progress_knob.setObjectName("progressKnob")
        self.progress_knob.setFixedSize(15, 15)
        self.progress_knob.hide()
        
        progress_bar_layout.addWidget(self.progress_bar)
        progress_bar_container.setLayout(progress_bar_layout)
        progress_layout.addWidget(progress_bar_container)
        
        progress_container.setLayout(progress_layout)
        main_layout.addWidget(progress_container)
        
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_layout = QHBoxLayout()
        controls_layout.setSpacing(25)
        controls_layout.setContentsMargins(20, 20, 20, 30)
        
        self.shuffle_btn = QPushButton()
        self.shuffle_btn.setObjectName("controlButton")
        self.shuffle_btn.setFixedSize(44, 44)
        self.shuffle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.shuffle_btn.clicked.connect(self.toggle_shuffle)
        
        shuffle_path = os.path.join(os.path.dirname(__file__), "assets", "shuffle.png")
        if os.path.exists(shuffle_path):
            self.shuffle_btn.setIcon(QIcon(shuffle_path))
            self.shuffle_btn.setIconSize(QSize(22, 22))
        else:
            self.shuffle_btn.setText("🔀")
        
        self.prev_btn = QPushButton()
        self.prev_btn.setObjectName("controlButton")
        self.prev_btn.setFixedSize(44, 44)
        self.prev_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.prev_btn.clicked.connect(self.previous)
        
        prev_path = os.path.join(os.path.dirname(__file__), "assets", "rewind.png")
        if os.path.exists(prev_path):
            self.prev_btn.setIcon(QIcon(prev_path))
            self.prev_btn.setIconSize(QSize(22, 22))
        else:
            self.prev_btn.setText("⏮")
        
        self.play_btn = QPushButton()
        self.play_btn.setObjectName("playButton")
        self.play_btn.setFixedSize(72, 72)
        self.play_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play_btn.clicked.connect(self.toggle_play)
        
        play_path = os.path.join(os.path.dirname(__file__), "assets", "play.png")
        if os.path.exists(play_path):
            self.play_btn.setIcon(QIcon(play_path))
            self.play_btn.setIconSize(QSize(32, 32))
        else:
            self.play_btn.setText("▶")
            play_font = QFont("SF Pro Text", 24)
            self.play_btn.setFont(play_font)
        
        self.next_btn = QPushButton()
        self.next_btn.setObjectName("controlButton")
        self.next_btn.setFixedSize(44, 44)
        self.next_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_btn.clicked.connect(self.next)
        
        next_path = os.path.join(os.path.dirname(__file__), "assets", "next.png")
        if os.path.exists(next_path):
            self.next_btn.setIcon(QIcon(next_path))
            self.next_btn.setIconSize(QSize(22, 22))
        else:
            self.next_btn.setText("⏭")
        
        self.repeat_btn = QPushButton()
        self.repeat_btn.setObjectName("controlButton")
        self.repeat_btn.setFixedSize(44, 44)
        self.repeat_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.repeat_btn.clicked.connect(self.toggle_repeat)
        
        repeat_path = os.path.join(os.path.dirname(__file__), "assets", "repeat.png")
        if os.path.exists(repeat_path):
            self.repeat_btn.setIcon(QIcon(repeat_path))
            self.repeat_btn.setIconSize(QSize(22, 22))
        else:
            self.repeat_btn.setText("🔁")
        
        controls_layout.addStretch()
        controls_layout.addWidget(self.shuffle_btn)
        controls_layout.addWidget(self.prev_btn)
        controls_layout.addWidget(self.play_btn)
        controls_layout.addWidget(self.next_btn)
        controls_layout.addWidget(self.repeat_btn)
        controls_layout.addStretch()
        
        controls_container.setLayout(controls_layout)
        main_layout.addWidget(controls_container)
        
        player_info_container = QFrame()
        player_info_container.setObjectName("playerInfoContainer")
        player_info_layout = QHBoxLayout()
        player_info_layout.setContentsMargins(15, 12, 15, 12)
        
        player_icon_label = QLabel("🎵")
        player_icon_label.setObjectName("playerIcon")
        player_icon_label.setFixedSize(32, 32)
        player_icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.player_label = QLabel("No player detected")
        self.player_label.setObjectName("playerLabel")
        player_label_font = QFont("SF Pro Text", 13, QFont.Weight.Medium)
        self.player_label.setFont(player_label_font)
        
        self.connection_status = QLabel()
        self.connection_status.setObjectName("connectionStatus")
        self.connection_status.setFixedSize(8, 8)
        self.connection_status.setStyleSheet("""
            QLabel#connectionStatus {
                background: #ff3b30;
                border-radius: 4px;
            }
        """)
        
        player_info_layout.addWidget(player_icon_label)
        player_info_layout.addWidget(self.player_label, 1)
        player_info_layout.addWidget(self.connection_status)
        
        player_info_container.setLayout(player_info_layout)
        main_layout.addWidget(player_info_container)
        
        main_layout.addStretch()
        
        self.setLayout(main_layout)
        self.update_stylesheet()
        self.detect_player()
        
        self.progress_bar.installEventFilter(self)
    
    def update_artwork(self):
        ios_image_path = os.path.join(os.path.dirname(__file__), "assets", "ios.png")
        
        if os.path.exists(ios_image_path):
            pixmap = QPixmap(ios_image_path)
            scaled_pixmap = pixmap.scaled(180, 180, 
                                        Qt.AspectRatioMode.KeepAspectRatio, 
                                        Qt.TransformationMode.SmoothTransformation)
            self.artwork_label.setPixmap(scaled_pixmap)
        else:
            pixmap = QPixmap(280, 280)
            pixmap.fill(Qt.GlobalColor.transparent)
            
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            if self.dark_mode:
                gradient = QLinearGradient(0, 0, 280, 280)
                gradient.setColorAt(0, QColor(98, 114, 164))
                gradient.setColorAt(0.5, QColor(73, 86, 125))
                gradient.setColorAt(1, QColor(52, 61, 89))
                
                painter.setBrush(gradient)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(0, 0, 280, 280, 20, 20)
                
                painter.setOpacity(0.1)
                painter.setBrush(QColor(255, 255, 255))
                for i in range(0, 280, 20):
                    painter.drawEllipse(i, i % 40, 8, 8)
            else:
                gradient = QLinearGradient(0, 0, 280, 280)
                gradient.setColorAt(0, QColor(255, 214, 186))
                gradient.setColorAt(0.5, QColor(255, 184, 184))
                gradient.setColorAt(1, QColor(255, 154, 184))
                
                painter.setBrush(gradient)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(0, 0, 280, 280, 20, 20)
                
                painter.setOpacity(0.1)
                painter.setBrush(QColor(255, 255, 255))
                for i in range(0, 280, 20):
                    painter.drawEllipse(i, i % 40, 8, 8)
            
            painter.setOpacity(0.2)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(255, 255, 255))
            
            painter.save()
            painter.translate(140, 140)
            painter.rotate(-15)
            
            note_font = QFont("SF Pro Display", 80, QFont.Weight.Thin)
            painter.setFont(note_font)
            painter.setPen(QColor(255, 255, 255, 50))
            painter.drawText(-40, -40, 80, 80, Qt.AlignmentFlag.AlignCenter, "♪")
            
            painter.restore()
            painter.end()
            self.artwork_label.setPixmap(pixmap)
        
    def eventFilter(self, obj, event):
        if obj == self.progress_bar:
            if event.type() == event.Type.Enter:
                self.progress_knob.show()
            elif event.type() == event.Type.Leave:
                self.progress_knob.hide()
            elif event.type() == event.Type.MouseMove and self.length > 0:
                pos = event.position().x()
                width = self.progress_bar.width()
                if width > 0:
                    knob_x = max(0, min(pos - self.progress_knob.width() // 2, width - self.progress_knob.width()))
                    self.progress_knob.move(int(knob_x), (self.progress_bar.height() - self.progress_knob.height()) // 2)
                    
                    new_position = (pos / width) * self.length
                    self.current_time.setText(self.format_time(new_position))
            elif event.type() == event.Type.MouseButtonPress and self.length > 0:
                pos = event.position().x()
                width = self.progress_bar.width()
                if width > 0:
                    new_position = (pos / width) * self.length
                    if self.current_player:
                        try:
                            subprocess.run(['playerctl', '--player', self.current_player, 'position', str(new_position)])
                        except:
                            pass
        return super().eventFilter(obj, event)
    
    def detect_player(self):
        try:
            result = subprocess.run(['playerctl', '-l'], capture_output=True, text=True)
            if result.returncode == 0:
                players = result.stdout.strip().split('\n')
                if players and players[0]:
                    self.current_player = players[0]
                    self.connection_status.setStyleSheet("""
                        QLabel#connectionStatus {
                            background: #34c759;
                            border-radius: 4px;
                        }
                    """)
                    self.update_player_info()
                    return
        except:
            pass
        self.current_player = None
        self.now_playing_label.setText("No player detected")
        self.artist_label.setText("")
        self.player_label.setText("Install playerctl and open a media player")
        self.connection_status.setStyleSheet("""
            QLabel#connectionStatus {
                background: #ff3b30;
                border-radius: 4px;
            }
        """)
    
    def showEvent(self, event):
        super().showEvent(event)
        
        if hasattr(self, 'refresh_timer') and not self.refresh_timer.isActive():
            self.refresh_timer.start(30000)
        
        if hasattr(self, 'Energy_status_timer') and not self.Energy_status_timer.isActive():
            self.Energy_status_timer.start(60000) 
    
    def hideEvent(self, event):
        super().hideEvent(event)
        if hasattr(self, 'refresh_timer'):
            self.refresh_timer.stop()
        
        if hasattr(self, 'player_timer'):
            self.player_timer.stop()
        
        if hasattr(self, 'Energy_status_timer'):
            self.Energy_status_timer.stop()
        if hasattr(self, 'music_player') and hasattr(self.music_player, 'timer'):
            self.music_player.timer.stop()

    def update_player_info(self):
        if not self.current_player:
            self.detect_player()
            return
        
        try:
            metadata = subprocess.run(['playerctl', '--player', self.current_player, 'metadata'], capture_output=True, text=True)
            if metadata.returncode != 0:
                self.detect_player()
                return
            
            title_result = subprocess.run(['playerctl', '--player', self.current_player, 'metadata', 'title'], capture_output=True, text=True)
            if title_result.returncode == 0 and title_result.stdout.strip():
                self.title = title_result.stdout.strip()
            else:
                self.title = "Unknown Title"
            
            artist_result = subprocess.run(['playerctl', '--player', self.current_player, 'metadata', 'artist'], capture_output=True, text=True)
            if artist_result.returncode == 0 and artist_result.stdout.strip():
                self.artist = artist_result.stdout.strip()
            else:
                self.artist = "Unknown Artist"
            
            album_result = subprocess.run(['playerctl', '--player', self.current_player, 'metadata', 'album'], capture_output=True, text=True)
            if album_result.returncode == 0 and album_result.stdout.strip():
                self.album = album_result.stdout.strip()
            else:
                self.album = ""
            
            position_result = subprocess.run(['playerctl', '--player', self.current_player, 'position'], capture_output=True, text=True)
            if position_result.returncode == 0 and position_result.stdout.strip():
                self.position = float(position_result.stdout.strip())
            
            length_result = subprocess.run(['playerctl', '--player', self.current_player, 'metadata', 'mpris:length'], capture_output=True, text=True)
            if length_result.returncode == 0 and length_result.stdout.strip():
                self.length = float(length_result.stdout.strip()) / 1000000
            else:
                self.length = 0
            
            status_result = subprocess.run(['playerctl', '--player', self.current_player, 'status'], capture_output=True, text=True)
            if status_result.returncode == 0:
                self.playing = status_result.stdout.strip() == "Playing"
            
            self.now_playing_label.setText(self.title)
            
            artist_text = self.artist
            if self.album:
                artist_text += f" • {self.album}"
            self.artist_label.setText(artist_text)
            
            self.current_time.setText(self.format_time(self.position))
            self.total_time.setText(self.format_time(self.length))
            
            if self.length > 0:
                progress_width = int((self.position / self.length) * self.progress_bar.width())
                self.progress_fill.setFixedWidth(progress_width)
                
                knob_x = max(0, min(progress_width - self.progress_knob.width() // 2, 
                                   self.progress_bar.width() - self.progress_knob.width()))
                self.progress_knob.move(int(knob_x), (self.progress_bar.height() - self.progress_knob.height()) // 2)
            
            if self.playing:
                pause_path = os.path.join(os.path.dirname(__file__), "assets", "pause.png")
                if os.path.exists(pause_path):
                    self.play_btn.setIcon(QIcon(pause_path))
                else:
                    self.play_btn.setText("⏸")
                self.player_status.setText("● Live")
            else:
                play_path = os.path.join(os.path.dirname(__file__), "assets", "play.png")
                if os.path.exists(play_path):
                    self.play_btn.setIcon(QIcon(play_path))
                else:
                    self.play_btn.setText("▶")
                self.player_status.setText("○ Paused")
            
            player_display = self.current_player
            if "youtube" in player_display.lower():
                player_display = "YouTube Music"
            elif "spotify" in player_display.lower():
                player_display = "Spotify"
            elif "firefox" in player_display.lower():
                player_display = "Firefox"
            elif "chrome" in player_display.lower():
                player_display = "Chrome"
            elif "vlc" in player_display.lower():
                player_display = "VLC"
            
            self.player_label.setText(player_display)
                
        except:
            self.detect_player()
    
    def format_time(self, seconds):
        if seconds <= 0:
            return "0:00"
        minutes = int(seconds // 60)
        seconds = int(seconds % 60)
        return f"{minutes}:{seconds:02d}"
    
    def toggle_play(self):
        if not self.current_player:
            return
        try:
            if self.playing:
                subprocess.run(['playerctl', '--player', self.current_player, 'pause'])
            else:
                subprocess.run(['playerctl', '--player', self.current_player, 'play'])
        except:
            pass
    
    def previous(self):
        if not self.current_player:
            return
        try:
            subprocess.run(['playerctl', '--player', self.current_player, 'previous'])
        except:
            pass
    
    def next(self):
        if not self.current_player:
            return
        try:
            subprocess.run(['playerctl', '--player', self.current_player, 'next'])
        except:
            pass
    
    def toggle_shuffle(self):
        if self.shuffle_btn.property("active"):
            self.shuffle_btn.setProperty("active", False)
            self.shuffle_btn.setStyleSheet(self.get_control_button_style())
        else:
            self.shuffle_btn.setProperty("active", True)
            self.shuffle_btn.setStyleSheet(self.get_active_control_button_style())
    
    def toggle_repeat(self):
        if self.repeat_btn.property("active"):
            self.repeat_btn.setProperty("active", False)
            self.repeat_btn.setStyleSheet(self.get_control_button_style())
        else:
            self.repeat_btn.setProperty("active", True)
            self.repeat_btn.setStyleSheet(self.get_active_control_button_style())
    
    def set_dark_mode(self, dark):
        self.dark_mode = dark
        self.update_artwork()
        self.update_stylesheet()
    
    def get_control_button_style(self):
        if self.dark_mode:
            return """
                QPushButton#controlButton {
                    background: #2a2a3a;
                    border: none;
                    border-radius: 22px;
                    color: #ffffff;
                }
                QPushButton#controlButton:hover {
                    background: #3a3a4a;
                }
                QPushButton#controlButton:pressed {
                    background: #1a1a2a;
                }
            """
        else:
            return """
                QPushButton#controlButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 22px;
                    color: #007aff;
                }
                QPushButton#controlButton:hover {
                    background: #e5e5ea;
                }
                QPushButton#controlButton:pressed {
                    background: #d1d1d6;
                }
            """
    
    def get_active_control_button_style(self):
        if self.dark_mode:
            return """
                QPushButton#controlButton {
                    background: #0a84ff;
                    border: none;
                    border-radius: 22px;
                    color: #ffffff;
                }
                QPushButton#controlButton:hover {
                    background: #409cff;
                }
            """
        else:
            return """
                QPushButton#controlButton {
                    background: #007aff;
                    border: none;
                    border-radius: 22px;
                    color: #ffffff;
                }
                QPushButton#controlButton:hover {
                    background: #005fc7;
                }
            """
    
    def update_stylesheet(self):
        if self.dark_mode:
            self.setStyleSheet("""
                QLabel#musicHeader {
                    color: #ffffff;
                    font-size: 28px;
                    font-weight: 600;
                    letter-spacing: -0.5px;
                }
                
                QLabel#playerStatus {
                    color: #34c759;
                    font-size: 12px;
                    font-weight: 500;
                }
                
                QFrame#artworkContainer {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 rgba(255,255,255,0.1),
                        stop:0.5 rgba(255,255,255,0.05),
                        stop:1 rgba(255,255,255,0));
                    border-radius: 30px;
                }
                
                QLabel#nowPlaying {
                    color: #ffffff;
                    font-size: 24px;
                    font-weight: 500;
                    letter-spacing: -0.5px;
                }
                
                QLabel#artistLabel {
                    color: #8e8e93;
                    font-size: 16px;
                    font-weight: 400;
                }
                
                QWidget#progressContainer {
                    background: transparent;
                }
                
                QLabel#timeLabel {
                    color: #8e8e93;
                    font-size: 13px;
                    font-weight: 500;
                }
                
                QFrame#progressBarContainer {
                    background: transparent;
                }
                
                QFrame#progressBar {
                    background: #3a3a4a;
                    border-radius: 3px;
                }
                
                QFrame#progressFill {
                    background: #0a84ff;
                    border-radius: 3px;
                }
                
                QFrame#progressKnob {
                    background: #ffffff;
                    border: 2px solid #0a84ff;
                    border-radius: 8px;
                }
                
                QWidget#controlsContainer {
                    background: transparent;
                }
                
                QPushButton#playButton {
                    background: #0a84ff;
                    border: none;
                    border-radius: 36px;
                    color: #ffffff;
                }
                QPushButton#playButton:hover {
                    background: #409cff;
                }
                QPushButton#playButton:pressed {
                    background: #0063ce;
                }
                
                QFrame#playerInfoContainer {
                    background: #2a2a3a;
                    border-radius: 20px;
                    border: 1px solid #3a3a4a;
                }
                
                QLabel#playerIcon {
                    background: #3a3a4a;
                    border-radius: 16px;
                    color: #ffffff;
                    font-size: 16px;
                }
                
                QLabel#playerLabel {
                    color: #ffffff;
                    font-size: 13px;
                    font-weight: 500;
                }
            """)
            
            self.shuffle_btn.setStyleSheet(self.get_control_button_style())
            self.prev_btn.setStyleSheet(self.get_control_button_style())
            self.next_btn.setStyleSheet(self.get_control_button_style())
            self.repeat_btn.setStyleSheet(self.get_control_button_style())
            
        else:
            self.setStyleSheet("""
                QLabel#musicHeader {
                    color: #000000;
                    font-size: 28px;
                    font-weight: 600;
                    letter-spacing: -0.5px;
                }
                
                QLabel#playerStatus {
                    color: #34c759;
                    font-size: 12px;
                    font-weight: 500;
                }
                
                QFrame#artworkContainer {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 rgba(0,0,0,0.03),
                        stop:0.5 rgba(0,0,0,0.02),
                        stop:1 rgba(0,0,0,0));
                    border-radius: 30px;
                }
                
                QLabel#nowPlaying {
                    color: #000000;
                    font-size: 24px;
                    font-weight: 500;
                    letter-spacing: -0.5px;
                }
                
                QLabel#artistLabel {
                    color: #8e8e93;
                    font-size: 16px;
                    font-weight: 400;
                }
                
                QWidget#progressContainer {
                    background: transparent;
                }
                
                QLabel#timeLabel {
                    color: #8e8e93;
                    font-size: 13px;
                    font-weight: 500;
                }
                
                QFrame#progressBarContainer {
                    background: transparent;
                }
                
                QFrame#progressBar {
                    background: #e9e9ed;
                    border-radius: 3px;
                }
                
                QFrame#progressFill {
                    background: #007aff;
                    border-radius: 3px;
                }
                
                QFrame#progressKnob {
                    background: #ffffff;
                    border: 2px solid #007aff;
                    border-radius: 8px;
                }
                
                QWidget#controlsContainer {
                    background: transparent;
                }
                
                QPushButton#playButton {
                    background: #007aff;
                    border: none;
                    border-radius: 36px;
                    color: #ffffff;
                }
                QPushButton#playButton:hover {
                    background: #005fc7;
                }
                QPushButton#playButton:pressed {
                    background: #004299;
                }
                
                QFrame#playerInfoContainer {
                    background: #ffffff;
                    border-radius: 20px;
                    border: 1px solid rgba(60, 60, 67, 0.1);
                }
                
                QLabel#playerIcon {
                    background: #f2f2f7;
                    border-radius: 16px;
                    color: #007aff;
                    font-size: 16px;
                }
                
                QLabel#playerLabel {
                    color: #000000;
                    font-size: 13px;
                    font-weight: 500;
                }
            """)
            
            self.shuffle_btn.setStyleSheet(self.get_control_button_style())
            self.prev_btn.setStyleSheet(self.get_control_button_style())
            self.next_btn.setStyleSheet(self.get_control_button_style())
            self.repeat_btn.setStyleSheet(self.get_control_button_style())

class NavigationBar(QFrame):
    """Custom navigation bar for web views with back, forward, refresh buttons"""
    def __init__(self, webview, parent=None):
        super().__init__(parent)
        self.webview = webview
        self.setObjectName("navigationBar")
        self.setFixedHeight(50)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(10, 5, 10, 5)
        layout.setSpacing(8)
        
        # Back button
        self.back_btn = QPushButton("←")
        self.back_btn.setFixedSize(36, 36)
        self.back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_btn.clicked.connect(self.go_back)
        self.back_btn.setToolTip("Back")
        
        # Forward button
        self.forward_btn = QPushButton("→")
        self.forward_btn.setFixedSize(36, 36)
        self.forward_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.forward_btn.clicked.connect(self.go_forward)
        self.forward_btn.setToolTip("Forward")
        
        # Refresh button
        self.refresh_btn = QPushButton("↻")
        self.refresh_btn.setFixedSize(36, 36)
        self.refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.refresh_page)
        self.refresh_btn.setToolTip("Refresh")
        
        # URL bar
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Enter URL...")
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        
        # Go button
        self.go_btn = QPushButton("Go")
        self.go_btn.setFixedSize(50, 36)
        self.go_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.go_btn.clicked.connect(self.navigate_to_url)
        
        layout.addWidget(self.back_btn)
        layout.addWidget(self.forward_btn)
        layout.addWidget(self.refresh_btn)
        layout.addWidget(self.url_bar, 1)
        layout.addWidget(self.go_btn)
        
        self.setLayout(layout)
        
        # Connect webview signals
        if self.webview:
            self.webview.urlChanged.connect(self.update_url)
            self.webview.loadFinished.connect(self.update_navigation_buttons)
    
    def go_back(self):
        if self.webview and self.webview.history().canGoBack():
            self.webview.back()
    
    def go_forward(self):
        if self.webview and self.webview.history().canGoForward():
            self.webview.forward()
    
    def refresh_page(self):
        if self.webview:
            self.webview.reload()
    
    def navigate_to_url(self):
        url = self.url_bar.text().strip()
        if url:
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            self.webview.setUrl(QUrl(url))
    
    def update_url(self, url):
        self.url_bar.setText(url.toString())
        self.update_navigation_buttons()
    
    def update_navigation_buttons(self):
        if self.webview:
            self.back_btn.setEnabled(self.webview.history().canGoBack())
            self.forward_btn.setEnabled(self.webview.history().canGoForward())
    
    def set_dark_mode(self, dark):
        if dark:
            self.setStyleSheet("""
                QFrame#navigationBar {
                    background: #2a2a3a;
                    border-bottom: 1px solid #3a3a4a;
                }
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: white;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
                QPushButton:disabled {
                    background: #2a2a3a;
                    color: #6a6a7a;
                }
                QLineEdit {
                    background: #3a3a4a;
                    border: 1px solid #4a4a5a;
                    border-radius: 8px;
                    color: white;
                    padding: 5px 10px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame#navigationBar {
                    background: white;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:disabled {
                    background: #f2f2f7;
                    color: #c7c7cc;
                }
                QLineEdit {
                    background: #f2f2f7;
                    border: 1px solid #e5e5ea;
                    border-radius: 8px;
                    color: black;
                    padding: 5px 10px;
                }
            """)

class WebViewWithNav(QWidget):
    """Widget that combines webview with navigation bar and search functionality"""
    def __init__(self, url, download_manager, notification_manager, profile_name=None, parent=None):
        super().__init__(parent)

        self.tab_id = None  
        self.tab_title = ""  
        self.initial_name = "" 
        
        # Search engine configuration
        self.search_engines = {
            'google': {
                'url': 'https://www.google.com/search?q={}',
                'name': 'Google',
                'icon': 'google.png'
            },
            'bing': {
                'url': 'https://www.bing.com/search?q={}',
                'name': 'Bing',
                'icon': 'bing.png'
            },
            'duckduckgo': {
                'url': 'https://duckduckgo.com/?q={}',
                'name': 'DuckDuckGo',
                'icon': 'duck.png'
            }
        }
        self.current_search_engine = 'google' 
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create webview
        self.webview = QWebEngineView()
        
        # Create profile if profile_name provided
        if profile_name:
            self.profile = QWebEngineProfile(profile_name)
            storage_path = os.path.join(os.getcwd(), "alin_vault_sessions", profile_name)
            os.makedirs(storage_path, exist_ok=True)
            self.profile.setPersistentStoragePath(storage_path)
            self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        else:
            self.profile = QWebEngineProfile()
        
        # Create custom page
        self.page = CustomWebEnginePage(self.profile, download_manager, notification_manager, self.webview)
        self.webview.setPage(self.page)
        
        # Create navigation bar with search engine selector
        self.nav_bar = self.create_navigation_bar()
        
        layout.addWidget(self.nav_bar)
        layout.addWidget(self.webview, 1)
        
        self.setLayout(layout)
        
        # Set URL after page is set
        if url and url != "about:blank":
            self.navigate_to_url(url)
        
        # Connect load finished signal
        self.webview.loadFinished.connect(self.on_load_finished)
        self.webview.page().titleChanged.connect(self.on_page_title_changed)
    
    def on_page_title_changed(self, title):
        """Handle page title change and update tab button"""
        if title and title.strip():
            self.tab_title = title.strip()
            
            # Find the main window
            main_window = self.get_main_window()
            if main_window and hasattr(main_window, 'update_tab_title'):
                main_window.update_tab_title(self.tab_id, title)
    
    def get_main_window(self):
        """Get the main ALINDashboard window"""
        app = QApplication.instance()
        for widget in app.topLevelWidgets():
            if isinstance(widget, ALINDashboard):
                return widget
        return None
    
    def update_tab_title(self, title):
        """Update tab title (called from main window)"""
        self.tab_title = title
        # Find main window to update UI
        main_window = self.get_main_window()
        if main_window and hasattr(main_window, 'update_tab_ui_title'):
            main_window.update_tab_ui_title(self.tab_id, title)
    
    def create_navigation_bar(self):
        """Create navigation bar with back, forward, refresh, URL bar and search engine selector"""
        nav_bar = QFrame()
        nav_bar.setObjectName("navigationBar")
        nav_bar.setFixedHeight(50)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(10, 5, 10, 5)
        layout.setSpacing(8)
        
        # Back button
        self.back_btn = QPushButton("←")
        self.back_btn.setFixedSize(36, 36)
        self.back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_btn.clicked.connect(self.go_back)
        self.back_btn.setToolTip("Back")
        
        # Forward button
        self.forward_btn = QPushButton("→")
        self.forward_btn.setFixedSize(36, 36)
        self.forward_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.forward_btn.clicked.connect(self.go_forward)
        self.forward_btn.setToolTip("Forward")
        
        # Refresh button
        self.refresh_btn = QPushButton("↻")
        self.refresh_btn.setFixedSize(36, 36)
        self.refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.refresh_page)
        self.refresh_btn.setToolTip("Refresh")
        
        # Search engine selector
        self.search_engine_combo = QComboBox()
        self.search_engine_combo.setFixedWidth(120)
        self.search_engine_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Add search engines to combo box with icons
        assets_path = os.path.join(os.path.dirname(__file__), "assets")
        
        for engine_id, engine_info in self.search_engines.items():
            engine_name = engine_info['name']
            icon_file = engine_info.get('icon')
            
            if icon_file and os.path.exists(os.path.join(assets_path, icon_file)):
                # Load icon from file
                icon_path = os.path.join(assets_path, icon_file)
                icon = QIcon(icon_path)
                self.search_engine_combo.addItem(icon, engine_name, engine_id)
            else:
                # Use text emoji as fallback
                if engine_id == 'google':
                    self.search_engine_combo.addItem(f"🔍 {engine_name}", engine_id)
                elif engine_id == 'bing':
                    self.search_engine_combo.addItem(f"🅱️ {engine_name}", engine_id)
                elif engine_id == 'duckduckgo':
                    self.search_engine_combo.addItem(f"🦆 {engine_name}", engine_id)
                else:
                    self.search_engine_combo.addItem(f"🔍 {engine_name}", engine_id)
        
        self.search_engine_combo.setCurrentIndex(0)  # Default to Google
        self.search_engine_combo.currentIndexChanged.connect(self.on_search_engine_changed)
        
        # URL/Search bar
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Search Google or enter URL...")
        self.url_bar.returnPressed.connect(self.navigate_or_search)
        
        # Go button
        self.go_btn = QPushButton()
        self.go_btn.setFixedSize(50, 36)
        self.go_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.go_btn.clicked.connect(self.navigate_or_search)
        
        # Set icon for go button
        go_icon_path = os.path.join(os.path.dirname(__file__), "assets", "search.png")
        if os.path.exists(go_icon_path):
            go_icon = QIcon(go_icon_path)
            self.go_btn.setIcon(go_icon)
            self.go_btn.setIconSize(QSize(20, 20))
        else:
            self.go_btn.setText("Go")
        
        layout.addWidget(self.back_btn)
        layout.addWidget(self.forward_btn)
        layout.addWidget(self.refresh_btn)
        layout.addWidget(self.search_engine_combo)
        layout.addWidget(self.url_bar, 1)
        layout.addWidget(self.go_btn)
        
        nav_bar.setLayout(layout)
        
        # Connect webview signals
        if self.webview:
            self.webview.urlChanged.connect(self.update_url)
            self.webview.loadFinished.connect(self.update_navigation_buttons)
        
        return nav_bar
    
    def on_search_engine_changed(self, index):
        """Handle search engine change"""
        self.current_search_engine = self.search_engine_combo.currentData()
        engine_name = self.search_engines[self.current_search_engine]['name']
        self.url_bar.setPlaceholderText(f"Search {engine_name} or enter URL...")
    
    def is_valid_url(self, text):
        """Check if text is a valid URL"""
        # Basic URL validation
        if not text or len(text) < 4:
            return False
        
        # Check if it starts with common protocols
        if text.startswith(('http://', 'https://', 'ftp://', 'file://')):
            return True
        
        # Check if it has domain-like structure
        if '.' in text and not ' ' in text:
            # Simple domain validation
            parts = text.split('.')
            if len(parts) >= 2 and all(part.isalnum() or part == '-' for part in parts):
                # Check if it has valid TLD
                tld = parts[-1].lower()
                common_tlds = ['com', 'org', 'net', 'edu', 'gov', 'io', 'co', 'uk', 'de', 'jp', 
                              'fr', 'au', 'ru', 'cn', 'br', 'in', 'it', 'nl', 'es', 'ca', 'kr',
                              'eu', 'info', 'biz', 'tv', 'me', 'cc', 'xyz', 'online', 'site',
                              'tech', 'store', 'blog', 'app', 'dev', 'cloud', 'pro', 'my', 'sg']
                if tld in common_tlds or len(tld) == 2:  
                    return True
        
        # Check if it's an IP address
        ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if re.match(ip_pattern, text):
            parts = text.split('.')
            if all(0 <= int(part) <= 255 for part in parts):
                return True
        
        # Check for localhost
        if text == 'localhost':
            return True
        
        return False
    
    def navigate_or_search(self):
        """Navigate to URL or perform search based on input"""
        input_text = self.url_bar.text().strip()
        
        if not input_text:
            return
        
        # Check if it's a valid URL
        if self.is_valid_url(input_text):
            # Add https:// if no protocol specified
            if not input_text.startswith(('http://', 'https://', 'ftp://', 'file://')):
                input_text = 'https://' + input_text
            self.webview.setUrl(QUrl(input_text))
        else:
            # Perform search using selected search engine
            self.perform_search(input_text)
    
    def perform_search(self, query):
        """Perform search using current search engine"""
        search_url_template = self.search_engines[self.current_search_engine]['url']
        
        # URL encode the query
        from urllib.parse import quote
        encoded_query = quote(query)
        search_url = search_url_template.format(encoded_query)
        
        self.webview.setUrl(QUrl(search_url))
    
    def navigate_to_url(self, url):
        """Navigate to a URL (can be called programmatically)"""
        if isinstance(url, str):
            if self.is_valid_url(url):
                if not url.startswith(('http://', 'https://', 'ftp://', 'file://')):
                    url = 'https://' + url
                self.webview.setUrl(QUrl(url))
            else:
                self.perform_search(url)
        else:
            self.webview.setUrl(url)
    
    def go_back(self):
        if self.webview and self.webview.history().canGoBack():
            self.webview.back()
    
    def go_forward(self):
        if self.webview and self.webview.history().canGoForward():
            self.webview.forward()
    
    def refresh_page(self):
        if self.webview:
            self.webview.reload()
    
    def update_url(self, url):
        self.url_bar.setText(url.toString())
        self.update_navigation_buttons()
    
    def update_navigation_buttons(self):
        if self.webview:
            self.back_btn.setEnabled(self.webview.history().canGoBack())
            self.forward_btn.setEnabled(self.webview.history().canGoForward())
    
    def on_load_finished(self, ok):
        """Called when page finishes loading"""
        if ok:
            # Inject JavaScript for clipboard and other features
            js_code = """
            (function() {
                console.log('Page loaded successfully');
                
                // Enable clipboard access
                if (navigator.clipboard) {
                    console.log('Clipboard API available');
                }
                
                // Add click handler for all links to ensure they open in same tab
                document.addEventListener('click', function(e) {
                    const link = e.target.closest('a');
                    if (link && link.href) {
                        // Let the web engine handle it normally
                        return true;
                    }
                });
            })();
            """
            self.webview.page().runJavaScript(js_code)
    
    def set_dark_mode(self, dark):
        """Apply dark/light theme to navigation bar"""
        if dark:
            self.nav_bar.setStyleSheet("""
                QFrame#navigationBar {
                    background: #2a2a3a;
                    border-bottom: 1px solid #3a3a4a;
                }
                QPushButton {
                    background: #3a3a4a;
                    border: none;
                    border-radius: 8px;
                    color: white;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #4a4a5a;
                }
                QPushButton:disabled {
                    background: #2a2a3a;
                    color: #6a6a7a;
                }
                QComboBox {
                    background: #3a3a4a;
                    border: 1px solid #4a4a5a;
                    border-radius: 8px;
                    color: white;
                    padding: 5px 10px;
                    min-width: 120px;
                }
                QComboBox::drop-down {
                    border: none;
                    width: 20px;
                }
                QComboBox::down-arrow {
                    image: none;
                    border-left: 5px solid transparent;
                    border-right: 5px solid transparent;
                    border-top: 5px solid white;
                }
                QComboBox QAbstractItemView {
                    background: #3a3a4a;
                    color: white;
                    selection-background-color: #4a4a5a;
                }
                QLineEdit {
                    background: #3a3a4a;
                    border: 1px solid #4a4a5a;
                    border-radius: 8px;
                    color: white;
                    padding: 5px 10px;
                }
                QLineEdit::placeholder {
                    color: #8e8e93;
                }
            """)
        else:
            self.nav_bar.setStyleSheet("""
                QFrame#navigationBar {
                    background: white;
                    border-bottom: 1px solid rgba(60, 60, 67, 0.1);
                }
                QPushButton {
                    background: #f2f2f7;
                    border: none;
                    border-radius: 8px;
                    color: #007aff;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background: #e5e5ea;
                }
                QPushButton:disabled {
                    background: #f2f2f7;
                    color: #c7c7cc;
                }
                QComboBox {
                    background: #f2f2f7;
                    border: 1px solid #e5e5ea;
                    border-radius: 8px;
                    color: #007aff;
                    padding: 5px 10px;
                    min-width: 120px;
                }
                QComboBox::drop-down {
                    border: none;
                    width: 20px;
                }
                QComboBox::down-arrow {
                    image: none;
                    border-left: 5px solid transparent;
                    border-right: 5px solid transparent;
                    border-top: 5px solid #007aff;
                }
                QComboBox QAbstractItemView {
                    background: white;
                    color: #007aff;
                    selection-background-color: #e5e5ea;
                }
                QLineEdit {
                    background: #f2f2f7;
                    border: 1px solid #e5e5ea;
                    border-radius: 8px;
                    color: black;
                    padding: 5px 10px;
                }
                QLineEdit::placeholder {
                    color: #8e8e93;
                }
            """)

class ALINDashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        check_dependencies()
        
        self.setWindowTitle("ALIN Vault")
        self.setGeometry(200, 100, 1400, 850)
        self.dark_mode = False
        self.download_manager = EnhancedDownloadManager()
        self.notification_manager = NotificationManager()
        self.tabs = []
        self.tab_counter = 0
        self.current_tab_index = -1
        self.tabs_state_file = "tabs_state.json"
        self.Energy_saving = False
        self.bluetooth_enabled = False
        self.bluetooth_enabled = self.check_bluetooth_status()
        self.command_cache = CommandCache(ttl=5)
        self.clipboard = QApplication.clipboard()
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)

        self.music_player_active = False
        self.player_timer = QTimer()
        self.player_timer.timeout.connect(self.update_player_info)

        self.tabs = [] 
        self.tab_counter = 0
        self.current_tab_index = -1

        self.player_timer = None

        QTimer.singleShot(100, self.load_and_connect_tabs)
        
        self.sessions_root = os.path.join(os.getcwd(), "alin_vault_sessions")
        if not os.path.exists(self.sessions_root):
            os.makedirs(self.sessions_root)
        
        self.default_profile = self.create_or_load_profile("default_tabs")
        
        icon_path = os.path.join(os.path.dirname(__file__), "assets", "vault.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.last_modified = os.path.getmtime(__file__)
        
        self.dragging = False
        self.drag_position = QPoint()
        
        self.system_tray = SystemTrayManager(self)
        self.download_manager.set_system_tray(self.system_tray)
        
        self.setup_ui()
        self.update_bluetooth_button_state() 
        self.apply_light_mode()
        self.setup_refresh_timer()
        self.last_bluetooth_status = self.bluetooth_enabled
        
        QTimer.singleShot(100, lambda: self.stack.setCurrentWidget(self.deepseek))
    
    def open_url_in_new_tab(self, url):
        """Buka URL dalam tab baru"""
        if isinstance(url, QUrl):
            url = url.toString()
        
        # Extract domain untuk nama tab
        from urllib.parse import urlparse
        parsed = urlparse(url)
        domain = parsed.netloc.replace('www.', '')[:15]
        name = domain if domain else "New Tab"
        
        # Gunakan method add_new_tab yang sedia ada tapi override URL
        self.tab_counter += 1
        tab_id = self.tab_counter
        profile_name = f"tab_{tab_id}_{domain.replace('.', '_') if domain else 'new'}"
        
        webview_with_nav = WebViewWithNav(url, self.download_manager, 
                                        self.notification_manager, profile_name)
        webview_with_nav.tab_id = tab_id
        
        tab_button = CustomTabButton(name, tab_id)
        tab_button.clicked.connect(lambda checked, vid=tab_id: self.switch_to_tab(vid))
        tab_button.closed.connect(self.close_tab)
        
        # Insert before the add tab button
        insert_pos = len(self.tabs)
        self.nav_layout.insertWidget(insert_pos + 13, tab_button)
        self.stack.addWidget(webview_with_nav)
        
        tab_info = TabInfo(name, url, webview_with_nav, tab_button)
        tab_info.profile_name = profile_name
        self.tabs.append(tab_info)
        
        # Connect title change
        webview_with_nav.webview.page().titleChanged.connect(
            lambda title, tid=tab_id: self.update_tab_title(tid, title)
        )
        
        self.switch_to_tab(tab_id)
        self.save_tab_state()
    
    def update_tab_title(self, tab_id, title):
        """Update tab title from webview"""
        for tab in self.tabs:
            if hasattr(tab.button, 'tab_id') and tab.button.tab_id == tab_id:
                tab.button.update_title(title)
                
                # Also update the stored name
                tab.name = title
                
                # Save state after title change 
                if not hasattr(self, '_title_save_timer'):
                    self._title_save_timer = QTimer()
                    self._title_save_timer.setSingleShot(True)
                    self._title_save_timer.timeout.connect(self.save_tab_state)
                
                self._title_save_timer.start(1000)
                break
    
    def update_tab_ui_title(self, tab_id, title):
        """Update tab UI title"""
        self.update_tab_title(tab_id, title)
    
    def setup_clipboard_paste_listener(self):
        """Listen for clipboard changes to detect pasted URLs"""
        self.clipboard = QApplication.clipboard()
        self.clipboard.dataChanged.connect(self.on_clipboard_changed)
        self.last_pasted_url = ""
        
    def on_clipboard_changed(self):
        """Handle clipboard changes - if it's a URL, open in new temp tab"""
        # Small delay to ensure we have the content
        QTimer.singleShot(100, self._check_clipboard_for_url)

    def _check_clipboard_for_url(self):
        try:
            text = self.clipboard.text().strip()
            
            # Avoid duplicate processing
            if text == self.last_pasted_url:
                return
                
            # Check if it looks like a URL
            if self.is_valid_url(text):
                self.last_pasted_url = text
                self.open_url_in_temp_tab(text)
        except Exception as e:
            print(f"Error checking clipboard: {e}")

    def is_valid_url(self, text):
        """Check if text looks like a valid URL"""
        # Basic URL patterns
        if not text or len(text) < 4:
            return False
            
        # Check for common URL patterns
        patterns = [
            r'^https?://',  
            r'^www\.',     
            r'\.[a-z]{2,}$' 
        ]
        
        import re
        for pattern in patterns:
            if re.search(pattern, text.lower()):
                return True
        
        # Also check if it has a domain-like structure (something.something)
        if '.' in text and not ' ' in text and '/' in text:
            parts = text.split('/')
            if len(parts) > 0 and '.' in parts[0]:
                return True
        
        return False

    def open_url_in_temp_tab(self, url):
        """Open URL in a new temporary tab (not saved)"""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        # Create a temporary tab name from domain
        from urllib.parse import urlparse
        parsed = urlparse(url)
        domain = parsed.netloc.replace('www.', '')[:15]
        tab_name = domain if domain else "Temp"
        
        self.tab_counter += 1
        tab_id = self.tab_counter
        
        # Use a temporary profile that won't be saved
        profile_name = f"temp_tab_{tab_id}"
        
        # Create webview with navigation
        webview_with_nav = WebViewWithNav(url, self.download_manager, self.notification_manager, profile_name)
        
        # Create tab button
        tab_button = CustomTabButton(f"🌐 {tab_name}", tab_id)
        tab_button.clicked.connect(lambda checked, vid=tab_id: self.switch_to_tab(vid))
        tab_button.closed.connect(self.close_temp_tab) 
        
        # Add to UI
        insert_pos = len(self.tabs)
        self.nav_layout.insertWidget(insert_pos + 13, tab_button)
        self.stack.addWidget(webview_with_nav)
        
        # Store tab info (marked as temporary)
        tab_info = TabInfo(tab_name, url, webview_with_nav, tab_button)
        tab_info.profile_name = profile_name
        tab_info.is_temp = True  
        self.tabs.append(tab_info)
        
        # Switch to new tab
        self.switch_to_tab(tab_id)
        
        # Optional: Show notification
        if self.system_tray:
            self.system_tray.show_notification(
                "New Tab Opened",
                f"Opened {domain} in temporary tab"
            )

    def close_temp_tab(self, button):
        """Special close for temp tabs - delete session data"""
        for i, tab in enumerate(self.tabs):
            if tab.button == button:
                # If it's a temp tab, delete its session data
                if hasattr(tab, 'is_temp') and tab.is_temp:
                    if hasattr(tab, 'profile_name') and tab.profile_name:
                        import shutil
                        session_path = os.path.join(self.sessions_root, tab.profile_name)
                        if os.path.exists(session_path):
                            shutil.rmtree(session_path)
                
                # Remove button
                button.setParent(None)
                button.deleteLater()
                
                # Remove webview
                self.stack.removeWidget(tab.webview)
                tab.webview.setParent(None)
                tab.webview.deleteLater()
                
                # Remove from tabs list
                self.tabs.pop(i)
                
                # Update current tab index
                if i <= self.current_tab_index:
                    self.current_tab_index = max(0, self.current_tab_index - 1)
                    
                # Switch to another tab
                if self.tabs:
                    self.switch_to_tab(self.tabs[self.current_tab_index].button.tab_id)
                break
    
    def load_and_connect_tabs(self):
        """Load tabs from state and connect signals"""
        self.load_tab_state()
        
        # Connect URL change signals for all tabs
        for tab in self.tabs:
            if hasattr(tab.webview, 'webview'):
                tab.webview.webview.urlChanged.connect(
                    lambda url, t=tab: self.on_tab_url_changed(t, url)
                )
    
    def setup_tab_url_tracking(self):
        """Track URL changes in tabs and save state"""
        for tab in self.tabs:
            if hasattr(tab.webview, 'webview'):
                # Connect to the webview's urlChanged signal
                tab.webview.webview.urlChanged.connect(
                    lambda url, t=tab: self.on_tab_url_changed(t, url)
            )

    def on_tab_url_changed(self, tab, url):
        """Called when a tab's URL changes"""
        # Update tab info with new URL
        tab.url = url.toString()
        
        # Debounce saving to avoid too many writes
        if not hasattr(self, '_tab_save_timer'):
            self._tab_save_timer = QTimer()
            self._tab_save_timer.setSingleShot(True)
            self._tab_save_timer.timeout.connect(self.save_tab_state)
        
        self._tab_save_timer.start(1000)
    
    def create_webview_with_notifications(self, url):
        webview = QWebEngineView()
        profile = self.create_or_load_profile("some_profile")
        page = CustomWebEnginePage(
            profile, 
            self.download_manager, 
            self.notification_manager, 
            webview
        )
        webview.setPage(page)
        webview.setUrl(QUrl(url))
        return webview

    def check_bluetooth_status(self):
        """Check actual Bluetooth status from system"""
        try:
            if sys.platform == "linux":
                result = subprocess.run(
                    ['systemctl', 'is-active', 'bluetooth'],
                    capture_output=True,
                    text=True
                )
                return result.returncode == 0
                
            elif sys.platform == "win32":
                try:
                    import winreg
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, 
                        r"SYSTEM\CurrentControlSet\Services\BTHPORT\Parameters")
                    value, _ = winreg.QueryValueEx(key, "State")
                    winreg.CloseKey(key)
                    return value == 1
                except:
                    result = subprocess.run(
                        ['powershell', '-Command', 
                        '(Get-Service -Name "BluetoothUserService").Status -eq "Running"'],
                        capture_output=True,
                        text=True
                    )
                    return "True" in result.stdout
                    
            elif sys.platform == "darwin":
                result = subprocess.run(
                    ['blueutil', '--power'],
                    capture_output=True,
                    text=True
                )
                return "1" in result.stdout
                
        except Exception as e:
            print(f"Error checking Bluetooth status: {e}")
            return False
    
    def update_bluetooth_button_state(self):
        if self.bluetooth_enabled:
            self.btn_bluetooth.setText(" ON")
            self.btn_bluetooth.setToolTip("Bluetooth: ON (system)\nClick to disable")
        else:
            self.btn_bluetooth.setText(" OFF")
            self.btn_bluetooth.setToolTip("Bluetooth: OFF (system)\nClick to enable")
        
    def update_player_info(self):
        if not self.current_player:
            self.detect_player()
            return
        
        try:
            result = subprocess.run(
                ['playerctl', '--player', self.current_player, 'metadata', 
                 '--format', '{{title}}|{{artist}}|{{album}}|{{position}}|{{mpris:length}}|{{status}}'],
                capture_output=True, text=True, timeout=1
            )
            
            if result.returncode == 0 and result.stdout.strip():
                parts = result.stdout.strip().split('|')
                if len(parts) >= 6:
                    self.title = parts[0] or "Unknown Title"
                    self.artist = parts[1] or "Unknown Artist"
                    self.album = parts[2] or ""
                    
                    try:
                        self.position = float(parts[3]) if parts[3] else 0
                    except:
                        self.position = 0
                    
                    try:
                        self.length = float(parts[4]) / 1000000 if parts[4] else 0
                    except:
                        self.length = 0
                    
                    self.playing = (parts[5] == "Playing")
                    
                    self.update_ui()
                    
        except subprocess.TimeoutExpired:
            print("Playerctl timeout")
        except Exception as e:
            print(f"Error updating player info: {e}")
            self.detect_player()
    
    def update_ui(self):
        self.now_playing_label.setText(self.title)
        
        artist_text = self.artist
        if self.album:
            artist_text += f" • {self.album}"
        self.artist_label.setText(artist_text)
        self.current_time.setText(self.format_time(self.position))
        self.total_time.setText(self.format_time(self.length))
        if self.length > 0:
            progress_width = int((self.position / self.length) * self.progress_bar.width())
            self.progress_fill.setFixedWidth(progress_width)
            
            knob_x = max(0, min(progress_width - self.progress_knob.width() // 2, 
                               self.progress_bar.width() - self.progress_knob.width()))
            self.progress_knob.move(int(knob_x), (self.progress_bar.height() - self.progress_knob.height()) // 2)
        pause_path = os.path.join(os.path.dirname(__file__), "assets", "pause.png")
        play_path = os.path.join(os.path.dirname(__file__), "assets", "play.png")
        
        if self.playing:
            if os.path.exists(pause_path):
                self.play_btn.setIcon(QIcon(pause_path))
            else:
                self.play_btn.setText("⏸")
            self.player_status.setText("● Live")
        else:
            if os.path.exists(play_path):
                self.play_btn.setIcon(QIcon(play_path))
            else:
                self.play_btn.setText("▶")
            self.player_status.setText("○ Paused")
        player_display = self.current_player
        if player_display:
            if "youtube" in player_display.lower():
                player_display = "YouTube Music"
            elif "spotify" in player_display.lower():
                player_display = "Spotify"
            elif "firefox" in player_display.lower():
                player_display = "Firefox"
            elif "chrome" in player_display.lower():
                player_display = "Chrome"
            elif "vlc" in player_display.lower():
                player_display = "VLC"
            
            self.player_label.setText(player_display)
    
    def on_music_widget_shown(self):
        self.music_player_active = True
        if not self.player_timer.isActive():
            self.player_timer.start(2000)
    
    def on_music_widget_hidden(self):
        self.music_player_active = False
        self.player_timer.stop()
        
    def run_sudo_command(self, command):
        try:
            if sys.platform == "linux":
                password, ok = QInputDialog.getText(
                    self,                          
                    "Sudo Password Required",       
                    "Enter your sudo password:",    
                    QLineEdit.EchoMode.Password,    
                    ""                              
                )
                
                if not ok or not password:
                    self.status_text.setText("Operation cancelled - password required")
                    return False
                
                commands = command.split(' && ')
                sudo_commands = []
                for cmd in commands:
                    clean_cmd = cmd.replace('sudo ', '')
                    escaped_password = password.replace("'", "'\\''")
                    sudo_commands.append(f"echo '{escaped_password}' | sudo -S {clean_cmd}")
                
                full_command = " && ".join(sudo_commands)
                
                terminal_cmd = [
                    'gnome-terminal', '--', 'bash', '-c',
                    f'echo "Running Energy saver command..." && {full_command} && '
                    f'echo "Done! You can close this window." && '
                    f'echo "Press Enter to exit..." && read'
                ]
                
                if not shutil.which('gnome-terminal'):
                    terminal_cmd = [
                        'xterm', '-e',
                        f'bash -c "echo Running Energy saver command... && {full_command} && '
                        f'echo Done! && echo Press Enter to exit... && read"'
                    ]
                
                password = None
                
                subprocess.Popen(terminal_cmd)
                return True
                
        except Exception:
            print(f"Error running sudo command")
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to run command"
            )
            return False
                
    def check_tlp_status(self):
        def _check_tlp():
            try:
                result = subprocess.run(
                    ['systemctl', 'is-active', 'tlp'],
                    capture_output=True,
                    text=True
                )
                is_active = result.returncode == 0
                
                result_enabled = subprocess.run(
                    ['systemctl', 'is-enabled', 'tlp'],
                    capture_output=True,
                    text=True
                )
                is_enabled = result_enabled.returncode == 0
                
                return is_active and is_enabled
            except Exception:
                return False
        
        return self.command_cache.get("tlp_status", _check_tlp)
            
        
    def toggle_Energy_saving(self):
        try:
            if sys.platform != "linux":
                QMessageBox.information(
                    self,
                    "Not Supported",
                    "Energy saving mode is only supported on Linux systems with TLP installed."
                )
                return
            
            check_tlp = subprocess.run(['which', 'tlp'], capture_output=True)
            if check_tlp.returncode != 0:
                QMessageBox.warning(
                    self,
                    "TLP Not Found",
                    "TLP is not installed. Please install TLP first:\n\nsudo apt install tlp tlp-rdw"
                )
                return
            
            tlp_running = self.check_tlp_status()
            
            if not self.Energy_saving:
                reply = QMessageBox.question(
                    self,
                    "Enable Energy Saver",
                    "This will enable TLP power saving features.\n\n"
                    "You will be prompted for your sudo password.\n\n"
                    "Do you want to continue?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    command = (
                        "sudo systemctl enable tlp.service && "
                        "sudo systemctl start tlp && "
                        "sudo systemctl enable tlp-pd.service && "
                        "sudo systemctl start tlp-pd.service"
                    )
                    
                    if self.run_sudo_command(command):
                        self.Energy_saving = True
                        self.btn_Energy_saving.setText("🔋 ON")
                        self.status_text.setText("Energy saving mode enabled")
                        
                        if self.system_tray:
                            self.system_tray.show_notification(
                                "Energy Saving",
                                "Energy saving mode has been enabled"
                            )
            else:
                reply = QMessageBox.question(
                    self,
                    "Disable Energy Saver",
                    "This will disable TLP power saving features.\n\n"
                    "You will be prompted for your sudo password.\n\n"
                    "Do you want to continue?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    command = (
                        "sudo systemctl stop tlp && "
                        "sudo systemctl disable tlp.service && "
                        "sudo systemctl stop tlp-pd.service && "
                        "sudo systemctl disable tlp-pd.service"
                    )
                    
                    if self.run_sudo_command(command):
                        self.Energy_saving = False
                        self.btn_Energy_saving.setText("🔋 OFF")
                        self.status_text.setText("Coded By Aydiel@FalconEye")
                        
                        if self.system_tray:
                            self.system_tray.show_notification(
                                "Energy Saving",
                                "Energy saving mode has been disabled"
                            )
            
            self.update_Energy_status_tooltip()
            
        except Exception:
            print("Error toggling Energy saving")
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to toggle Energy saving mode"
            )
        
    def update_Energy_status_tooltip(self):
        if self.Energy_saving:
            tooltip = "Energy Saver: ON\nClick to disable power saving"
        else:
            tooltip = "Energy Saver: OFF\nClick to enable power saving"
        
        if sys.platform == "linux":
            tlp_running = self.check_tlp_status()
            if tlp_running:
                tooltip += "\nTLP is running"
            else:
                tooltip += "\nTLP is not running"
        
        self.btn_Energy_saving.setToolTip(tooltip)

    def toggle_bluetooth(self):
        try:
            if sys.platform != "linux":
                QMessageBox.information(
                    self,
                    "Not Supported",
                    "Bluetooth control is only supported on Linux systems."
                )
                return
            
            # Set flag bahwa ini adalah aksi manual user
            self._manual_bluetooth_toggle = True
            
            current_status = self.check_bluetooth_status()
            
            if not current_status: 
                reply = QMessageBox.question(
                    self,
                    "Enable Bluetooth",
                    "This will start the Bluetooth service.\n\n"
                    "You will be prompted for your sudo password.\n\n"
                    "Do you want to continue?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    command = "sudo systemctl start bluetooth"
                    
                    if self.run_sudo_command(command):
                        QTimer.singleShot(2000, self.verify_bluetooth_status)
                        
            else: 
                reply = QMessageBox.question(
                    self,
                    "Disable Bluetooth",
                    "This will stop the Bluetooth service.\n\n"
                    "You will be prompted for your sudo password.\n\n"
                    "Do you want to continue?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    command = "sudo systemctl stop bluetooth"
                    
                    if self.run_sudo_command(command):
                        QTimer.singleShot(2000, self.verify_bluetooth_status)
            
        except Exception as e:
            print(f"Error toggling Bluetooth: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to toggle Bluetooth: {str(e)}"
            )
            self._manual_bluetooth_toggle = False

    def verify_bluetooth_status(self):
        """Verify Bluetooth status after command execution"""
        new_status = self.check_bluetooth_status()
        
        if new_status != self.bluetooth_enabled:
            self.bluetooth_enabled = new_status
            self.update_bluetooth_button_state()
            
            if hasattr(self, '_manual_bluetooth_toggle') and self._manual_bluetooth_toggle:
                if self.system_tray:
                    status = "enabled" if self.bluetooth_enabled else "disabled"
                    self.system_tray.show_notification(
                        "Bluetooth",
                        f"Coded By Aydiel@FalconEye"
                    )
                self.status_text.setText(f"Bluetooth {status}")
                self._manual_bluetooth_toggle = False
        
        self.update_bluetooth_tooltip()
        
    def update_bluetooth_tooltip(self):
        if self.bluetooth_enabled:
            tooltip = "Bluetooth: ON\nClick to disable"
        else:
            tooltip = "Bluetooth: OFF\nClick to enable"
        self.btn_bluetooth.setToolTip(tooltip)

    def save_tab_state(self):
        """Save current tabs to JSON file including titles"""
        try:
            tabs_data = []
            for tab in self.tabs:
                try:
                    # Get current URL and title
                    if hasattr(tab.webview, 'webview'):
                        current_url = tab.webview.webview.url().toString()
                        current_title = tab.webview.webview.page().title()
                    else:
                        current_url = tab.url
                        current_title = tab.name
                    
                    tabs_data.append({
                        'name': current_title if current_title else tab.name,
                        'url': current_url,
                        'profile_name': tab.profile_name
                    })
                except Exception as e:
                    print(f"Error saving tab {tab.name}: {e}")
                    continue
            
            # Create backup of existing file
            if os.path.exists(self.tabs_state_file):
                backup_file = self.tabs_state_file + ".backup"
                try:
                    shutil.copy2(self.tabs_state_file, backup_file)
                except:
                    pass
            
            # Save new state
            with open(self.tabs_state_file, 'w') as f:
                json.dump(tabs_data, f, indent=2)
            
            print(f"✓ Saved {len(tabs_data)} tabs to {self.tabs_state_file}")
            
        except Exception as e:
            print(f"✗ Error saving tab state: {e}")
            # Try to restore from backup if save failed
            try:
                backup_file = self.tabs_state_file + ".backup"
                if os.path.exists(backup_file):
                    shutil.copy2(backup_file, self.tabs_state_file)
                    print("Restored from backup")
            except:
                pass

    def load_tab_state(self):
        """Load and restore tabs from JSON file with titles"""
        try:
            if os.path.exists(self.tabs_state_file):
                with open(self.tabs_state_file, 'r') as f:
                    tabs_data = json.load(f)
                
                # Clear existing tabs except the first one
                while len(self.tabs) > 1:
                    tab = self.tabs[-1]
                    self.close_tab(tab.button)
                
                # Load saved tabs
                for tab_data in tabs_data:
                    if len(self.tabs) == 1 and self.tabs[0].name == tab_data['name'] and self.tabs[0].url == tab_data['url']:
                        continue
                    
                    self.add_tab_from_state(
                        tab_data['name'], 
                        tab_data['url'], 
                        tab_data.get('profile_name')
                    )
                
                print(f"Loaded {len(tabs_data)} tabs from {self.tabs_state_file}")
        except Exception as e:
            print(f"Error loading tab state: {e}")

    def add_tab_from_state(self, name, url, profile_name=None):
        """Add a tab from saved state with initial title"""
        try:
            self.tab_counter += 1
            tab_id = self.tab_counter
            
            # Create or load profile
            if profile_name:
                profile = self.create_or_load_profile(profile_name)
            else:
                parsed_url = urlparse(url)
                domain = parsed_url.netloc.replace('.', '_')
                profile_name = f"tab_{tab_id}_{domain}"
                profile = self.create_or_load_profile(profile_name)
            
            # Create webview with navigation
            webview_with_nav = WebViewWithNav(url, self.download_manager, self.notification_manager, profile_name)
            webview = webview_with_nav.webview
            
            # Set tab_id for title updates
            webview_with_nav.tab_id = tab_id
            
            # Create tab button with initial name
            # Extract domain for initial name
            parsed_url = urlparse(url)
            domain = parsed_url.netloc.replace('www.', '')
            if not domain:
                domain = name
            display_name = domain[:15] if len(domain) > 15 else domain
            
            tab_button = CustomTabButton(display_name, tab_id)
            tab_button.clicked.connect(lambda checked, vid=tab_id: self.switch_to_tab(vid))
            tab_button.closed.connect(self.close_tab)
            
            insert_pos = len(self.tabs)
            self.nav_layout.insertWidget(insert_pos + 13, tab_button)
            
            # Add to stack
            self.stack.addWidget(webview_with_nav)
            
            # Store tab info
            tab_info = TabInfo(name, url, webview_with_nav, tab_button)
            tab_info.profile_name = profile_name
            self.tabs.append(tab_info)
            
            # Connect title change signal from webview page
            webview.page().titleChanged.connect(
                lambda title, tid=tab_id: self.update_tab_title(tid, title)
            )
            
            # Also connect to webview_with_nav if needed
            webview_with_nav.tab_id = tab_id
            
            # Switch to new tab
            self.switch_to_tab(tab_id)
            
        except Exception as e:
            print(f"Error adding tab from state: {e}")

    def create_or_load_profile(self, profile_name):
        try:
            profile = QWebEngineProfile(profile_name)
            storage_path = os.path.join(self.sessions_root, profile_name)
            
            os.makedirs(storage_path, exist_ok=True)
            
            profile.setPersistentStoragePath(storage_path)
            profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
            
            settings = profile.settings()
            settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
            settings.setAttribute(QWebEngineSettings.WebAttribute.AllowRunningInsecureContent, True)
            
            return profile
        except Exception:
            return QWebEngineProfile()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = True
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.dragging and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = False
            event.accept()

    def setup_refresh_timer(self):
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.check_file_changes)
        self.refresh_timer.start(30000)

    def check_file_changes(self):
        try:
            current_modified = os.path.getmtime(__file__)
            if current_modified > self.last_modified:
                self.last_modified = current_modified
                self.refresh_application()
        except OSError:
            pass

    def refresh_application(self):
        self.save_tab_state()
        self.status_text.setText("Refreshing application...")
        QApplication.processEvents()
        python = sys.executable
        os.execl(python, python, *sys.argv)

    def create_logo(self):
        icon_path = os.path.join(os.path.dirname(__file__), "assets", "vault.png")
        if os.path.exists(icon_path):
            return QPixmap(icon_path).scaled(48, 48, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        
        size = 48
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        gradient = QLinearGradient(0, 0, size, size)
        if self.dark_mode:
            gradient.setColorAt(0, QColor(168, 192, 255))
            gradient.setColorAt(1, QColor(63, 43, 150))
        else:
            gradient.setColorAt(0, QColor(43, 88, 118))
            gradient.setColorAt(1, QColor(78, 67, 118))
        painter.setBrush(gradient)
        painter.setPen(QPen(QColor(255, 255, 255, 80), 2))
        painter.drawEllipse(4, 4, size-8, size-8)
        painter.setPen(QColor(255, 255, 255))
        font = QFont("Arial", 20)
        painter.setFont(font)
        painter.drawText(pixmap.rect().adjusted(0, -2, 0, 0), Qt.AlignmentFlag.AlignCenter, "AL")
        painter.end()
        return pixmap

    def show_login_helper(self, service_name, login_url, webview):
        dialog = LoginHelperDialog(service_name, login_url, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.stack.setCurrentWidget(webview)
            webview.reload()
            QMessageBox.information(
                self,
                "Reloading",
                f"Reloading {service_name}. If you're still not logged in, please try again."
            )
        else:
            self.stack.setCurrentWidget(webview)

    def add_new_tab(self):
        dialog = AddTabDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            url, name = dialog.get_values()
            if url and name:
                if not url.startswith(('http://', 'https://')):
                    url = 'https://' + url
                
                parsed = urlparse(url)
                if not parsed.netloc:
                    QMessageBox.warning(self, "Invalid URL", "Please enter a valid URL")
                    return
                
                self.tab_counter += 1
                tab_id = self.tab_counter
                
                parsed_url = urlparse(url)
                domain = parsed_url.netloc.replace('.', '_')
                profile_name = f"tab_{tab_id}_{domain}"
                
                # Create webview with navigation
                webview_with_nav = WebViewWithNav(url, self.download_manager, self.notification_manager, profile_name)
                
                # Set tab_id for title updates
                webview_with_nav.tab_id = tab_id
                webview_with_nav.initial_name = name
                
                # Create tab button with initial name
                tab_button = CustomTabButton(name, tab_id)
                tab_button.clicked.connect(lambda checked, vid=tab_id: self.switch_to_tab(vid))
                tab_button.closed.connect(self.close_tab)
                
                insert_pos = len(self.tabs)
                self.nav_layout.insertWidget(insert_pos + 13, tab_button)
                
                self.stack.addWidget(webview_with_nav)
                
                tab_info = TabInfo(name, url, webview_with_nav, tab_button)
                tab_info.profile_name = profile_name
                self.tabs.append(tab_info)
                
                # Connect title change signal
                webview_with_nav.webview.page().titleChanged.connect(
                    lambda title, tid=tab_id: self.update_tab_title(tid, title)
                )
                
                self.switch_to_tab(tab_id)
                
                # Save state immediately after adding new tab
                self.save_tab_state()
    
    def update_notification_badge(self, count):
        if count > 0:
            self.btn_notifications.setText(f"🔔 ({count})")
            
            if not hasattr(self, 'notification_badge_added'):
                badge_style = """
                    QPushButton {
                        border: 2px solid #ff3b30;
                    }
                """
                if self.dark_mode:
                    badge_style += """
                        QPushButton {
                            background: #ff3b30;
                            color: white;
                        }
                    """
                else:
                    badge_style += """
                        QPushButton {
                            background: #ff3b30;
                            color: white;
                        }
                    """
                self.btn_notifications.setStyleSheet(self.btn_notifications.styleSheet() + badge_style)
                self.notification_badge_added = True
        else:
            self.btn_notifications.setText("🔔 Notifications")
            if hasattr(self, 'notification_badge_added'):
                self.btn_notifications.setStyleSheet(self.btn_notifications.styleSheet().replace(
                    "border: 2px solid #ff3b30;", ""
                ).replace("background: #ff3b30;", "").replace("color: white;", ""))
                delattr(self, 'notification_badge_added')
                
    def switch_to_tab(self, tab_id):
        for i, tab in enumerate(self.tabs):
            if hasattr(tab.button, 'tab_id') and tab.button.tab_id == tab_id:
                # Update URL of previous tab before switching
                if self.current_tab_index >= 0 and self.current_tab_index < len(self.tabs):
                    current_tab = self.tabs[self.current_tab_index]
                    if hasattr(current_tab.webview, 'webview'):
                        current_tab.url = current_tab.webview.webview.url().toString()
                
                self.stack.setCurrentWidget(tab.webview)
                self.current_tab_index = i
                self.update_tab_styles()
                
                # Save state after switching (debounced)
                if not hasattr(self, '_tab_switch_timer'):
                    self._tab_switch_timer = QTimer()
                    self._tab_switch_timer.setSingleShot(True)
                    self._tab_switch_timer.timeout.connect(self.save_tab_state)
                
                self._tab_switch_timer.start(500)
                break
                
    def close_tab(self, button):
        """Close a tab and save state"""
        if len(self.tabs) <= 1:
            QMessageBox.information(self, "Cannot Close", "You must keep at least one tab open.")
            return
            
        for i, tab in enumerate(self.tabs):
            if tab.button == button:
                reply = QMessageBox.question(
                    self, 
                    'Delete Session Data',
                    f'Do you want to delete saved login data for "{tab.name}"?\n'
                    'Click No to keep cookies for next time.',
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    if hasattr(tab, 'profile_name') and tab.profile_name:
                        import shutil
                        session_path = os.path.join(self.sessions_root, tab.profile_name)
                        if os.path.exists(session_path):
                            shutil.rmtree(session_path)
                
                # Remove button
                button.setParent(None)
                button.deleteLater()
                
                # Remove webview
                self.stack.removeWidget(tab.webview)
                tab.webview.setParent(None)
                tab.webview.deleteLater()
                
                # Remove from tabs list
                self.tabs.pop(i)
                
                # Update current tab index
                if i <= self.current_tab_index:
                    self.current_tab_index = max(0, self.current_tab_index - 1)
                    
                # Switch to another tab
                if self.tabs:
                    self.switch_to_tab(self.tabs[self.current_tab_index].button.tab_id)
                
                # Save state after closing tab
                self.save_tab_state()
                break
                
    def update_tab_styles(self):
        for i, tab in enumerate(self.tabs):
            if i == self.current_tab_index:
                if self.dark_mode:
                    tab.button.setStyleSheet("""
                        QPushButton { 
                            background: #0f3460; 
                            color: white; 
                            padding: 6px 10px; 
                            border: 2px solid #4a9eff; 
                            border-radius: 8px; 
                        }
                    """)
                else:
                    tab.button.setStyleSheet("""
                        QPushButton { 
                            background: #e0e0e0; 
                            color: black; 
                            padding: 6px 10px; 
                            border: 2px solid #2196F3; 
                            border-radius: 8px; 
                        }
                    """)
            else:
                if self.dark_mode:
                    tab.button.setStyleSheet("""
                        QPushButton { 
                            background: #16213e; 
                            color: white; 
                            padding: 6px 10px; 
                            border: 1px solid #333; 
                            border-radius: 8px; 
                        }
                        QPushButton:hover { background: #1a4b8c; }
                    """)
                else:
                    tab.button.setStyleSheet("""
                        QPushButton { 
                            background: white; 
                            color: black; 
                            padding: 6px 10px; 
                            border: 1px solid #ddd; 
                            border-radius: 8px; 
                        }
                        QPushButton:hover { background: #e0e0e0; }
                    """)

    def reload_whatsapp_if_needed(self):
        self.stack.setCurrentWidget(self.whatsapp)
        current_url = self.whatsapp.webview.url().toString()
        if "web.whatsapp.com" not in current_url:
            self.whatsapp.webview.setUrl(QUrl("about:blank"))
            QTimer.singleShot(500, lambda: self.whatsapp.webview.setUrl(QUrl("https://web.whatsapp.com/")))

    def clear_cache(self):
        reply = QMessageBox.question(
            self,
            "Clear Cache",
            "This will clear all browser cache, cookies, and session data for all tabs.\n\n"
            "You will be logged out from all websites.\n\n"
            "Do you want to continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                import shutil
                
                for tab in self.tabs:
                    if hasattr(tab, 'profile_name') and tab.profile_name:
                        session_path = os.path.join(self.sessions_root, tab.profile_name)
                        if os.path.exists(session_path):
                            shutil.rmtree(session_path)
                
                if hasattr(self, 'default_profile') and self.default_profile:
                    default_path = os.path.join(self.sessions_root, "default_tabs")
                    if os.path.exists(default_path):
                        shutil.rmtree(default_path)
                
                QMessageBox.information(
                    self,
                    "Cache Cleared",
                    "All browser cache, cookies, and session data have been cleared.\n\n"
                    "The application will now refresh to apply changes."
                )
                
                self.status_text.setText("Cache cleared - Refreshing...")
                QApplication.processEvents()
                
                QTimer.singleShot(1000, self.refresh_application)
                
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"Failed to clear cache: {str(e)}"
                )

    def setup_ui(self):
        self.central_widget = QWidget()
        self.central_widget.setObjectName("centralWidget")
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        self.nav_bar = QFrame()
        self.nav_bar.setObjectName("navBar")
        self.nav_layout = QHBoxLayout()
        self.nav_layout.setContentsMargins(10, 5, 10, 5)
        self.nav_layout.setSpacing(5)

        logo_container = QWidget()
        logo_layout = QHBoxLayout()
        logo_layout.setContentsMargins(0, 0, 0, 0)
        self.logo_label = QLabel()
        self.logo_label.setPixmap(self.create_logo())
        self.title_label = QLabel("Alin Vault")
        logo_layout.addWidget(self.logo_label)
        logo_layout.addWidget(self.title_label)
        logo_container.setLayout(logo_layout)
        self.nav_layout.addWidget(logo_container)

        self.nav_layout.addStretch()

        self.btn_deepseek = QPushButton("DeepSeek")
        self.btn_whatsapp = QPushButton("WhatsApp")
        self.btn_chatgpt = QPushButton("ChatGPT")
        self.btn_youtube = QPushButton("YouTube")
        self.btn_music = QPushButton("Music")
        self.btn_notes = QPushButton("Notes")
        self.btn_clipboard = QPushButton("Clipboard")
        self.btn_downloads = QPushButton("⬇ Downloads")
        self.btn_notifications = QPushButton("🔔 Notifications")
        self.btn_add_tab = QPushButton("+")
        self.btn_add_tab.setFixedWidth(40)
        self.btn_add_tab.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_add_tab.clicked.connect(self.add_new_tab)
        
        self.btn_clear_cache = QPushButton("🧹 Clear Cache")
        self.btn_clear_cache.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_clear_cache.clicked.connect(self.clear_cache)
        self.btn_clear_cache.setToolTip("Clear all browser cache, cookies, and session data")
        
        self.btn_Energy_saving = QPushButton("🔋 OFF")
        self.btn_Energy_saving.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_Energy_saving.clicked.connect(self.toggle_Energy_saving)
        self.btn_Energy_saving.setToolTip("Click to toggle Energy saving mode")
        
        self.btn_bluetooth = QPushButton(" OFF")
        self.btn_bluetooth.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_bluetooth.clicked.connect(self.toggle_bluetooth)
        self.btn_bluetooth.setToolTip("Click to toggle Bluetooth")

        bluetooth_icon_path = os.path.join(os.path.dirname(__file__), "assets", "bluetooth.png")
        if os.path.exists(bluetooth_icon_path):
            bluetooth_icon = QIcon(bluetooth_icon_path)
            self.btn_bluetooth.setIcon(bluetooth_icon)
            self.btn_bluetooth.setIconSize(QSize(20, 20))
        
        for btn in [self.btn_deepseek, self.btn_whatsapp, self.btn_chatgpt, self.btn_youtube, self.btn_music, self.btn_notes, self.btn_clipboard, 
                self.btn_downloads, self.btn_notifications, self.btn_add_tab, self.btn_clear_cache, self.btn_Energy_saving, self.btn_bluetooth]:
            btn.setCursor(Qt.CursorShape.PointingHandCursor)

        # Add buttons to layout in specific order
        self.nav_layout.addWidget(self.btn_deepseek)
        self.nav_layout.addWidget(self.btn_whatsapp)
        self.nav_layout.addWidget(self.btn_chatgpt)
        self.nav_layout.addWidget(self.btn_youtube)
        self.nav_layout.addWidget(self.btn_music)
        self.nav_layout.addWidget(self.btn_notes)
        self.nav_layout.addWidget(self.btn_clipboard)
        self.nav_layout.addWidget(self.btn_downloads)
        self.nav_layout.addWidget(self.btn_notifications)
        self.nav_layout.addWidget(self.btn_add_tab)

        self.nav_layout.addStretch()

        theme_Energy_container = QWidget()
        theme_Energy_layout = QHBoxLayout()
        theme_Energy_layout.setContentsMargins(0, 0, 0, 0)
        theme_Energy_layout.setSpacing(5)

        self.btn_theme = QPushButton("Change Theme")
        self.btn_clear_cache = QPushButton("🧹 Clear Cache")
        self.btn_clear_cache.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_clear_cache.clicked.connect(self.clear_cache)
        self.btn_clear_cache.setToolTip("Clear all browser cache, cookies, and session data")

        self.btn_Energy_saving = QPushButton("🔋 OFF")
        self.btn_Energy_saving.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_Energy_saving.clicked.connect(self.toggle_Energy_saving)
        self.btn_Energy_saving.setToolTip("Click to toggle Energy saving mode")

        self.btn_bluetooth = QPushButton(" OFF")
        self.btn_bluetooth.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_bluetooth.clicked.connect(self.toggle_bluetooth)
        self.btn_bluetooth.setToolTip("Click to toggle Bluetooth")

        bluetooth_icon_path = os.path.join(os.path.dirname(__file__), "assets", "bluetooth.png")
        if os.path.exists(bluetooth_icon_path):
            bluetooth_icon = QIcon(bluetooth_icon_path)
            self.btn_bluetooth.setIcon(bluetooth_icon)
            self.btn_bluetooth.setIconSize(QSize(20, 20))

        self.nav_layout.addWidget(self.btn_theme)
        self.nav_layout.addWidget(self.btn_clear_cache)
        theme_Energy_layout.addWidget(self.btn_Energy_saving)
        theme_Energy_layout.addWidget(self.btn_bluetooth)
        theme_Energy_container.setLayout(theme_Energy_layout)

        self.nav_layout.addWidget(theme_Energy_container)

        window_controls = QWidget()
        win_layout = QHBoxLayout()
        self.btn_minimize = QPushButton("−")
        self.btn_maximize = QPushButton("□")
        self.btn_close = QPushButton("✕")
        for b in [self.btn_minimize, self.btn_maximize, self.btn_close]: 
            b.setFixedSize(30, 30)
        self.btn_minimize.clicked.connect(self.showMinimized)
        self.btn_maximize.clicked.connect(self.toggle_maximize)
        self.btn_close.clicked.connect(self.close)
        win_layout.addWidget(self.btn_minimize)
        win_layout.addWidget(self.btn_maximize)
        win_layout.addWidget(self.btn_close)
        window_controls.setLayout(win_layout)
        self.nav_layout.addWidget(window_controls)

        self.nav_bar.setLayout(self.nav_layout)

        modern_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        
        # Create WhatsApp with WebViewWithNav
        self.whatsapp = WebViewWithNav("about:blank", self.download_manager, self.notification_manager, "whatsapp_profile")
        # Apply custom profile and user agent
        whatsapp_profile = QWebEngineProfile("whatsapp_profile")
        storage_path = os.path.join(self.sessions_root, "whatsapp_profile")
        os.makedirs(storage_path, exist_ok=True)
        whatsapp_profile.setPersistentStoragePath(storage_path)
        whatsapp_profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        whatsapp_profile.setHttpUserAgent(modern_ua)
        
        # Create page and set to webview
        whatsapp_page = CustomWebEnginePage(whatsapp_profile, self.download_manager, self.notification_manager, self.whatsapp.webview)
        self.whatsapp.webview.setPage(whatsapp_page)
        self.whatsapp.webview.setUrl(QUrl("https://web.whatsapp.com/"))
        
        # Create DeepSeek with WebViewWithNav
        self.deepseek = WebViewWithNav("about:blank", self.download_manager, self.notification_manager, "deepseek_profile")
        deepseek_page = CustomWebEnginePage(self.default_profile, self.download_manager, self.notification_manager, self.deepseek.webview)
        self.deepseek.webview.setPage(deepseek_page)
        self.deepseek.webview.setUrl(QUrl("https://chat.deepseek.com/"))
        
        # Create ChatGPT with WebViewWithNav
        self.chatgpt = WebViewWithNav("about:blank", self.download_manager, self.notification_manager, "chatgpt_profile")
        chatgpt_page = CustomWebEnginePage(self.default_profile, self.download_manager, self.notification_manager, self.chatgpt.webview)
        self.chatgpt.webview.setPage(chatgpt_page)
        self.chatgpt.webview.setUrl(QUrl("https://chat.openai.com/"))
        
        # Create YouTube with WebViewWithNav
        self.youtube = WebViewWithNav("about:blank", self.download_manager, self.notification_manager, "youtube_profile")
        youtube_page = CustomWebEnginePage(self.default_profile, self.download_manager, self.notification_manager, self.youtube.webview)
        self.youtube.webview.setPage(youtube_page)
        self.youtube.webview.setUrl(QUrl("https://www.youtube.com/"))
        
        self.music_player = MusicPlayerWidget()
        self.music_player.shown.connect(self.on_music_widget_shown)
        self.music_player.hidden.connect(self.on_music_widget_hidden)

        self.notes_widget = NotesWidget()
        self.search_timer = ThrottledSearch(self._do_filter_notes, delay=300)
        self.clipboard_widget = ClipboardWidget()
        self.download_manager_widget = DownloadManagerWidget(self.download_manager, self)
        self.notifications_widget = NotificationsWidget(self.notification_manager, self)

        self.stack = QStackedWidget()
        self.stack.addWidget(self.deepseek)
        self.stack.addWidget(self.whatsapp)
        self.stack.addWidget(self.chatgpt)
        self.stack.addWidget(self.youtube)
        self.stack.addWidget(self.music_player)
        self.stack.addWidget(self.notes_widget)
        self.stack.addWidget(self.clipboard_widget)
        self.stack.addWidget(self.download_manager_widget)
        self.stack.addWidget(self.notifications_widget)

        self.btn_deepseek.clicked.connect(lambda: self.stack.setCurrentWidget(self.deepseek))
        self.btn_whatsapp.clicked.connect(self.reload_whatsapp_if_needed)
        self.btn_chatgpt.clicked.connect(lambda: self.stack.setCurrentWidget(self.chatgpt))
        self.btn_youtube.clicked.connect(lambda: self.stack.setCurrentWidget(self.youtube))
        self.btn_music.clicked.connect(lambda: self.stack.setCurrentWidget(self.music_player))
        self.btn_notes.clicked.connect(lambda: self.stack.setCurrentWidget(self.notes_widget))
        self.btn_clipboard.clicked.connect(lambda: self.stack.setCurrentWidget(self.clipboard_widget))
        self.btn_downloads.clicked.connect(lambda: self.stack.setCurrentWidget(self.download_manager_widget))
        self.btn_notifications.clicked.connect(lambda: self.stack.setCurrentWidget(self.notifications_widget))
        self.btn_theme.clicked.connect(self.toggle_theme)

        self.Energy_status_timer = QTimer()
        self.Energy_status_timer.timeout.connect(self.update_Energy_status_tooltip)
        self.Energy_status_timer.start(60000) 

        self.bluetooth_check_timer = QTimer()
        self.bluetooth_check_timer.timeout.connect(self.verify_bluetooth_status)
        self.bluetooth_check_timer.start(30000) 

        self.status_container = QFrame()
        self.status_container.setObjectName("statusContainer")
        status_layout = QHBoxLayout()
        self.status_text = QLabel("Coded By Aydiel@FalconEye")

        self.datetime_label = QLabel()

        self.github_icon = QLabel()
        github_pixmap = QPixmap("assets/github.png")
        if not github_pixmap.isNull():
            scaled_pixmap = github_pixmap.scaled(20, 20, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.github_icon.setPixmap(scaled_pixmap)
        else:
            self.github_icon.setText("🐙")
        
        self.github_icon.setCursor(Qt.CursorShape.PointingHandCursor)
        self.github_icon.mousePressEvent = lambda e: webbrowser.open("https://github.com/Falco1337")

        self.instagram_icon = QLabel()
        instagram_pixmap = QPixmap("assets/instagram.png")
        if not instagram_pixmap.isNull():
            scaled_pixmap = instagram_pixmap.scaled(20, 20, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.instagram_icon.setPixmap(scaled_pixmap)
        else:
            self.github_icon.setText("📸")
        
        self.instagram_icon.setCursor(Qt.CursorShape.PointingHandCursor)
        self.instagram_icon.mousePressEvent = lambda e: webbrowser.open("https://www.instagram.com/a.xydiel/")

        status_layout.addWidget(self.status_text)
        status_layout.addWidget(self.github_icon)
        status_layout.addWidget(self.instagram_icon)
        status_layout.addStretch()
        status_layout.addWidget(self.datetime_label)
        self.status_container.setLayout(status_layout)

        main_layout.addWidget(self.nav_bar)
        main_layout.addWidget(self.stack, 1)
        main_layout.addWidget(self.status_container)
        self.central_widget.setLayout(main_layout)
        self.setCentralWidget(self.central_widget)

        self.update_datetime()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_datetime)
        self.timer.start(1000)
    
    def filter_notes_throttled(self):
        if hasattr(self, 'search_timer') and self.search_timer:
            self.search_timer.trigger()
    
    def _do_filter_notes(self):
        if hasattr(self, 'notes_widget'):
            filter_text = self.notes_widget.search_input.text().lower()
            category = self.notes_widget.category_combo.currentText()
            self.notes_widget.refresh_notes_list(category, filter_text)
    
    def show_music_widget(self):
        self.stack.setCurrentWidget(self.music_player)
        self.music_player_active = True
        if not self.player_timer.isActive():
            self.player_timer.start(2000)  
    
    def update_player_info(self):
        if hasattr(self, 'music_player') and self.music_player_active:
            self.music_player.update_player_info()
    
    def changeEvent(self, event):
        if event.type() == event.Type.WindowStateChange:
            if self.windowState() & Qt.WindowState.WindowMinimized:
                if hasattr(self, 'refresh_timer') and self.refresh_timer:
                    self.refresh_timer.stop()
                
                if hasattr(self, 'player_timer') and self.player_timer is not None:
                    self.player_timer.stop()
                    
                if hasattr(self, 'Energy_status_timer') and self.Energy_status_timer:
                    self.Energy_status_timer.stop()
                
                if hasattr(self, 'bluetooth_check_timer'):
                    self.bluetooth_check_timer.stop()
                
                if hasattr(self, 'music_player') and hasattr(self.music_player, 'timer') and self.music_player.timer:
                    self.music_player.timer.stop()
            
            elif self.windowState() == Qt.WindowState.WindowNoState or \
                self.windowState() & Qt.WindowState.WindowMaximized:
                if hasattr(self, 'refresh_timer') and self.refresh_timer:
                    self.refresh_timer.start(30000)
                if hasattr(self, 'music_player') and self.music_player_active:
                    if hasattr(self, 'player_timer') and self.player_timer is not None:
                        self.player_timer.start(2000)
                
                if hasattr(self, 'Energy_status_timer') and self.Energy_status_timer:
                    self.Energy_status_timer.start(60000) 
                
                if hasattr(self, 'bluetooth_check_timer'):
                    self.bluetooth_check_timer.start(30000) 
                
                if hasattr(self, 'music_player') and \
                self.stack.currentWidget() == self.music_player:
                    if hasattr(self.music_player, 'timer') and self.music_player.timer:
                        self.music_player.timer.start(1000)
        
        super().changeEvent(event)

    def toggle_maximize(self):
        if self.isMaximized(): 
            self.showNormal()
            self.btn_maximize.setText("□")
        else: 
            self.showMaximized()
            self.btn_maximize.setText("❐")

    def apply_light_mode(self):
        self.dark_mode = False
        self.central_widget.setStyleSheet("""
            QWidget#centralWidget { 
                background: #f8f9fa; 
                border-radius: 15px; 
            } 
            QLabel { 
                color: #000000; 
            } 
            QWidget#navBar QLabel { 
                color: #000000; 
            }
        """)
        btn_style = """
            QPushButton { 
                background: white; 
                color: black; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #ddd; 
            }
            QPushButton:hover {
                background: #f0f0f0;
            }
        """
        self.btn_add_tab.setStyleSheet("""
            QPushButton { 
                background: white; 
                color: black; 
                padding: 6px; 
                border-radius: 10px; 
                border: 1px solid #ddd; 
                font-size: 16px; 
            }
            QPushButton:hover {
                background: #f0f0f0;
            }
        """)
        self.btn_clear_cache.setStyleSheet("""
            QPushButton { 
                background: white; 
                color: black; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #ddd; 
            }
            QPushButton:hover {
                background: #f0f0f0;
            }
        """)
        self.btn_Energy_saving.setStyleSheet("""
            QPushButton { 
                background: white; 
                color: black; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #ddd; 
            }
            QPushButton:hover {
                background: #f0f0f0;
            }
        """)
        self.btn_bluetooth.setStyleSheet("""
            QPushButton { 
                background: white; 
                color: black; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #ddd; 
            }
            QPushButton:hover {
                background: #f0f0f0;
            }
        """)
        for btn in [self.btn_deepseek, self.btn_whatsapp, self.btn_chatgpt, self.btn_youtube, 
                    self.btn_music, self.btn_notes, self.btn_clipboard, 
                    self.btn_downloads, self.btn_notifications, self.btn_theme, 
                    self.btn_minimize, self.btn_maximize, self.btn_close]:
            btn.setStyleSheet(btn_style)
        self.notes_widget.set_dark_mode(False)
        self.clipboard_widget.set_dark_mode(False)
        self.download_manager_widget.set_dark_mode(False)
        self.music_player.set_dark_mode(False)
        
        # Update navigation bars for web views
        if hasattr(self, 'deepseek') and hasattr(self.deepseek, 'set_dark_mode'):
            self.deepseek.set_dark_mode(False)
        if hasattr(self, 'whatsapp') and hasattr(self.whatsapp, 'set_dark_mode'):
            self.whatsapp.set_dark_mode(False)
        if hasattr(self, 'chatgpt') and hasattr(self.chatgpt, 'set_dark_mode'):
            self.chatgpt.set_dark_mode(False)
        if hasattr(self, 'youtube') and hasattr(self.youtube, 'set_dark_mode'):
            self.youtube.set_dark_mode(False)
        for tab in self.tabs:
            if hasattr(tab.webview, 'set_dark_mode'):
                tab.webview.set_dark_mode(False)
        
        self.update_tab_styles()
        if hasattr(self, 'btn_notifications'):
            self.btn_notifications.setStyleSheet(btn_style)

    def apply_dark_mode(self):
        self.dark_mode = True
        self.central_widget.setStyleSheet("""
            QWidget#centralWidget { 
                background: #1a1a2e; 
                border-radius: 15px; 
            }
            QLabel {
                color: #ffffff;
            }
        """)
        btn_style = """
            QPushButton { 
                background: #16213e; 
                color: white; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #333; 
            }
            QPushButton:hover {
                background: #1f2a4a;
            }
        """
        self.btn_add_tab.setStyleSheet("""
            QPushButton { 
                background: #16213e; 
                color: white; 
                padding: 6px; 
                border-radius: 10px; 
                border: 1px solid #333; 
                font-size: 16px; 
            }
            QPushButton:hover {
                background: #1f2a4a;
            }
        """)
        self.btn_clear_cache.setStyleSheet("""
            QPushButton { 
                background: #16213e; 
                color: white; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #333; 
            }
            QPushButton:hover {
                background: #1f2a4a;
            }
        """)
        self.btn_Energy_saving.setStyleSheet("""
            QPushButton { 
                background: #16213e; 
                color: white; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #333; 
            }
            QPushButton:hover {
                background: #1f2a4a;
            }
        """)
        self.btn_bluetooth.setStyleSheet("""
            QPushButton { 
                background: #16213e; 
                color: white; 
                padding: 6px 10px; 
                border-radius: 10px; 
                border: 1px solid #333; 
            }
            QPushButton:hover {
                background: #1f2a4a;
            }
        """)
        for btn in [self.btn_deepseek, self.btn_whatsapp, self.btn_chatgpt, self.btn_youtube, 
                    self.btn_music, self.btn_notes, self.btn_clipboard, 
                    self.btn_downloads, self.btn_notifications, self.btn_theme, 
                    self.btn_minimize, self.btn_maximize, self.btn_close]:
            btn.setStyleSheet(btn_style)
        self.notes_widget.set_dark_mode(True)
        self.clipboard_widget.set_dark_mode(True)
        self.download_manager_widget.set_dark_mode(True)
        self.music_player.set_dark_mode(True)
        
        # Update navigation bars for web views
        if hasattr(self, 'deepseek') and hasattr(self.deepseek, 'set_dark_mode'):
            self.deepseek.set_dark_mode(True)
        if hasattr(self, 'whatsapp') and hasattr(self.whatsapp, 'set_dark_mode'):
            self.whatsapp.set_dark_mode(True)
        if hasattr(self, 'chatgpt') and hasattr(self.chatgpt, 'set_dark_mode'):
            self.chatgpt.set_dark_mode(True)
        if hasattr(self, 'youtube') and hasattr(self.youtube, 'set_dark_mode'):
            self.youtube.set_dark_mode(True)
        for tab in self.tabs:
            if hasattr(tab.webview, 'set_dark_mode'):
                tab.webview.set_dark_mode(True)
        
        self.update_tab_styles()
        if hasattr(self, 'btn_notifications'):
            self.btn_notifications.setStyleSheet(btn_style)

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.logo_label.setPixmap(self.create_logo())
        if self.dark_mode: 
            self.apply_dark_mode()
            self.btn_theme.setText("Light")
        else: 
            self.apply_light_mode()
            self.btn_theme.setText("Dark")

        if hasattr(self, 'notifications_widget'):
            self.notifications_widget.set_dark_mode(self.dark_mode)

        if hasattr(self, 'notification_manager'):
            self.update_notification_badge(self.notification_manager.unread_count)

    def update_datetime(self):
        current = QDateTime.currentDateTime().toTimeZone(QTimeZone(b"Asia/Kuala_Lumpur"))
        self.datetime_label.setText(current.toString("dddd, MMMM d, yyyy • hh:mm:ss"))

    def closeEvent(self, event):
        try:
            # Update URLs for all tabs before saving
            for tab in self.tabs:
                if hasattr(tab.webview, 'webview'):
                    tab.url = tab.webview.webview.url().toString()
            
            # Final save
            self.save_tab_state()
            
            # Stop all timers
            self.refresh_timer.stop()
            self.timer.stop()
            self.Energy_status_timer.stop()
            self.bluetooth_check_timer.stop()
            
            if hasattr(self, 'auto_save_timer'):
                self.auto_save_timer.stop()
            
            # Clean up
            for tab in self.tabs:
                if hasattr(tab, 'webview') and tab.webview:
                    tab.webview.setParent(None)
                    tab.webview.deleteLater()
            
            self.notes_widget.save_notes()
            
            event.accept()
        except Exception as e:
            print(f"Error during close: {e}")
            event.accept()

def main():
    chrome_flags = [
        "--disable-gpu",
        "--disable-gpu-compositing",
        "--disable-accelerated-video-decode",
        "--disable-accelerated-2d-canvas",
        "--disable-webgl",
        "--disable-webgl2",
        "--disable-3d-apis",
        "--disable-features=VaapiVideoDecoder",
        "--disable-features=VaapiVideoEncoder",
        "--disable-features=UseOzonePlatform",
        "--disable-features=VizDisplayCompositor",
        "--disable-features=Vulkan",
        "--disable-features=CanvasOopRasterization",
        "--disable-features=OverlayScrollbar",
        "--disable-features=CalculateNativeWinOcclusion",
        "--disable-features=HardwareMediaKeyHandling",
        "--disable-features=MediaSessionService",
        "--disable-component-update",
        "--disable-sync",
        "--disable-background-networking",
        "--disable-default-apps",
        "--no-first-run",
        "--no-experiments",
        "--no-pings",
        "--autoplay-policy=document-user-activation-required",
        "--force-device-scale-factor=1",
        "--force-color-profile=srgb",
        "--disable-breakpad",
        "--disable-crash-reporter",
        "--disable-logging",
        "--log-level=3",
        "--silent-debugger-extension-api",
        "--no-sandbox",        
        "--enable-features=ClipboardAPI,ClipboardReadWrite,ClipboardCustomFormats,WebContentsOcclusion",
        "--disable-web-security", 
        "--allow-file-access-from-files",
        "--enable-blink-features=Clipboard,ClipboardItem,AsyncClipboard",        
        "--enable-shared-workers",
        "--enable-webgl2-compute-context",
    ]
    
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = " ".join(chrome_flags)
    os.environ["QT_QUICK_BACKEND"] = "software"
    os.environ["QT_WEBENGINE_DISABLE_SANDBOX"] = "1"
    os.environ["QTWEBENGINE_DISABLE_SANDBOX"] = "1"    
    os.environ["QTWEBENGINE_REMOTE_DEBUGGING"] = "9222"

    os.environ["QT_QPA_PLATFORM"] = "xcb"
    
    app = QApplication(sys.argv)
    app.setAttribute(Qt.ApplicationAttribute.AA_UseSoftwareOpenGL)
    app.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)
    window = ALINDashboard()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
